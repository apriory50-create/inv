import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'news_models.dart';
import 'news_store.dart';
import 'rss_parser.dart';

/// HTTP-клиент для каналов. Подменяется в тестах.
final newsHttpProvider = Provider<Dio>(
  (ref) => Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 20),
      responseType: ResponseType.plain,
      followRedirects: true,
      maxRedirects: 3,
      headers: {'Accept': 'application/rss+xml, application/atom+xml, application/xml, text/xml;q=0.9'},
    ),
  ),
);

@immutable
class NewsState {
  final List<NewsSource> sources;
  final List<RawNewsItem> items;
  final NewsFilterSettings filters;
  final bool refreshing;

  /// Ошибки загрузки по названию источника.
  final Map<String, String> errors;
  final DateTime? updatedAt;

  const NewsState({
    this.sources = const [],
    this.items = const [],
    this.filters = const NewsFilterSettings(),
    this.refreshing = false,
    this.errors = const {},
    this.updatedAt,
  });

  NewsState copyWith({
    List<NewsSource>? sources,
    List<RawNewsItem>? items,
    NewsFilterSettings? filters,
    bool? refreshing,
    Map<String, String>? errors,
    DateTime? updatedAt,
  }) {
    return NewsState(
      sources: sources ?? this.sources,
      items: items ?? this.items,
      filters: filters ?? this.filters,
      refreshing: refreshing ?? this.refreshing,
      errors: errors ?? this.errors,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

class NewsController extends AsyncNotifier<NewsState> {
  static const int _maxChars = 3000000;

  @override
  Future<NewsState> build() async {
    final store = await ref.watch(newsStoreProvider.future);
    return NewsState(
      sources: await store.sources(),
      items: await store.cachedItems(),
      filters: store.loadFilters(),
    );
  }

  Future<void> _reload(NewsState next) async {
    state = AsyncData(next);
  }

  /// Адрес должен быть http или https; остальное отклоняем.
  static String? validateUrl(String url) {
    final u = Uri.tryParse(url.trim());
    if (u == null || !(u.scheme == 'http' || u.scheme == 'https') || u.host.isEmpty) {
      return 'Адрес должен начинаться с http:// или https:// и вести на RSS или Atom.';
    }
    return null;
  }

  Future<String?> addSource(String title, String url) async {
    final t = title.trim();
    if (t.isEmpty) return 'Укажите название канала.';
    final err = validateUrl(url);
    if (err != null) return err;
    final cur = state.valueOrNull;
    if (cur == null) return 'Новости ещё загружаются.';
    if (cur.sources.any((s) => s.url == url.trim())) return 'Такой канал уже подключён.';
    final store = await ref.read(newsStoreProvider.future);
    await store.addSource(t, url.trim());
    await _reload(cur.copyWith(sources: await store.sources()));
    return null;
  }

  Future<void> toggleSource(NewsSource s, bool on) async {
    final cur = state.valueOrNull;
    if (cur == null || s.id == null) return;
    final store = await ref.read(newsStoreProvider.future);
    await store.setEnabled(s.id!, on);
    await _reload(cur.copyWith(sources: await store.sources()));
  }

  Future<void> removeSource(NewsSource s) async {
    final cur = state.valueOrNull;
    if (cur == null || s.id == null) return;
    final store = await ref.read(newsStoreProvider.future);
    await store.removeSource(s.id!);
    await store.deleteItemsOfSource(s.title);
    await _reload(cur.copyWith(sources: await store.sources(), items: await store.cachedItems()));
  }

  /// Ручная заметка: вставленный текст новости (например, из другого приложения).
  Future<String?> addNote(String title, String text) async {
    final t = title.trim();
    final body = text.trim();
    if (t.isEmpty || body.isEmpty) return 'Укажите заголовок и текст.';
    final cur = state.valueOrNull;
    if (cur == null) return 'Новости ещё загружаются.';
    final store = await ref.read(newsStoreProvider.future);
    final item = RawNewsItem(sourceTitle: 'Вручную', title: t, summary: body, published: DateTime.now().toUtc());
    await store.saveItems([item]);
    await _reload(cur.copyWith(items: await store.cachedItems()));
    return null;
  }

  Future<void> setFilters(NewsFilterSettings f) async {
    final cur = state.valueOrNull;
    if (cur == null) return;
    final store = await ref.read(newsStoreProvider.future);
    await store.saveFilters(f);
    await _reload(cur.copyWith(filters: f));
  }

  String _netText(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.receiveTimeout:
      case DioExceptionType.sendTimeout:
        return 'Канал не ответил вовремя.';
      case DioExceptionType.connectionError:
        return 'Нет соединения с каналом.';
      case DioExceptionType.badResponse:
        return 'Канал ответил ошибкой (${e.response?.statusCode ?? '?'}).';
      default:
        return 'Не удалось загрузить канал.';
    }
  }

  /// Загружает все включённые каналы. Ошибка одного не останавливает остальные.
  Future<void> refresh() async {
    final cur = state.valueOrNull;
    if (cur == null || cur.refreshing) return;
    await _reload(cur.copyWith(refreshing: true));

    final store = await ref.read(newsStoreProvider.future);
    final dio = ref.read(newsHttpProvider);
    final fresh = <RawNewsItem>[];
    final errors = <String, String>{};

    for (final s in cur.sources.where((s) => s.enabled && !s.isManual)) {
      try {
        final r = await dio.get<String>(s.url);
        final body = r.data ?? '';
        if (body.length > _maxChars) {
          throw const FormatException('Канал вернул слишком большой ответ.');
        }
        final items = FeedParser.parse(body, sourceTitle: s.title);
        if (items.isEmpty) {
          errors[s.title] = 'В ответе не нашлось новостей. Проверьте, что адрес ведёт на RSS или Atom.';
        }
        fresh.addAll(items);
      } on DioException catch (e) {
        errors[s.title] = _netText(e);
      } on FormatException catch (e) {
        errors[s.title] = e.message;
      } catch (_) {
        errors[s.title] = 'Не удалось разобрать канал.';
      }
    }

    await store.saveItems(fresh);
    final latest = state.valueOrNull ?? cur;
    await _reload(latest.copyWith(
      items: await store.cachedItems(),
      refreshing: false,
      errors: errors,
      updatedAt: DateTime.now(),
    ));
  }
}

final newsControllerProvider =
    AsyncNotifierProvider<NewsController, NewsState>(NewsController.new);
