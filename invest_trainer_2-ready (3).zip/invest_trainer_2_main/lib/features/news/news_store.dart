import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

import '../../core/settings/settings_controller.dart';
import '../../data/db/app_database.dart';
import 'news_models.dart';

/// Хранение источников, кэша новостей и настроек фильтров.
class NewsStore {
  NewsStore(this._db, this._prefs);

  final Database _db;
  final SharedPreferences _prefs;

  static const _kFilters = 'news.filters.v1';

  NewsFilterSettings loadFilters() {
    final raw = _prefs.getString(_kFilters);
    if (raw == null) return const NewsFilterSettings();
    try {
      return NewsFilterSettings.fromJson(Map<String, Object?>.from(jsonDecode(raw) as Map));
    } catch (_) {
      return const NewsFilterSettings();
    }
  }

  Future<void> saveFilters(NewsFilterSettings f) =>
      _prefs.setString(_kFilters, jsonEncode(f.toJson()));

  Future<List<NewsSource>> sources() async {
    final rows = await _db.query('news_sources', orderBy: 'id ASC');
    return [
      for (final r in rows)
        NewsSource(
          id: r['id'] as int?,
          title: r['title'] as String,
          url: r['url'] as String,
          enabled: (r['enabled'] as int? ?? 1) == 1,
        ),
    ];
  }

  Future<void> addSource(String title, String url) => _db.insert('news_sources', {
        'title': title,
        'url': url,
        'kind': url.isEmpty ? 'note' : 'rss',
        'enabled': 1,
      });

  Future<void> setEnabled(int id, bool on) =>
      _db.update('news_sources', {'enabled': on ? 1 : 0}, where: 'id = ?', whereArgs: [id]);

  Future<void> removeSource(int id) => _db.delete('news_sources', where: 'id = ?', whereArgs: [id]);

  Future<List<RawNewsItem>> cachedItems() async {
    final rows = await _db.query('news_items', orderBy: 'published DESC, fetched DESC', limit: 800);
    return [
      for (final r in rows)
        RawNewsItem(
          sourceTitle: r['source'] as String,
          title: r['title'] as String,
          summary: r['summary'] as String,
          url: r['url'] as String,
          published: r['published'] == null
              ? null
              : DateTime.fromMillisecondsSinceEpoch(r['published'] as int, isUtc: true),
        ),
    ];
  }

  Future<void> saveItems(List<RawNewsItem> items) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final batch = _db.batch();
    for (final it in items) {
      batch.insert(
        'news_items',
        {
          'id': it.key,
          'source': it.sourceTitle,
          'title': it.title,
          'summary': it.summary,
          'url': it.url,
          'published': it.published?.millisecondsSinceEpoch,
          'fetched': now,
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
    // Старше двух недель не храним: кэш нужен для просмотра без сети, а не как архив.
    final cutoff = DateTime.now().subtract(const Duration(days: 14)).millisecondsSinceEpoch;
    batch.delete('news_items', where: 'fetched < ?', whereArgs: [cutoff]);
    await batch.commit(noResult: true);
  }

  Future<void> deleteItemsOfSource(String source) =>
      _db.delete('news_items', where: 'source = ?', whereArgs: [source]);
}

final newsStoreProvider = FutureProvider<NewsStore>((ref) async {
  final db = await ref.watch(databaseProvider.future);
  return NewsStore(db, ref.watch(sharedPreferencesProvider));
});
