import 'package:xml/xml.dart';

import 'news_models.dart';

/// Разбор RSS 2.0 и Atom. Устойчив к повреждённым данным: плохие записи пропускаются.
class FeedParser {
  const FeedParser._();

  static List<RawNewsItem> parse(String xml, {required String sourceTitle}) {
    final XmlDocument doc;
    try {
      doc = XmlDocument.parse(xml);
    } catch (_) {
      return const [];
    }
    final out = <RawNewsItem>[];
    for (final item in doc.findAllElements('item')) {
      out.add(_rss(item, sourceTitle));
    }
    for (final entry in doc.findAllElements('entry')) {
      out.add(_atom(entry, sourceTitle));
    }
    return out.where((r) => r.title.isNotEmpty).toList();
  }

  static String _child(XmlElement e, String name) {
    for (final c in e.findElements(name)) {
      return c.innerText.trim();
    }
    return '';
  }

  static RawNewsItem _rss(XmlElement e, String source) => RawNewsItem(
        sourceTitle: source,
        title: stripHtml(_child(e, 'title')),
        summary: stripHtml(_child(e, 'description')),
        url: _child(e, 'link'),
        published: parseDate(_child(e, 'pubDate')),
      );

  static RawNewsItem _atom(XmlElement e, String source) {
    var href = '';
    for (final l in e.findElements('link')) {
      final rel = l.getAttribute('rel');
      if (rel == null || rel == 'alternate') {
        href = l.getAttribute('href') ?? '';
        break;
      }
    }
    final summary = _child(e, 'summary').isNotEmpty ? _child(e, 'summary') : _child(e, 'content');
    return RawNewsItem(
      sourceTitle: source,
      title: stripHtml(_child(e, 'title')),
      summary: stripHtml(summary),
      url: href,
      published: parseDate(_child(e, 'updated').isNotEmpty ? _child(e, 'updated') : _child(e, 'published')),
    );
  }

  /// Убирает теги и распространённые HTML-сущности, сжимает пробелы.
  static String stripHtml(String s) {
    var t = s.replaceAll(RegExp(r'<[^>]*>'), ' ');
    t = t
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', '"')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>');
    return t.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  /// ISO 8601 понимаем; RFC 822 (в RSS) разбираем по месяцам.
  static DateTime? parseDate(String s) {
    if (s.isEmpty) return null;
    final iso = DateTime.tryParse(s);
    if (iso != null) return iso;
    final m = RegExp(r'(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})\s+(\d{1,2}):(\d{2})').firstMatch(s);
    if (m == null) return null;
    const months = {
      'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6,
      'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct': 10, 'Nov': 11, 'Dec': 12,
    };
    final month = months[m.group(2)];
    if (month == null) return null;
    return DateTime.utc(
      int.parse(m.group(3)!),
      month,
      int.parse(m.group(1)!),
      int.parse(m.group(4)!),
      int.parse(m.group(5)!),
    );
  }
}
