import '../portfolio/portfolio_models.dart';
import 'news_models.dart';

class _Rule {
  final List<String> words;
  final String effect;
  const _Rule(this.words, this.effect);
}

/// Классификация и фильтрация новостей. Все правила — простые эвристики по словам:
/// они помогают разобрать поток, но не заменяют чтение первоисточника.
class NewsClassifier {
  const NewsClassifier._();

  static const List<String> _macroWords = [
    'ставк', 'инфляц', 'курс', 'рубл', 'нефть', 'санкц', 'цб', 'банк россии', 'минфин',
    'офз', 'бюджет', 'ввп', 'безработиц', 'фрс', 'доллар', 'золот', 'дефолт',
  ];

  static const List<String> _rumorMarkers = [
    'слух', 'неподтвержд', 'по данным источников', 'инсайд', 'говорят', 'по информации из',
  ];

  static const List<String> _opinionMarkers = [
    'прогноз', 'считает', 'полагает', 'мнение', 'аналитик', 'рекомендует', 'может вырасти', 'может упасть',
  ];

  static const List<String> _clickbaitMarkers = [
    'шок', 'срочно', 'сенсац', 'вы не поверите', 'взорвёт', 'взорвет', 'только сейчас', '!!!',
  ];

  static const List<String> _adMarkers = [
    'реклама', 'промокод', 'подпишись', 'гарантированн', 'заработок', 'розыгрыш',
  ];

  static final List<_Rule> _rules = [
    _Rule(['ставк', 'повыс'], 'Облигации с фиксированным купоном могут подешеветь; флоатеры и денежный рынок выигрывают.'),
    _Rule(['ставк', 'вырос'], 'Облигации с фиксированным купоном могут подешеветь; флоатеры и денежный рынок выигрывают.'),
    _Rule(['ставк', 'снизи'], 'Облигации с фиксированным купоном могут подорожать; акции получают поддержку.'),
    _Rule(['инфляц', 'выше'], 'Давление на облигации; линкеры и флоатеры защищают лучше.'),
    _Rule(['инфляц', 'ниже'], 'Снижается давление на ставки: поддержка облигаций и акций.'),
    _Rule(['нефть', 'подорож'], 'Нефтегазовые компании могут получить рост выручки и дивидендов.'),
    _Rule(['нефть', 'вырос'], 'Нефтегазовые компании могут получить рост выручки и дивидендов.'),
    _Rule(['нефть', 'подешев'], 'Нефтегазовые компании под давлением; дивидендные ожидания могут снизиться.'),
    _Rule(['нефть', 'упал'], 'Нефтегазовые компании под давлением; дивидендные ожидания могут снизиться.'),
    _Rule(['дивиденд', 'сократ'], 'Дивидендные ожидания снижаются.'),
    _Rule(['дивиденд', 'отмен'], 'Дивидендные ожидания снижаются.'),
    _Rule(['дивиденд', 'рекорд'], 'Дивидендные ожидания растут; помните про дивидендный гэп в день отсечки.'),
    _Rule(['дефолт'], 'Высокий риск потери денег по бумагам этого эмитента.'),
    _Rule(['рейтинг', 'понизил'], 'Рост риска эмитента; спред к ОФЗ может расшириться.'),
    _Rule(['рейтинг', 'снизил'], 'Рост риска эмитента; спред к ОФЗ может расшириться.'),
    _Rule(['рубл', 'ослаб'], 'Валютные и золотые активы дорожают в рублях; импорт дорожает.'),
    _Rule(['курс', 'ослаб'], 'Валютные и золотые активы дорожают в рублях; импорт дорожает.'),
    _Rule(['санкц'], 'Риск для экспортёров и финансового сектора.'),
    _Rule(['выкуп', 'акций'], 'Выкуп акций обычно поддерживает цену и долю оставшихся акционеров.'),
    _Rule(['допэмисс'], 'Размытие доли акционеров; цена может снизиться.'),
    _Rule(['дополнительн', 'эмисс'], 'Размытие доли акционеров; цена может снизиться.'),
  ];

  static String _norm(String s) => s.toLowerCase().replaceAll('ё', 'е');

  static bool _hasAny(String text, List<String> words) {
    for (final w in words) {
      if (text.contains(w)) return true;
    }
    return false;
  }

  static bool _isWordAt(String text, String word) {
    final pattern = RegExp('(^|[^a-zа-я0-9])${RegExp.escape(word)}(\$|[^a-zа-я0-9])');
    return pattern.hasMatch(text);
  }

  /// Тип: слух, мнение или факт (по умолчанию факт — но это тоже эвристика).
  static NewsKind kindOf(String text) {
    if (_hasAny(text, _rumorMarkers)) return NewsKind.rumor;
    if (_hasAny(text, _opinionMarkers)) return NewsKind.opinion;
    return NewsKind.fact;
  }

  /// Признаки кликбейта и рекламы; 2 и больше — скрываем, если включён фильтр.
  static int noiseOf(RawNewsItem item) {
    final t = _norm('${item.title} ${item.summary}');
    var score = 0;
    for (final w in _clickbaitMarkers) {
      if (t.contains(w)) score++;
    }
    for (final w in _adMarkers) {
      if (t.contains(w)) score++;
    }
    if (item.title.length < 15) score++;
    final letters = item.title.replaceAll(RegExp(r'[^A-Za-zА-Яа-яЁё]'), '');
    if (letters.length > 6 && letters == letters.toUpperCase()) score++;
    return score;
  }

  /// Бумаги портфеля, упомянутые в новости: по тикеру как отдельному слову и по первому длинному слову названия.
  static List<String> matchPositions(String text, List<Position> positions) {
    final found = <String>[];
    for (final p in positions) {
      final ticker = _norm(p.ticker);
      var hit = ticker.length >= 3 && _isWordAt(text, ticker);
      if (!hit) {
        final first = _norm(p.name).split(RegExp(r'[\s,.()«»"-]+')).firstWhere(
              (w) => w.length >= 6,
              orElse: () => '',
            );
        hit = first.isNotEmpty && _isWordAt(text, first);
      }
      if (hit) found.add(p.ticker);
    }
    return found;
  }

  /// Возможное влияние по ключевым словам. Это именно «возможное», не прогноз.
  static List<String> impactsOf(String text) {
    final out = <String>[];
    for (final r in _rules) {
      if (r.words.every(text.contains) && !out.contains(r.effect)) {
        out.add(r.effect);
      }
    }
    return out;
  }

  static ClassifiedNews classify(RawNewsItem item, List<Position> positions) {
    final text = _norm('${item.title} ${item.summary}');
    final matched = matchPositions(text, positions);
    return ClassifiedNews(
      raw: item,
      // Упоминание бумаги портфеля — новость для портфеля, иначе — рыночная.
      scope: matched.isNotEmpty ? NewsScope.portfolio : NewsScope.market,
      kind: kindOf(text),
      matchedTickers: matched,
      impacts: impactsOf(text),
      noise: noiseOf(item),
    );
  }

  /// Удаляет дубликаты по нормализованному заголовку, сохраняя первое вхождение.
  static List<RawNewsItem> dedupe(List<RawNewsItem> items) {
    final seen = <String>{};
    final out = <RawNewsItem>[];
    for (final it in items) {
      final key = _norm(it.title).replaceAll(RegExp(r'[^a-zа-я0-9]+'), ' ').trim();
      final short = key.length > 60 ? key.substring(0, 60) : key;
      if (short.isEmpty || !seen.add(short)) continue;
      out.add(it);
    }
    return out;
  }

  /// Применяет фильтры пользователя и делит новости на рыночные и портфельные.
  static FilteredNews apply(
    List<RawNewsItem> raw, {
    required List<Position> positions,
    required NewsFilterSettings settings,
    required DateTime now,
  }) {
    final cutoff = now.subtract(Duration(days: settings.maxAgeDays));
    final include = settings.includeWords.map(_norm).where((w) => w.isNotEmpty).toList();
    final exclude = settings.excludeWords.map(_norm).where((w) => w.isNotEmpty).toList();
    final blocked = settings.blockedSources.map(_norm).toSet();

    var hidden = 0;
    final market = <ClassifiedNews>[];
    final portfolio = <ClassifiedNews>[];

    for (final it in dedupe(raw)) {
      final text = _norm('${it.title} ${it.summary}');
      if (it.published != null && it.published!.isBefore(cutoff)) {
        hidden++;
        continue;
      }
      if (blocked.contains(_norm(it.sourceTitle))) {
        hidden++;
        continue;
      }
      if (_hasAny(text, exclude)) {
        hidden++;
        continue;
      }
      if (include.isNotEmpty && !_hasAny(text, include)) {
        hidden++;
        continue;
      }
      final c = classify(it, positions);
      if (settings.hideNoisy && c.noise >= 2) {
        hidden++;
        continue;
      }
      final relevant = c.matchedTickers.isNotEmpty || _hasAny(text, _macroWords);
      if (settings.hideIrrelevant && !relevant) {
        hidden++;
        continue;
      }
      if (c.scope == NewsScope.portfolio) {
        portfolio.add(c);
      } else {
        market.add(c);
      }
    }

    int byDate(ClassifiedNews a, ClassifiedNews b) {
      final da = a.raw.published ?? DateTime.fromMillisecondsSinceEpoch(0);
      final db = b.raw.published ?? DateTime.fromMillisecondsSinceEpoch(0);
      return db.compareTo(da);
    }

    market.sort(byDate);
    portfolio.sort(byDate);
    return FilteredNews(market: market, portfolio: portfolio, hiddenCount: hidden);
  }
}

class FilteredNews {
  final List<ClassifiedNews> market;
  final List<ClassifiedNews> portfolio;
  final int hiddenCount;

  const FilteredNews({required this.market, required this.portfolio, required this.hiddenCount});
}
