import 'package:flutter/foundation.dart';

/// Источник новостей, который подключил пользователь.
@immutable
class NewsSource {
  final int? id;
  final String title;

  /// Адрес RSS или Atom. Для источника «Вручную» пустой.
  final String url;
  final bool enabled;

  const NewsSource({this.id, required this.title, this.url = '', this.enabled = true});

  bool get isManual => url.isEmpty;

  NewsSource copyWith({bool? enabled}) =>
      NewsSource(id: id, title: title, url: url, enabled: enabled ?? this.enabled);
}

/// Сырая новость из источника (до классификации).
@immutable
class RawNewsItem {
  final String sourceTitle;
  final String title;
  final String summary;
  final String url;
  final DateTime? published;

  const RawNewsItem({
    required this.sourceTitle,
    required this.title,
    this.summary = '',
    this.url = '',
    this.published,
  });

  /// Стабильный ключ для дедупликации и кэша.
  String get key {
    final base = url.isNotEmpty ? url : '$sourceTitle|$title';
    return base.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();
  }
}

/// Тип сообщения: факт можно проверить, мнение — чья-то оценка, слух — без официального источника.
enum NewsKind {
  fact('Факт'),
  opinion('Мнение'),
  rumor('Слух');

  const NewsKind(this.label);
  final String label;
}

/// К чему относится новость.
enum NewsScope {
  market('Рынок'),
  portfolio('Ваш портфель');

  const NewsScope(this.label);
  final String label;
}

/// Новость после классификации: тип, область, связь с портфелем и возможное влияние.
@immutable
class ClassifiedNews {
  final RawNewsItem raw;
  final NewsScope scope;
  final NewsKind kind;
  final List<String> matchedTickers;
  final List<String> impacts;
  final int noise;

  const ClassifiedNews({
    required this.raw,
    required this.scope,
    required this.kind,
    this.matchedTickers = const [],
    this.impacts = const [],
    this.noise = 0,
  });
}

/// Настройки фильтрации, которые задаёт пользователь.
@immutable
class NewsFilterSettings {
  /// Показывать только новости, в которых есть хотя бы одно из этих слов (пусто — все).
  final List<String> includeWords;

  /// Скрывать новости с любым из этих слов.
  final List<String> excludeWords;

  /// Названия источников, новости которых скрываются.
  final List<String> blockedSources;

  /// Скрывать кликбейт и рекламу.
  final bool hideNoisy;

  /// Скрывать новости, не связанные ни с портфелем, ни с рынком.
  final bool hideIrrelevant;

  /// Максимальный возраст новости в днях.
  final int maxAgeDays;

  const NewsFilterSettings({
    this.includeWords = const [],
    this.excludeWords = const [],
    this.blockedSources = const [],
    this.hideNoisy = true,
    this.hideIrrelevant = true,
    this.maxAgeDays = 7,
  });

  NewsFilterSettings copyWith({
    List<String>? includeWords,
    List<String>? excludeWords,
    List<String>? blockedSources,
    bool? hideNoisy,
    bool? hideIrrelevant,
    int? maxAgeDays,
  }) {
    return NewsFilterSettings(
      includeWords: includeWords ?? this.includeWords,
      excludeWords: excludeWords ?? this.excludeWords,
      blockedSources: blockedSources ?? this.blockedSources,
      hideNoisy: hideNoisy ?? this.hideNoisy,
      hideIrrelevant: hideIrrelevant ?? this.hideIrrelevant,
      maxAgeDays: maxAgeDays ?? this.maxAgeDays,
    );
  }

  Map<String, Object?> toJson() => {
        'include': includeWords,
        'exclude': excludeWords,
        'blocked': blockedSources,
        'noisy': hideNoisy,
        'irrelevant': hideIrrelevant,
        'age': maxAgeDays,
      };

  factory NewsFilterSettings.fromJson(Map<String, Object?> j) => NewsFilterSettings(
        includeWords: [for (final x in (j['include'] as List? ?? const [])) x as String],
        excludeWords: [for (final x in (j['exclude'] as List? ?? const [])) x as String],
        blockedSources: [for (final x in (j['blocked'] as List? ?? const [])) x as String],
        hideNoisy: j['noisy'] as bool? ?? true,
        hideIrrelevant: j['irrelevant'] as bool? ?? true,
        maxAgeDays: (j['age'] as num?)?.toInt() ?? 7,
      );
}
