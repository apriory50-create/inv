import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../../core/ai/ai_profiles_controller.dart';
import '../../core/data/data_backup.dart';
import '../../core/files/file_text_picker.dart';
import '../../core/security/secure_key_store.dart';
import '../../core/settings/settings_controller.dart';
import '../../core/share/share_service.dart';
import '../../data/db/app_database.dart';
import '../academy/progress_repository.dart';
import '../news/news_controller.dart';
import '../portfolio/portfolio_repository.dart';
import '../simulator/sim_controller.dart';

/// Экран переноса данных: экспорт в файл, импорт из текста файла, удаление всех данных.
class DataPage extends ConsumerStatefulWidget {
  const DataPage({super.key});

  @override
  ConsumerState<DataPage> createState() => _DataPageState();
}

class _DataPageState extends ConsumerState<DataPage> {
  bool _busy = false;

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text), duration: const Duration(seconds: 6)));
  }

  /// После импорта или удаления сбрасываем состояние, которое приложение держит в памяти.
  void _refreshAll() {
    ref.invalidate(simProvider);
    ref.invalidate(progressProvider);
    ref.invalidate(positionsProvider);
    ref.invalidate(newsControllerProvider);
    ref.invalidate(aiProfilesProvider);
    ref.invalidate(settingsProvider);
  }

  Future<void> _export() async {
    setState(() => _busy = true);
    try {
      final db = await ref.read(databaseProvider.future);
      final prefs = ref.read(sharedPreferencesProvider);
      final json = await DataBackup.export(db, prefs);
      final dir = await getApplicationDocumentsDirectory();
      final stamp = DateTime.now().toIso8601String().substring(0, 10);
      final file = File(p.join(dir.path, 'invest_trainer_backup_$stamp.json'));
      await file.writeAsString(json, flush: true);
      final msg = await ShareService.shareFile(file.path, subject: 'Резервная копия приложения');
      _snack(msg);
    } catch (_) {
      _snack('Не удалось создать файл резервной копии.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _import() async {
    final controller = TextEditingController();
    final raw = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Импорт резервной копии'),
        content: SizedBox(
          width: 480,
          child: TextField(
            controller: controller,
            minLines: 6,
            maxLines: 12,
            decoration: const InputDecoration(
              labelText: 'Вставьте содержимое файла резервной копии',
              helperText: 'Откройте файл .json в текстовом редакторе, выделите всё и скопируйте сюда.',
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Отмена')),
          TextButton(
            onPressed: () async {
              try {
                final picked = await FileTextPicker.pick(extensions: const ['json']);
                if (picked != null) controller.text = picked.text;
              } on FormatException catch (e) {
                if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text(e.message)));
              }
            },
            child: const Text('Выбрать файл'),
          ),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(controller.text), child: const Text('Проверить')),
        ],
      ),
    );
    controller.dispose();
    if (raw == null || raw.trim().isEmpty || !mounted) return;

    final String summary;
    try {
      summary = DataBackup.describe(raw);
    } on FormatException catch (e) {
      _snack(e.message);
      return;
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Заменить все данные?'),
        content: Text(
          'В файле:\n$summary\n\nВсе текущие данные приложения будут заменены содержимым файла. Отменить это будет нельзя.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Отмена')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Theme.of(ctx).colorScheme.error),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Заменить'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    setState(() => _busy = true);
    try {
      final db = await ref.read(databaseProvider.future);
      await DataBackup.restore(raw, db, ref.read(sharedPreferencesProvider));
      _refreshAll();
      _snack('Данные восстановлены. Ключи API нужно ввести заново в настройках ИИ.');
    } on FormatException catch (e) {
      _snack(e.message);
    } catch (_) {
      _snack('Не удалось восстановить данные. Текущие данные не изменены.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _wipe() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить все данные?'),
        content: const Text(
          'Будут удалены прогресс уроков, портфель, журнал, симулятор, новости и профили ИИ вместе с ключами API. '
          'Восстановить можно только из резервной копии.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Отмена')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Theme.of(ctx).colorScheme.error),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Удалить всё'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    setState(() => _busy = true);
    try {
      final keys = ref.read(secureKeyStoreProvider);
      for (final profile in ref.read(aiProfilesProvider).profiles) {
        await keys.deleteKey(profile.id);
      }
      final db = await ref.read(databaseProvider.future);
      await DataBackup.wipe(db, ref.read(sharedPreferencesProvider));
      _refreshAll();
      _snack('Все данные удалены.');
    } catch (_) {
      _snack('Не удалось удалить данные.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Резервная копия')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Что входит в копию', style: theme.textTheme.titleMedium),
          const SizedBox(height: 6),
          const Text(
            'Прогресс и тесты уроков, закладки и заметки, реальный портфель и журнал, источники и фильтры новостей, '
            'сохранение симулятора, профили ИИ без ключей, настройки оформления.',
          ),
          const SizedBox(height: 10),
          Text('Что не входит', style: theme.textTheme.titleMedium),
          const SizedBox(height: 6),
          const Text(
            'Ключи API: они хранятся только в защищённом хранилище устройства и в файл не попадают. '
            'Кэш новостей тоже не сохраняется: он загрузится заново.',
          ),
          const SizedBox(height: 10),
          Card(
            color: theme.colorScheme.errorContainer,
            child: const Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                'Файл резервной копии не зашифрован. В нём есть ваш портфель и заметки: не публикуйте его и храните там, где вам доверяете.',
              ),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _busy ? null : _export,
            icon: const Icon(Icons.ios_share),
            label: const Text('Экспортировать и поделиться'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _busy ? null : _import,
            icon: const Icon(Icons.file_open_outlined),
            label: const Text('Импортировать из файла'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(foregroundColor: theme.colorScheme.error),
            onPressed: _busy ? null : _wipe,
            icon: const Icon(Icons.delete_forever_outlined),
            label: const Text('Удалить все данные'),
          ),
          if (_busy) const Padding(padding: EdgeInsets.only(top: 16), child: Center(child: CircularProgressIndicator())),
        ],
      ),
    );
  }
}
