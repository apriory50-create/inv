import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/ai/ai_clients.dart';
import '../../core/ai/ai_models.dart';
import '../../core/ai/ai_profiles_controller.dart';
import '../../core/legal/disclaimer.dart';
import '../../core/security/secure_key_store.dart';
import '../../core/settings/settings_controller.dart';
import 'ai_profile_dialog.dart';
import 'data_page.dart';

class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  Future<void> _edit(BuildContext context, WidgetRef ref, AiProfile? profile) async {
    final hasKey = profile == null ? false : await ref.read(secureKeyStoreProvider).hasKey(profile.id);
    if (!context.mounted) return;
    final result = await showDialog<AiProfileEditResult>(
      context: context,
      builder: (_) => AiProfileDialog(initial: profile, hasKey: hasKey),
    );
    if (result == null) return;
    await ref.read(aiProfilesProvider.notifier).upsert(result.profile, apiKey: result.apiKey);
  }

  Future<void> _test(BuildContext context, WidgetRef ref, AiProfile profile) async {
    final messenger = ScaffoldMessenger.of(context);
    messenger.showSnackBar(const SnackBar(content: Text('Проверяю подключение…')));
    try {
      final key = await ref.read(secureKeyStoreProvider).readKey(profile.id) ?? '';
      final client = AiClientFactory.create(profile.copyWith(maxTokens: 64), key);
      final reply = await client.chat(const [AiMessage.user('Ответь одним словом: ок')]);
      messenger.hideCurrentSnackBar();
      messenger.showSnackBar(SnackBar(content: Text('Подключение работает. Ответ: ${_short(reply)}')));
    } on AiException catch (e) {
      messenger.hideCurrentSnackBar();
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    } catch (_) {
      messenger.hideCurrentSnackBar();
      messenger.showSnackBar(const SnackBar(content: Text('Не удалось проверить подключение.')));
    }
  }

  String _short(String s) => s.length > 60 ? '${s.substring(0, 60)}…' : s;

  Future<void> _confirmDelete(BuildContext context, WidgetRef ref, AiProfile profile) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить профиль?'),
        content: Text('Профиль «${profile.name}» и его ключ API будут удалены с устройства.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Удалить')),
        ],
      ),
    );
    if (ok == true) {
      await ref.read(aiProfilesProvider.notifier).remove(profile.id);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final ai = ref.watch(aiProfilesProvider);
    final theme = Theme.of(context);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Внешний вид', style: theme.textTheme.titleLarge),
        const SizedBox(height: 8),
        SegmentedButton<ThemeMode>(
          segments: const [
            ButtonSegment(value: ThemeMode.system, label: Text('Системная'), icon: Icon(Icons.brightness_auto)),
            ButtonSegment(value: ThemeMode.light, label: Text('Светлая'), icon: Icon(Icons.light_mode)),
            ButtonSegment(value: ThemeMode.dark, label: Text('Тёмная'), icon: Icon(Icons.dark_mode)),
          ],
          selected: {settings.themeMode},
          onSelectionChanged: (s) => ref.read(settingsProvider.notifier).setThemeMode(s.first),
        ),
        const SizedBox(height: 12),
        Text('Размер текста: ${(settings.fontScale * 100).round()}%'),
        Slider(
          value: settings.fontScale,
          min: 0.85,
          max: 1.6,
          divisions: 15,
          onChanged: (v) => ref.read(settingsProvider.notifier).setFontScale(v),
        ),
        const Divider(height: 32),
        Row(
          children: [
            Expanded(child: Text('Подключения ИИ', style: theme.textTheme.titleLarge)),
            FilledButton.icon(
              onPressed: () => _edit(context, ref, null),
              icon: const Icon(Icons.add),
              label: const Text('Добавить'),
            ),
          ],
        ),
        const SizedBox(height: 4),
        const Text(
          'Подключите любой ИИ-сервис со своим ключом API. Ключи хранятся в защищенном хранилище устройства '
          'и не попадают в экспорт, логи и «Поделиться».',
        ),
        const SizedBox(height: 8),
        if (ai.profiles.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Профилей пока нет. Нажмите «Добавить», выберите тип подключения, модель и введите ключ.'),
            ),
          )
        else
          for (final p in ai.profiles)
            Card(
              child: ListTile(
                leading: Icon(
                  ai.active?.id == p.id ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                  color: ai.active?.id == p.id ? theme.colorScheme.primary : null,
                ),
                title: Text(p.name),
                subtitle: Text('${p.type.label.split(' (').first} • ${p.model}'),
                onTap: () => ref.read(aiProfilesProvider.notifier).setActive(p.id),
                trailing: PopupMenuButton<String>(
                  onSelected: (v) {
                    switch (v) {
                      case 'edit':
                        _edit(context, ref, p);
                      case 'test':
                        _test(context, ref, p);
                      case 'delete':
                        _confirmDelete(context, ref, p);
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'test', child: Text('Проверить подключение')),
                    PopupMenuItem(value: 'edit', child: Text('Изменить')),
                    PopupMenuItem(value: 'delete', child: Text('Удалить')),
                  ],
                ),
              ),
            ),
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Отправлять в ИИ суммы'),
          subtitle: const Text('Выключено: в ИИ уходят названия и доли в процентах, без количества и цен.'),
          value: settings.sendAmountsToAi,
          onChanged: (v) => ref.read(settingsProvider.notifier).setSendAmountsToAi(v),
        ),
        const Divider(height: 32),
        Text('Данные', style: theme.textTheme.titleLarge),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.backup_outlined),
          title: const Text('Резервная копия и перенос данных'),
          subtitle: const Text('Экспорт в файл, импорт, удаление всех данных. Ключи API в копию не входят.'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const DataPage())),
        ),
        const Divider(height: 32),
        Text('О приложении', style: theme.textTheme.titleLarge),
        const SizedBox(height: 8),
        const Text(Disclaimer.full),
      ],
    );
  }
}
