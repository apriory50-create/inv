import 'package:flutter/material.dart';

import '../../core/ai/ai_models.dart';
import '../../core/ai/ai_profiles_controller.dart';

class AiProfileEditResult {
  final AiProfile profile;
  final String? apiKey;
  const AiProfileEditResult(this.profile, this.apiKey);
}

/// Диалог создания и редактирования профиля ИИ.
class AiProfileDialog extends StatefulWidget {
  const AiProfileDialog({super.key, this.initial, required this.hasKey});

  final AiProfile? initial;
  final bool hasKey;

  @override
  State<AiProfileDialog> createState() => _AiProfileDialogState();
}

class _AiProfileDialogState extends State<AiProfileDialog> {
  late AiProviderType _type;
  late final TextEditingController _name;
  late final TextEditingController _baseUrl;
  late final TextEditingController _model;
  late final TextEditingController _key;
  late final TextEditingController _system;
  late final TextEditingController _maxTokens;
  late double _temperature;
  bool _showKey = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    final i = widget.initial;
    _type = i?.type ?? AiProviderType.openaiCompatible;
    _name = TextEditingController(text: i?.name ?? '');
    _baseUrl = TextEditingController(text: i?.baseUrl ?? _type.defaultBaseUrl);
    _model = TextEditingController(text: i?.model ?? '');
    _key = TextEditingController();
    _system = TextEditingController(text: i?.systemPrompt ?? '');
    _maxTokens = TextEditingController(text: (i?.maxTokens ?? 1500).toString());
    _temperature = i?.temperature ?? 0.3;
  }

  @override
  void dispose() {
    _name.dispose();
    _baseUrl.dispose();
    _model.dispose();
    _key.dispose();
    _system.dispose();
    _maxTokens.dispose();
    super.dispose();
  }

  void _save() {
    final name = _name.text.trim();
    final url = _baseUrl.text.trim();
    final model = _model.text.trim();
    final tokens = int.tryParse(_maxTokens.text.trim());
    if (name.isEmpty) {
      setState(() => _error = 'Введите название профиля.');
      return;
    }
    if (!(url.startsWith('http://') || url.startsWith('https://'))) {
      setState(() => _error = 'Адрес должен начинаться с http:// или https://');
      return;
    }
    if (model.isEmpty) {
      setState(() => _error = 'Укажите имя модели (${_type.modelHint}).');
      return;
    }
    if (tokens == null || tokens < 100 || tokens > 100000) {
      setState(() => _error = 'Лимит токенов: число от 100 до 100000.');
      return;
    }
    final isNew = widget.initial == null;
    final keyText = _key.text.trim();
    if (isNew && keyText.isEmpty && _type != AiProviderType.openaiCompatible) {
      setState(() => _error = 'Введите ключ API.');
      return;
    }
    final profile = AiProfile(
      id: widget.initial?.id ?? AiProfilesController.newId(),
      name: name,
      type: _type,
      baseUrl: url,
      model: model,
      temperature: _temperature,
      maxTokens: tokens,
      systemPrompt: _system.text.trim(),
    );
    Navigator.of(context).pop(AiProfileEditResult(profile, keyText.isEmpty ? null : keyText));
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.initial == null ? 'Новый профиль ИИ' : 'Изменить профиль ИИ'),
      content: SizedBox(
        width: 460,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DropdownButtonFormField<AiProviderType>(
                value: _type,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Тип подключения'),
                items: [
                  for (final t in AiProviderType.values)
                    DropdownMenuItem(value: t, child: Text(t.label, overflow: TextOverflow.ellipsis)),
                ],
                onChanged: (v) {
                  if (v == null) return;
                  setState(() {
                    final wasDefault = _baseUrl.text.trim() == _type.defaultBaseUrl || _baseUrl.text.trim().isEmpty;
                    _type = v;
                    if (wasDefault) _baseUrl.text = v.defaultBaseUrl;
                  });
                },
              ),
              const SizedBox(height: 10),
              TextField(controller: _name, decoration: const InputDecoration(labelText: 'Название профиля')),
              const SizedBox(height: 10),
              TextField(
                controller: _baseUrl,
                decoration: const InputDecoration(
                  labelText: 'Адрес API',
                  helperText: 'Для локальных моделей, например: http://localhost:11434/v1',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _model,
                decoration: InputDecoration(labelText: 'Модель', helperText: _type.modelHint),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _key,
                obscureText: !_showKey,
                autocorrect: false,
                enableSuggestions: false,
                decoration: InputDecoration(
                  labelText: 'Ключ API',
                  helperText: widget.hasKey
                      ? 'Ключ уже сохранен. Оставьте пустым, чтобы не менять.'
                      : (_type == AiProviderType.openaiCompatible
                          ? 'Для локальных серверов ключ может быть не нужен.'
                          : 'Хранится в защищенном хранилище устройства.'),
                  suffixIcon: IconButton(
                    icon: Icon(_showKey ? Icons.visibility_off : Icons.visibility),
                    onPressed: () => setState(() => _showKey = !_showKey),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text('Температура: ${_temperature.toStringAsFixed(1)} (ниже — строже и стабильнее)'),
              Slider(
                value: _temperature,
                min: 0,
                max: 1.5,
                divisions: 15,
                onChanged: (v) => setState(() => _temperature = v),
              ),
              TextField(
                controller: _maxTokens,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Максимум токенов в ответе'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _system,
                minLines: 2,
                maxLines: 5,
                decoration: const InputDecoration(
                  labelText: 'Системный промт (необязательно)',
                  helperText: 'Добавляется к встроенным инструкциям приложения.',
                ),
              ),
              if (_error != null) ...[
                const SizedBox(height: 10),
                Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Отмена')),
        FilledButton(onPressed: _save, child: const Text('Сохранить')),
      ],
    );
  }
}
