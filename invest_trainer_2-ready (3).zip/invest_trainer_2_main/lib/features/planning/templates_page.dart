import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/format.dart';
import '../../core/legal/disclaimer.dart';
import '../../domain/planning/portfolio_templates.dart';
import '../portfolio/portfolio_models.dart';
import '../portfolio/portfolio_repository.dart';

/// Шаблоны портфелей: описание каждого и сравнение с реальным портфелем по классам.
class TemplatesPage extends ConsumerWidget {
  const TemplatesPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final positions = ref.watch(positionsProvider).valueOrNull ?? const <Position>[];
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Шаблоны портфелей')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Text('Шаблон — это ориентир пропорций, а не готовый совет. Выберите тот, который соответствует вашему горизонту и тому, сколько просадки вы выдержите.'),
            ),
          ),
          for (final t in PortfolioTemplates.all)
            Card(
              child: ExpansionTile(
                title: Text(t.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(t.description),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                expandedCrossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Риск: ${t.riskNote}'),
                  const SizedBox(height: 8),
                  Text('Пропорции:', style: theme.textTheme.titleSmall),
                  for (final c in AssetClass.values)
                    if ((t.shares[c] ?? 0) > 0)
                      Text('• ${c.label}: ${fmtPct((t.shares[c] ?? 0) * 100, sign: false)}'),
                  const SizedBox(height: 10),
                  if (positions.isEmpty)
                    const Text('Чтобы сравнить с портфелем, добавьте бумаги в раздел «Портфель».')
                  else
                    FilledButton.tonal(
                      onPressed: () => showDialog<void>(
                        context: context,
                        builder: (ctx) => _CompareDialog(template: t, positions: positions),
                      ),
                      child: const Text('Сравнить с моим портфелем'),
                    ),
                ],
              ),
            ),
          const SizedBox(height: 8),
          Text(Disclaimer.short, style: theme.textTheme.bodySmall),
        ],
      ),
    );
  }
}

class _CompareDialog extends StatelessWidget {
  const _CompareDialog({required this.template, required this.positions});

  final PortfolioTemplate template;
  final List<Position> positions;

  @override
  Widget build(BuildContext context) {
    final lines = PortfolioTemplates.compare(
      template,
      [for (final p in positions) (kind: p.kind, value: p.cost)],
    );
    return AlertDialog(
      title: Text('Сравнение: ${template.name}'),
      content: SizedBox(
        width: 480,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final l in lines)
                if (l.targetShare > 0 || l.currentShare > 0)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${l.cls.label}: у вас ${fmtPct(l.currentShare * 100, sign: false)}, '
                          'в шаблоне ${fmtPct(l.targetShare * 100, sign: false)}',
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        Text(l.advice, style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ),
              const SizedBox(height: 6),
              const Text('Доли считаются по стоимости покупки. Это учебное сравнение, не рекомендация.'),
            ],
          ),
        ),
      ),
      actions: [FilledButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Понятно'))],
    );
  }
}
