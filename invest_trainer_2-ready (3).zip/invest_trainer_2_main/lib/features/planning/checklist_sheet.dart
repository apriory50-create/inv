import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/db/app_database.dart';
import '../../domain/checklist/buy_checklist.dart';

/// Чек-лист «Купить? 10 вопросов». Результат можно сохранить в журнал.
class ChecklistSheet extends ConsumerStatefulWidget {
  const ChecklistSheet({super.key});

  @override
  ConsumerState<ChecklistSheet> createState() => _ChecklistSheetState();
}

class _ChecklistSheetState extends ConsumerState<ChecklistSheet> {
  final Map<String, Answer> _answers = {};
  final _ticker = TextEditingController();
  ChecklistResult? _result;
  String? _saved;

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  Future<void> _save(ChecklistResult r) async {
    final db = await ref.read(databaseProvider.future);
    await db.insert('journal', {
      'created_at': DateTime.now().millisecondsSinceEpoch,
      'ticker': _ticker.text.trim().isEmpty ? null : _ticker.text.trim().toUpperCase(),
      'action': 'checklist',
      'reason': 'Да: ${r.yesCount} из ${r.total}. Блокеров: ${r.blockers.length}',
      'outcome': r.verdict.label,
    });
    if (!mounted) return;
    setState(() => _saved = 'Сохранено в журнал.');
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final r = _result;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 12, 16, 12 + MediaQuery.of(context).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Купить? 10 вопросов', style: theme.textTheme.titleLarge),
              const SizedBox(height: 4),
              const Text('Ответьте честно. «Не знаю» — тоже ответ: он показывает, что проверить.'),
              const SizedBox(height: 8),
              TextField(
                controller: _ticker,
                decoration: const InputDecoration(labelText: 'Бумага (необязательно, для журнала)'),
              ),
              for (var i = 0; i < BuyChecklist.questions.length; i++) ...[
                const SizedBox(height: 10),
                Text('${i + 1}. ${BuyChecklist.questions[i].text}', style: const TextStyle(fontWeight: FontWeight.w600)),
                Text(BuyChecklist.questions[i].hint, style: theme.textTheme.bodySmall),
                const SizedBox(height: 4),
                SegmentedButton<Answer>(
                  segments: const [
                    ButtonSegment(value: Answer.yes, label: Text('Да')),
                    ButtonSegment(value: Answer.unknown, label: Text('Не знаю')),
                    ButtonSegment(value: Answer.no, label: Text('Нет')),
                  ],
                  emptySelectionAllowed: true,
                  selected: _answers[BuyChecklist.questions[i].id] == null
                      ? <Answer>{}
                      : {_answers[BuyChecklist.questions[i].id]!},
                  onSelectionChanged: (s) => setState(() {
                    if (s.isEmpty) {
                      _answers.remove(BuyChecklist.questions[i].id);
                    } else {
                      _answers[BuyChecklist.questions[i].id] = s.first;
                    }
                    _result = null;
                    _saved = null;
                  }),
                ),
              ],
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () => setState(() => _result = BuyChecklist.evaluate(_answers)),
                child: const Text('Посмотреть результат'),
              ),
              if (r != null) ...[
                const SizedBox(height: 12),
                Card(
                  color: switch (r.verdict) {
                    ChecklistVerdict.blocked => theme.colorScheme.errorContainer,
                    ChecklistVerdict.checkMore => theme.colorScheme.tertiaryContainer,
                    ChecklistVerdict.considerable => theme.colorScheme.primaryContainer,
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(r.verdict.label, style: theme.textTheme.titleMedium),
                        Text('Да: ${r.yesCount} из ${r.total}'),
                        if (r.blockers.isNotEmpty) ...[
                          const SizedBox(height: 6),
                          const Text('Критичные вопросы с ответом «нет»:', style: TextStyle(fontWeight: FontWeight.bold)),
                          for (final b in r.blockers) Text('• $b'),
                        ],
                        if (r.todo.isNotEmpty) ...[
                          const SizedBox(height: 6),
                          const Text('Что ещё проверить:', style: TextStyle(fontWeight: FontWeight.bold)),
                          for (final t in r.todo) Text('• $t'),
                        ],
                        const SizedBox(height: 8),
                        const Text('Это учебный чек-лист, а не рекомендация. Решение за вами.'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: () => _save(r),
                  icon: const Icon(Icons.bookmark_add_outlined),
                  label: const Text('Сохранить в журнал'),
                ),
                if (_saved != null) Text(_saved!, style: theme.textTheme.bodySmall),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
