import 'package:flutter/material.dart';

import '../../core/format.dart';
import '../../domain/planning/goal_planner.dart';

/// Планировщик цели: сколько откладывать каждый месяц и как это зависит от доходности.
class GoalPlannerPage extends StatefulWidget {
  const GoalPlannerPage({super.key});

  @override
  State<GoalPlannerPage> createState() => _GoalPlannerPageState();
}

class _GoalPlannerPageState extends State<GoalPlannerPage> {
  final _target = TextEditingController(text: '1000000');
  final _start = TextEditingController(text: '100000');
  final _years = TextEditingController(text: '5');
  final _inflation = TextEditingController(text: '7');
  bool _adjustInflation = false;

  @override
  void dispose() {
    _target.dispose();
    _start.dispose();
    _years.dispose();
    _inflation.dispose();
    super.dispose();
  }

  double? _num(TextEditingController c) => double.tryParse(c.text.trim().replaceAll(',', '.'));

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final target = _num(_target);
    final start = _num(_start);
    final years = _num(_years)?.round();
    final inflation = (_num(_inflation) ?? 0) / 100;

    String? error;
    if (target == null || target <= 0) {
      error = 'Укажите сумму цели больше нуля.';
    } else if (start == null || start < 0) {
      error = 'Стартовая сумма не может быть отрицательной.';
    } else if (years == null || years <= 0 || years > 50) {
      error = 'Срок — от 1 до 50 лет.';
    }

    List<GoalScenario> rows = const [];
    double? todayMoney;
    if (error == null) {
      rows = GoalPlanner.scenarios(target: target!, start: start!, years: years!);
      if (_adjustInflation) {
        todayMoney = GoalPlanner.targetInTodayMoney(target: target, inflation: inflation, years: years);
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Планировщик цели')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          TextField(controller: _target, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Сумма цели, ₽')),
          const SizedBox(height: 8),
          TextField(controller: _start, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Уже накоплено, ₽')),
          const SizedBox(height: 8),
          TextField(controller: _years, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Срок, лет')),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Показать цель в сегодняшних деньгах'),
            value: _adjustInflation,
            onChanged: (v) => setState(() => _adjustInflation = v),
          ),
          if (_adjustInflation)
            TextField(
              controller: _inflation,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Ожидаемая инфляция, % в год'),
            ),
          const SizedBox(height: 12),
          if (error != null)
            Text(error, style: TextStyle(color: theme.colorScheme.error))
          else ...[
            if (todayMoney != null)
              Text('Цель ${fmtRub(target!)} ₽ через $years лет — это около ${fmtRub(todayMoney)} ₽ в сегодняшних деньгах.',
                  style: theme.textTheme.bodyMedium),
            const SizedBox(height: 8),
            Text('Сколько откладывать в месяц', style: theme.textTheme.titleMedium),
            const SizedBox(height: 4),
            for (final r in rows)
              Card(
                child: ListTile(
                  title: Text('${fmtRub(r.monthly)} ₽ в месяц'),
                  subtitle: Text(
                    'Доходность ${fmtPct(r.annualReturn * 100, digits: 0, sign: false)} годовых. '
                    'Вы сами внесёте ${fmtRub(r.totalContributed)} ₽ за весь срок.',
                  ),
                ),
              ),
            const SizedBox(height: 8),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  'Расчёт предполагает, что доходность одинакова каждый год и взносы делаются в конце месяца. '
                  'Реальная доходность колеблется, и гарантий нет. Это ориентир для планирования, а не обещание.',
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
