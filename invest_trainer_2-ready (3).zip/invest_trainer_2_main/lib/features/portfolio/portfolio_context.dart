import 'portfolio_models.dart';

/// Формирует текстовое описание портфеля для ИИ.
/// По умолчанию отправляются только проценты и названия, без сумм.
class PortfolioContext {
  const PortfolioContext._();

  static String build(List<Position> positions, {required bool includeAmounts}) {
    final total = positions.fold<double>(0, (s, p) => s + p.cost);
    if (positions.isEmpty || total <= 0) {
      return 'Портфель пока пуст.';
    }

    final byKind = <PositionKind, double>{};
    for (final p in positions) {
      byKind[p.kind] = (byKind[p.kind] ?? 0) + p.cost;
    }

    final buf = StringBuffer('Структура портфеля (по стоимости покупки):\n');
    final kinds = byKind.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    for (final e in kinds) {
      buf.writeln('- ${e.key.label}: ${_pct(e.value, total)}%');
    }

    buf.writeln('\nПозиции:');
    var i = 1;
    for (final p in positions) {
      final share = _pct(p.cost, total);
      final amount = includeAmounts
          ? ', количество: ${_num(p.quantity)}, средняя цена: ${_num(p.avgPrice)} ${p.currency}'
          : '';
      final note = p.note.trim().isEmpty ? '' : ', заметка: ${p.note.trim()}';
      buf.writeln('$i) ${p.ticker} — ${p.name} (${p.kind.label}): $share%$amount$note');
      i++;
    }
    if (includeAmounts) {
      buf.writeln('\nОбщая стоимость по цене покупки: ${_num(total)}');
    }
    return buf.toString();
  }

  static String _pct(double part, double total) => (part / total * 100).toStringAsFixed(1);

  static String _num(double v) {
    if (v == v.roundToDouble()) return v.toStringAsFixed(0);
    return v.toStringAsFixed(2);
  }
}
