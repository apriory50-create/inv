import 'portfolio_models.dart';

/// Разбор CSV: разделитель определяется по заголовку (; или ,), поддерживаются кавычки и переносы внутри кавычек.
class CsvParser {
  const CsvParser._();

  static List<List<String>> parse(String text) {
    final clean = text.replaceFirst('\uFEFF', '');
    final firstLine = clean.split(RegExp(r'\r?\n')).firstWhere((l) => l.trim().isNotEmpty, orElse: () => '');
    final delim = ';'.allMatches(firstLine).length >= ','.allMatches(firstLine).length ? ';' : ',';

    final rows = <List<String>>[];
    var row = <String>[];
    final cell = StringBuffer();
    var inQuotes = false;
    for (var i = 0; i < clean.length; i++) {
      final ch = clean[i];
      if (inQuotes) {
        if (ch == '"') {
          if (i + 1 < clean.length && clean[i + 1] == '"') {
            cell.write('"');
            i++;
          } else {
            inQuotes = false;
          }
        } else {
          cell.write(ch);
        }
      } else if (ch == '"') {
        inQuotes = true;
      } else if (ch == delim) {
        row.add(cell.toString().trim());
        cell.clear();
      } else if (ch == '\n' || ch == '\r') {
        if (ch == '\r' && i + 1 < clean.length && clean[i + 1] == '\n') i++;
        row.add(cell.toString().trim());
        cell.clear();
        rows.add(row);
        row = <String>[];
      } else {
        cell.write(ch);
      }
    }
    if (cell.isNotEmpty || row.isNotEmpty) {
      row.add(cell.toString().trim());
      rows.add(row);
    }
    return rows.where((r) => r.any((c) => c.isNotEmpty)).toList();
  }
}

/// Результат сопоставления: готовые позиции и ошибки по строкам.
class PositionImportResult {
  final List<Position> positions;
  final List<String> errors;

  const PositionImportResult(this.positions, this.errors);
}

/// Сопоставляет колонки по заголовкам (русским и английским) и проверяет каждую строку.
class PositionCsvMapper {
  const PositionCsvMapper._();

  static const Map<String, List<String>> _synonyms = {
    'ticker': ['тикер', 'ticker', 'код', 'secid', 'код бумаги', 'инструмент'],
    'name': ['название', 'наименование', 'name', 'бумага', 'эмитент'],
    'kind': ['тип', 'вид', 'type', 'kind', 'класс'],
    'quantity': ['количество', 'кол-во', 'колво', 'quantity', 'qty', 'шт', 'остаток'],
    'price': ['средняя цена', 'цена покупки', 'цена', 'avg price', 'avg_price', 'price', 'средняя'],
    'note': ['заметка', 'комментарий', 'note', 'описание'],
  };

  static String _norm(String s) => s.toLowerCase().replaceAll('ё', 'е').trim();

  /// Индексы колонок по заголовку; null, если обязательная колонка не найдена.
  static Map<String, int> columns(List<String> header) {
    final out = <String, int>{};
    final normHeader = header.map(_norm).toList();
    _synonyms.forEach((field, names) {
      for (var i = 0; i < normHeader.length; i++) {
        if (names.contains(normHeader[i])) {
          out[field] = i;
          break;
        }
      }
    });
    return out;
  }

  static PositionKind kindOf(String raw) {
    final t = _norm(raw);
    if (t.contains('облиг')) return PositionKind.bond;
    if (t.contains('акци') || t.contains('stock') || t.contains('share')) return PositionKind.stock;
    if (t.contains('фонд') || t.contains('бпиф') || t.contains('etf')) return PositionKind.fund;
    if (t.contains('золот') || t.contains('gold') || t.contains('металл')) return PositionKind.gold;
    if (t.contains('валют') || t.contains('currency')) return PositionKind.currency;
    if (t.contains('деньг') || t.contains('кэш') || t.contains('cash') || t.contains('рубл')) return PositionKind.cash;
    return PositionKind.other;
  }

  /// Числа в российском и английском виде: «1 234,5», «1,234.5», «1234.5».
  static double? number(String raw) {
    var t = raw.replaceAll('\u00A0', '').replaceAll(' ', '').trim();
    if (t.isEmpty) return null;
    if (t.contains(',') && t.contains('.')) {
      t = t.replaceAll(',', '');
    } else {
      t = t.replaceAll(',', '.');
    }
    return double.tryParse(t);
  }

  static PositionImportResult map(List<List<String>> rows) {
    if (rows.isEmpty) {
      return const PositionImportResult([], ['Файл пуст.']);
    }
    final cols = columns(rows.first);
    if (!cols.containsKey('ticker') || !cols.containsKey('quantity') || !cols.containsKey('price')) {
      return const PositionImportResult([], [
        'Не найдены обязательные колонки: тикер (или код), количество и средняя цена (или цена покупки).',
      ]);
    }
    String cell(List<String> r, String field) {
      final i = cols[field];
      return i == null || i >= r.length ? '' : r[i];
    }

    final positions = <Position>[];
    final errors = <String>[];
    for (var n = 1; n < rows.length; n++) {
      final r = rows[n];
      final line = n + 1;
      final ticker = cell(r, 'ticker').toUpperCase();
      final qty = number(cell(r, 'quantity'));
      final price = number(cell(r, 'price'));
      if (ticker.isEmpty) {
        errors.add('Строка $line: не указан тикер.');
        continue;
      }
      if (qty == null || qty <= 0) {
        errors.add('Строка $line ($ticker): количество должно быть числом больше нуля.');
        continue;
      }
      if (price == null || price < 0) {
        errors.add('Строка $line ($ticker): средняя цена должна быть числом не меньше нуля.');
        continue;
      }
      final kindText = cell(r, 'kind');
      final name = cell(r, 'name');
      positions.add(Position(
        ticker: ticker,
        name: name.isEmpty ? ticker : name,
        kind: kindText.isEmpty ? PositionKind.stock : kindOf(kindText),
        quantity: qty,
        avgPrice: price,
        note: cell(r, 'note'),
      ));
    }
    return PositionImportResult(positions, errors);
  }
}
