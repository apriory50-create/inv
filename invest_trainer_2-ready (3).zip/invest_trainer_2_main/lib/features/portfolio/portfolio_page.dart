import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/share/share_service.dart';
import '../../core/share/share_texts.dart';
import 'ai_advisor_sheet.dart';
import '../../domain/risk/stress_test.dart';
import '../../core/files/file_text_picker.dart';
import '../planning/checklist_sheet.dart';
import '../planning/goal_planner_page.dart';
import '../planning/templates_page.dart';
import 'csv_import.dart';
import 'devil_advocate_sheet.dart';
import 'quotes_service.dart';
import 'portfolio_models.dart';
import 'portfolio_repository.dart';

class PortfolioPage extends ConsumerWidget {
  const PortfolioPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final positions = ref.watch(positionsProvider);
    return positions.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('Не удалось открыть базу данных портфеля. Перезапустите приложение.\n$e'),
        ),
      ),
      data: (list) => _Content(positions: list),
    );
  }
}

class _Content extends ConsumerWidget {
  const _Content({required this.positions});

  final List<Position> positions;

  Future<void> _add(BuildContext context, WidgetRef ref) async {
    final result = await showDialog<Position>(
      context: context,
      builder: (_) => const _PositionDialog(),
    );
    if (result == null) return;
    final repo = await ref.read(portfolioRepositoryProvider.future);
    await repo.add(result);
    ref.invalidate(positionsProvider);
  }

  void _stressTest(BuildContext context, WidgetRef ref) {
    final quotes = ref.read(quotesProvider);
    final sp = [
      for (final p in positions)
        StressPosition(
          ticker: p.ticker,
          kind: p.kind,
          value: PortfolioMath.currentValue(p, quotes) ?? p.cost,
        ),
    ];
    final results = PortfolioStress.runAll(sp);
    final total = sp.fold<double>(0, (s, p) => s + p.value);
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Стресс-тест портфеля'),
        content: SizedBox(
          width: 480,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Стоимость портфеля для расчёта: ${total.toStringAsFixed(0)} ₽'),
                const SizedBox(height: 10),
                for (final r in results)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(r.scenario.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                          Text(r.scenario.description),
                          const SizedBox(height: 4),
                          Text(
                            'Изменение: ${r.changeRub >= 0 ? '+' : ''}${r.changeRub.toStringAsFixed(0)} ₽ '
                            '(${r.changePct >= 0 ? '+' : ''}${r.changePct.toStringAsFixed(1)}%)',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: r.changeRub < 0 ? Colors.red.shade700 : Colors.green.shade700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                const SizedBox(height: 6),
                const Text('Допущения модели:', style: TextStyle(fontWeight: FontWeight.bold)),
                for (final a in PortfolioStress.assumptions) Text('• $a'),
                const SizedBox(height: 8),
                const Text('Учебная модель, а не прогноз. Решения за вами.'),
              ],
            ),
          ),
        ),
        actions: [
          FilledButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Понятно')),
        ],
      ),
    );
  }

  String _quoteLine(Position p, QuotesState q) {
    final v = PortfolioMath.currentValue(p, q);
    if (v == null) return '';
    final pnl = v - p.cost;
    final price = q.priceOf(p.ticker)!;
    return '\nТекущая цена: ${price.toStringAsFixed(2)} (результат ${pnl >= 0 ? '+' : ''}${pnl.toStringAsFixed(2)})';
  }

  Future<void> _importCsv(BuildContext context, WidgetRef ref) async {
    final controller = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Импорт портфеля из CSV'),
        content: SizedBox(
          width: 480,
          child: TextField(
            controller: controller,
            minLines: 6,
            maxLines: 12,
            decoration: const InputDecoration(
              labelText: 'Вставьте содержимое CSV',
              helperText: 'Колонки: тикер (или код), название, тип, количество, средняя цена (или цена покупки), заметка. Разделитель ; или ,',
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Отмена')),
          TextButton(
            onPressed: () async {
              try {
                final picked = await FileTextPicker.pick(extensions: const ['csv', 'txt']);
                if (picked != null) controller.text = picked.text;
              } on FormatException catch (e) {
                if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text(e.message)));
              }
            },
            child: const Text('Выбрать файл'),
          ),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(controller.text), child: const Text('Проверить')),
        ],
      ),
    );
    controller.dispose();
    if (text == null || text.trim().isEmpty || !context.mounted) return;

    final result = PositionCsvMapper.map(CsvParser.parse(text));
    if (result.positions.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result.errors.first)));
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Добавить ${result.positions.length} поз.?'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Будут добавлены позиции: ${result.positions.map((p) => p.ticker).join(', ')}.'),
              if (result.errors.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text('Пропущено строк: ${result.errors.length}', style: const TextStyle(fontWeight: FontWeight.bold)),
                for (final e in result.errors.take(8)) Text('• $e'),
                if (result.errors.length > 8) Text('…и ещё ${result.errors.length - 8}'),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Добавить')),
        ],
      ),
    );
    if (ok != true) return;
    final repo = await ref.read(portfolioRepositoryProvider.future);
    for (final p in result.positions) {
      await repo.add(p);
    }
    ref.invalidate(positionsProvider);
  }

  Future<void> _confirmRemove(BuildContext context, WidgetRef ref, Position p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить позицию?'),
        content: Text('${p.ticker} — ${p.name} будет удалена из портфеля.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Удалить')),
        ],
      ),
    );
    if (ok == true) await _remove(ref, p);
  }

  Future<void> _remove(WidgetRef ref, Position p) async {
    final id = p.id;
    if (id == null) return;
    final repo = await ref.read(portfolioRepositoryProvider.future);
    await repo.remove(id);
    ref.invalidate(positionsProvider);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final total = positions.fold<double>(0, (s, p) => s + p.cost);
    final quotes = ref.watch(quotesProvider);
    final market = PortfolioMath.marketValue(positions, quotes);
    final byKind = <PositionKind, double>{};
    for (final p in positions) {
      byKind[p.kind] = (byKind[p.kind] ?? 0) + p.cost;
    }

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            FilledButton.icon(
              onPressed: () => _add(context, ref),
              icon: const Icon(Icons.add),
              label: const Text('Добавить бумагу'),
            ),
            OutlinedButton.icon(
              onPressed: () => showModalBottomSheet<void>(
                context: context,
                isScrollControlled: true,
                useSafeArea: true,
                builder: (_) => const ChecklistSheet(),
              ),
              icon: const Icon(Icons.checklist),
              label: const Text('Чек-лист покупки'),
            ),
            OutlinedButton.icon(
              onPressed: () => showModalBottomSheet<void>(
                context: context,
                isScrollControlled: true,
                useSafeArea: true,
                builder: (_) => const DevilAdvocateSheet(),
              ),
              icon: const Icon(Icons.gavel),
              label: const Text('Адвокат дьявола'),
            ),
            OutlinedButton.icon(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const TemplatesPage())),
              icon: const Icon(Icons.dashboard_customize_outlined),
              label: const Text('Шаблоны портфелей'),
            ),
            OutlinedButton.icon(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const GoalPlannerPage())),
              icon: const Icon(Icons.flag_outlined),
              label: const Text('Планировщик цели'),
            ),
            OutlinedButton.icon(
              onPressed: positions.isEmpty ? null : () => _stressTest(context, ref),
              icon: const Icon(Icons.warning_amber_outlined),
              label: const Text('Стресс-тест'),
            ),
            OutlinedButton.icon(
              onPressed: () => _importCsv(context, ref),
              icon: const Icon(Icons.upload_file),
              label: const Text('Импорт из CSV'),
            ),
            OutlinedButton.icon(
              onPressed: quotes.loading ? null : () => ref.read(quotesProvider.notifier).refresh(),
              icon: quotes.loading
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.show_chart),
              label: const Text('Котировки MOEX'),
            ),
            OutlinedButton.icon(
              onPressed: () async {
                final messenger = ScaffoldMessenger.of(context);
                final msg = await ShareService.shareText(ShareTexts.portfolioStructure(positions), subject: 'Структура портфеля');
                messenger.showSnackBar(SnackBar(content: Text(msg)));
              },
              icon: const Icon(Icons.ios_share),
              label: const Text('Поделиться структурой'),
            ),
            OutlinedButton.icon(
              onPressed: () => showModalBottomSheet<void>(
                context: context,
                isScrollControlled: true,
                builder: (_) => AiAdvisorSheet(positions: positions),
              ),
              icon: const Icon(Icons.smart_toy_outlined),
              label: const Text('Посоветоваться с ИИ'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (positions.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Здесь будет ваш реальный портфель. Добавьте бумаги вручную: тикер, название, тип, количество и среднюю цену покупки. '
                'Приложение не подключается к брокеру и не совершает сделок.',
              ),
            ),
          )
        else ...[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Структура (по цене покупки)',
                      style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  for (final e in byKind.entries)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${e.key.label}: ${total > 0 ? (e.value / total * 100).toStringAsFixed(1) : '0.0'}%'),
                          const SizedBox(height: 2),
                          LinearProgressIndicator(
                            value: total > 0 ? e.value / total : 0,
                            minHeight: 6,
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ],
                      ),
                    ),
                  Text('Вложено всего: ${total.toStringAsFixed(2)}'),
                  if (market.priced > 0) ...[
                    Text('Стоимость по котировкам: ${market.total.toStringAsFixed(2)} (результат ${market.pnl >= 0 ? '+' : ''}${market.pnl.toStringAsFixed(2)})'),
                    Text('Котировок: ${market.priced}, без котировки (по цене покупки): ${market.unpriced}',
                        style: Theme.of(context).textTheme.bodySmall),
                  ],
                  if (quotes.updatedAt != null)
                    Text('Котировки на ${quotes.updatedAt!.hour.toString().padLeft(2, '0')}:${quotes.updatedAt!.minute.toString().padLeft(2, '0')} (задержка биржи)',
                        style: Theme.of(context).textTheme.bodySmall),
                  if (quotes.error != null)
                    Text(quotes.error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                ],
              ),
            ),
          ),
          for (final p in positions)
            Card(
              child: ListTile(
                title: Text('${p.ticker} — ${p.name}'),
                subtitle: Text(
                  '${p.kind.label} • ${p.quantity} шт. × ${p.avgPrice} ${p.currency}'
                  '${_quoteLine(p, quotes)}'
                  '${p.note.isEmpty ? '' : '\n${p.note}'}',
                ),
                isThreeLine: p.note.isNotEmpty || _quoteLine(p, quotes).isNotEmpty,
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(p.cost.toStringAsFixed(2)),
                    IconButton(
                      tooltip: 'Удалить позицию',
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => _confirmRemove(context, ref, p),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ],
    );
  }
}

class _PositionDialog extends StatefulWidget {
  const _PositionDialog();

  @override
  State<_PositionDialog> createState() => _PositionDialogState();
}

class _PositionDialogState extends State<_PositionDialog> {
  final _ticker = TextEditingController();
  final _name = TextEditingController();
  final _qty = TextEditingController();
  final _price = TextEditingController();
  final _note = TextEditingController();
  PositionKind _kind = PositionKind.stock;
  String? _error;

  @override
  void dispose() {
    _ticker.dispose();
    _name.dispose();
    _qty.dispose();
    _price.dispose();
    _note.dispose();
    super.dispose();
  }

  double? _parse(String s) => double.tryParse(s.trim().replaceAll(',', '.'));

  void _save() {
    final ticker = _ticker.text.trim().toUpperCase();
    final qty = _parse(_qty.text);
    final price = _parse(_price.text);
    if (ticker.isEmpty) {
      setState(() => _error = 'Укажите тикер или короткое название.');
      return;
    }
    if (qty == null || qty <= 0) {
      setState(() => _error = 'Количество должно быть больше нуля.');
      return;
    }
    if (price == null || price < 0) {
      setState(() => _error = 'Укажите среднюю цену покупки (0 или больше).');
      return;
    }
    Navigator.of(context).pop(Position(
      ticker: ticker,
      name: _name.text.trim().isEmpty ? ticker : _name.text.trim(),
      kind: _kind,
      quantity: qty,
      avgPrice: price,
      note: _note.text.trim(),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Новая позиция'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: _ticker, decoration: const InputDecoration(labelText: 'Тикер')),
            const SizedBox(height: 8),
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Название')),
            const SizedBox(height: 8),
            DropdownButtonFormField<PositionKind>(
              value: _kind,
              decoration: const InputDecoration(labelText: 'Тип'),
              items: [
                for (final k in PositionKind.values)
                  DropdownMenuItem(value: k, child: Text(k.label)),
              ],
              onChanged: (v) => setState(() => _kind = v ?? _kind),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _qty,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Количество'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _price,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Средняя цена покупки'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _note,
              decoration: const InputDecoration(labelText: 'Заметка: зачем куплено (необязательно)'),
            ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Отмена')),
        FilledButton(onPressed: _save, child: const Text('Сохранить')),
      ],
    );
  }
}
