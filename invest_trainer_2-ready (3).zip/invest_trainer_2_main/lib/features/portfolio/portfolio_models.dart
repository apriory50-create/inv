import 'package:flutter/foundation.dart';

enum PositionKind {
  stock('Акция'),
  bond('Облигация'),
  fund('Фонд (БПИФ/ETF)'),
  gold('Золото'),
  currency('Валюта'),
  cash('Деньги'),
  other('Другое');

  const PositionKind(this.label);
  final String label;

  static PositionKind fromName(String? name) => PositionKind.values.firstWhere(
        (k) => k.name == name,
        orElse: () => PositionKind.other,
      );
}

@immutable
class Position {
  final int? id;
  final String ticker;
  final String name;
  final PositionKind kind;
  final double quantity;
  final double avgPrice;
  final String currency;
  final String note;

  const Position({
    this.id,
    required this.ticker,
    required this.name,
    required this.kind,
    required this.quantity,
    required this.avgPrice,
    this.currency = 'RUB',
    this.note = '',
  });

  /// Стоимость по цене покупки.
  double get cost => quantity * avgPrice;

  Map<String, Object?> toRow() => {
        if (id != null) 'id': id,
        'ticker': ticker,
        'name': name,
        'kind': kind.name,
        'quantity': quantity,
        'avg_price': avgPrice,
        'currency': currency,
        'note': note,
        'created_at': DateTime.now().millisecondsSinceEpoch,
      };

  factory Position.fromRow(Map<String, Object?> row) => Position(
        id: row['id'] as int?,
        ticker: row['ticker'] as String? ?? '',
        name: row['name'] as String? ?? '',
        kind: PositionKind.fromName(row['kind'] as String?),
        quantity: (row['quantity'] as num?)?.toDouble() ?? 0,
        avgPrice: (row['avg_price'] as num?)?.toDouble() ?? 0,
        currency: row['currency'] as String? ?? 'RUB',
        note: row['note'] as String? ?? '',
      );
}
