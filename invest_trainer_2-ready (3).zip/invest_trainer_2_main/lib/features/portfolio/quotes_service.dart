import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'portfolio_models.dart';

/// Котировки с публичного API Московской биржи (ISS). Только акции и биржевые фонды.
/// Облигации здесь не котируются: их цена в процентах от номинала, и она требует отдельного расчёта.
class MoexQuotes {
  const MoexQuotes._();

  static const String host = 'iss.moex.com';

  /// Режимы торгов: TQBR — акции, TQTF — биржевые фонды.
  static const List<String> boards = ['TQBR', 'TQTF'];

  static Uri url(String board) => Uri.https(
        host,
        '/iss/engines/stock/markets/shares/boards/$board/securities.json',
        {'iss.only': 'marketdata', 'marketdata.columns': 'SECID,LAST,PREVPRICE'},
      );

  /// Разбор ответа ISS: {"marketdata": {"columns": [...], "data": [[...], ...]}}.
  /// Берём LAST, а если торгов не было — PREVPRICE. Бумаги без цены пропускаем.
  static Map<String, double> parse(String body) {
    final Object? decoded;
    try {
      decoded = jsonDecode(body);
    } catch (_) {
      throw const FormatException('Биржа вернула непонятный ответ.');
    }
    if (decoded is! Map) throw const FormatException('Биржа вернула непонятный ответ.');
    final md = decoded['marketdata'];
    if (md is! Map) throw const FormatException('В ответе нет котировок.');
    final columns = [for (final c in (md['columns'] as List? ?? const [])) c.toString()];
    final data = md['data'] as List? ?? const [];
    final iSec = columns.indexOf('SECID');
    final iLast = columns.indexOf('LAST');
    final iPrev = columns.indexOf('PREVPRICE');
    if (iSec < 0) throw const FormatException('В ответе нет кода бумаги.');

    final out = <String, double>{};
    for (final row in data) {
      if (row is! List || row.length <= iSec) continue;
      final secid = row[iSec];
      if (secid is! String || secid.isEmpty) continue;
      double? price;
      if (iLast >= 0 && row.length > iLast && row[iLast] is num) {
        price = (row[iLast] as num).toDouble();
      } else if (iPrev >= 0 && row.length > iPrev && row[iPrev] is num) {
        price = (row[iPrev] as num).toDouble();
      }
      if (price != null && price > 0) out[secid.toUpperCase()] = price;
    }
    return out;
  }
}

@immutable
class QuotesState {
  final Map<String, double> prices;
  final DateTime? updatedAt;
  final String? error;
  final bool loading;

  const QuotesState({this.prices = const {}, this.updatedAt, this.error, this.loading = false});

  /// Текущая цена или null, если котировки нет.
  double? priceOf(String ticker) => prices[ticker.toUpperCase()];

  QuotesState copyWith({Map<String, double>? prices, DateTime? updatedAt, String? error, bool? loading}) =>
      QuotesState(
        prices: prices ?? this.prices,
        updatedAt: updatedAt ?? this.updatedAt,
        error: error,
        loading: loading ?? this.loading,
      );
}

final moexHttpProvider = Provider<Dio>(
  (ref) => Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 10),
    receiveTimeout: const Duration(seconds: 20),
    responseType: ResponseType.plain,
  )),
);

class QuotesController extends Notifier<QuotesState> {
  @override
  QuotesState build() => const QuotesState();

  /// Обновляет котировки. Ошибка не очищает последние известные цены.
  Future<void> refresh() async {
    if (state.loading) return;
    state = state.copyWith(loading: true);
    final dio = ref.read(moexHttpProvider);
    final merged = <String, double>{...state.prices};
    String? error;
    var any = false;
    for (final board in MoexQuotes.boards) {
      try {
        final r = await dio.getUri<String>(MoexQuotes.url(board));
        merged.addAll(MoexQuotes.parse(r.data ?? ''));
        any = true;
      } on DioException {
        error = 'Биржа недоступна. Показаны последние известные цены.';
      } on FormatException catch (e) {
        error = e.message;
      } catch (_) {
        error = 'Не удалось получить котировки.';
      }
    }
    state = QuotesState(
      prices: merged,
      updatedAt: any ? DateTime.now() : state.updatedAt,
      error: error,
      loading: false,
    );
  }
}

final quotesProvider = NotifierProvider<QuotesController, QuotesState>(QuotesController.new);

/// Стоимость позиций по текущим ценам. Позиции без котировки считаются по цене покупки и помечаются.
class MarketValue {
  final double total;
  final double costTotal;
  final int priced;
  final int unpriced;

  const MarketValue({required this.total, required this.costTotal, required this.priced, required this.unpriced});

  double get pnl => total - costTotal;
}

class PortfolioMath {
  const PortfolioMath._();

  static double? currentValue(Position p, QuotesState q) {
    if (p.kind != PositionKind.stock && p.kind != PositionKind.fund) return null;
    final price = q.priceOf(p.ticker);
    return price == null ? null : price * p.quantity;
  }

  static MarketValue marketValue(List<Position> positions, QuotesState q) {
    var total = 0.0;
    var cost = 0.0;
    var priced = 0;
    var unpriced = 0;
    for (final p in positions) {
      cost += p.cost;
      final v = currentValue(p, q);
      if (v == null) {
        total += p.cost;
        unpriced++;
      } else {
        total += v;
        priced++;
      }
    }
    return MarketValue(total: total, costTotal: cost, priced: priced, unpriced: unpriced);
  }
}
