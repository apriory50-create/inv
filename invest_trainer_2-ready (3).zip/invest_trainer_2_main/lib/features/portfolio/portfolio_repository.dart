import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:sqflite/sqflite.dart';

import '../../data/db/app_database.dart';
import 'portfolio_models.dart';

class PortfolioRepository {
  PortfolioRepository(this._db);

  final Database _db;

  Future<List<Position>> all() async {
    final rows = await _db.query('portfolio_positions', orderBy: 'id ASC');
    return rows.map(Position.fromRow).toList();
  }

  Future<int> add(Position position) => _db.insert('portfolio_positions', position.toRow());

  Future<void> update(Position position) async {
    final id = position.id;
    if (id == null) return;
    await _db.update('portfolio_positions', position.toRow(), where: 'id = ?', whereArgs: [id]);
  }

  Future<void> remove(int id) =>
      _db.delete('portfolio_positions', where: 'id = ?', whereArgs: [id]);
}

final portfolioRepositoryProvider = FutureProvider<PortfolioRepository>((ref) async {
  final db = await ref.watch(databaseProvider.future);
  return PortfolioRepository(db);
});

final positionsProvider = FutureProvider.autoDispose<List<Position>>((ref) async {
  final repo = await ref.watch(portfolioRepositoryProvider.future);
  return repo.all();
});
