import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/ai/ai_clients.dart';
import '../../core/ai/ai_models.dart';
import '../../core/ai/ai_profiles_controller.dart';
import '../../core/legal/disclaimer.dart';
import '../../core/security/secure_key_store.dart';
import '../../core/settings/settings_controller.dart';
import 'portfolio_context.dart';
import 'portfolio_models.dart';

/// Системный промт ИИ-советчика (образовательный, осторожный).
const String kAdvisorSystemPrompt =
    'Ты — осторожный образовательный помощник частного инвестора. Объясняй как человеку, который совсем не знает рынок: '
    'простыми словами, с короткими примерами. Опирайся только на данные пользователя и общеизвестные факты; '
    'если данных не хватает — так и скажи. Не выдумывай цифры, тикеры и условия выпусков. '
    'Структура ответа: 1) Краткий вывод (1–2 предложения). 2) Почему (по пунктам, с числами из портфеля). '
    '3) Риски и что может пойти не так. 4) Альтернативы (минимум две). 5) Что проверить самому. '
    '6) Возможные шаги (без гарантий, поэтапно). 7) Оговорка: это образовательная информация, не индивидуальная '
    'инвестиционная рекомендация. Не обещай доходность. Различай факт, мнение и догадку.';

class AiAdvisorSheet extends ConsumerStatefulWidget {
  const AiAdvisorSheet({super.key, required this.positions});

  final List<Position> positions;

  @override
  ConsumerState<AiAdvisorSheet> createState() => _AiAdvisorSheetState();
}

class _AiAdvisorSheetState extends ConsumerState<AiAdvisorSheet> {
  final _question = TextEditingController();
  CancelToken? _cancel;
  bool _loading = false;
  String? _answer;
  String? _error;

  static const _quick = <String>[
    'Что в моем портфеле самое рискованное?',
    'Что будет с портфелем при росте ключевой ставки?',
    'Как улучшить диверсификацию?',
    'Проверь портфель по чек-листу: что я мог упустить?',
  ];

  @override
  void dispose() {
    _cancel?.cancel();
    _question.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _question.text.trim();
    if (text.isEmpty || _loading) return;
    final profile = ref.read(aiProfilesProvider).active;
    if (profile == null) return;

    setState(() {
      _loading = true;
      _error = null;
      _answer = null;
    });
    final cancel = CancelToken();
    _cancel = cancel;
    try {
      final key = await ref.read(secureKeyStoreProvider).readKey(profile.id) ?? '';
      if (!mounted) return;
      final includeAmounts = ref.read(settingsProvider).sendAmountsToAi;
      final portfolioText = PortfolioContext.build(widget.positions, includeAmounts: includeAmounts);
      final client = AiClientFactory.create(profile, key);
      final reply = await client.chat(
        [
          const AiMessage.system(kAdvisorSystemPrompt),
          AiMessage.user('$portfolioText\n\nВопрос: $text'),
        ],
        cancelToken: cancel,
      );
      if (!mounted) return;
      setState(() => _answer = reply);
    } on AiException catch (e) {
      if (!mounted) return;
      setState(() => _error = e.message);
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'Не удалось получить ответ. Проверьте настройки ИИ.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final profile = ref.watch(aiProfilesProvider).active;
    final includeAmounts = ref.watch(settingsProvider).sendAmountsToAi;
    final bottom = MediaQuery.of(context).viewInsets.bottom;

    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Посоветоваться с ИИ', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 6),
            if (profile == null)
              const Text(
                'Сначала подключите ИИ: Настройки → Подключения ИИ → добавить профиль и ключ API.',
              )
            else ...[
              Text('Профиль: ${profile.name} • ${profile.model}',
                  style: Theme.of(context).textTheme.bodySmall),
              Text(
                includeAmounts
                    ? 'В ИИ уйдут названия, доли и суммы.'
                    : 'В ИИ уйдут названия и доли в процентах (без сумм).',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  for (final q in _quick)
                    ActionChip(label: Text(q), onPressed: () => setState(() => _question.text = q)),
                ],
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _question,
                minLines: 2,
                maxLines: 5,
                decoration: const InputDecoration(labelText: 'Ваш вопрос'),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  FilledButton.icon(
                    onPressed: _loading ? null : _send,
                    icon: const Icon(Icons.send),
                    label: const Text('Спросить'),
                  ),
                  const SizedBox(width: 12),
                  if (_loading)
                    TextButton(
                      onPressed: () => _cancel?.cancel(),
                      child: const Text('Отмена'),
                    ),
                  if (_loading)
                    const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                ],
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
              if (_answer != null) ...[
                const SizedBox(height: 12),
                const Text('Мнение ИИ:', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                SelectableText(_answer!),
              ],
            ],
            const SizedBox(height: 12),
            Text(Disclaimer.short, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}
