import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/ai/ai_clients.dart';
import '../../core/ai/ai_models.dart';
import '../../core/ai/ai_profiles_controller.dart';
import '../../core/legal/disclaimer.dart';
import '../../core/security/secure_key_store.dart';
import '../../core/settings/settings_controller.dart';
import 'devil_advocate.dart';
import 'portfolio_models.dart';
import 'portfolio_repository.dart';

/// Адвокат дьявола: опишите идею, ИИ найдёт сильнейшие аргументы против неё.
class DevilAdvocateSheet extends ConsumerStatefulWidget {
  const DevilAdvocateSheet({super.key});

  @override
  ConsumerState<DevilAdvocateSheet> createState() => _DevilAdvocateSheetState();
}

class _DevilAdvocateSheetState extends ConsumerState<DevilAdvocateSheet> {
  final _idea = TextEditingController();
  CancelToken? _cancel;
  bool _loading = false;
  String? _answer;
  String? _error;

  @override
  void dispose() {
    _cancel?.cancel();
    _idea.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final text = _idea.text.trim();
    if (text.isEmpty || _loading) return;
    // Обработчик нажатия: только read.
    final profile = ref.read(aiProfilesProvider).active;
    if (profile == null) {
      setState(() => _error = 'Сначала подключите ИИ: Настройки → Подключения ИИ.');
      return;
    }
    final positions = ref.read(positionsProvider).valueOrNull ?? const <Position>[];
    final includeAmounts = ref.read(settingsProvider).sendAmountsToAi;
    setState(() {
      _loading = true;
      _error = null;
      _answer = null;
    });
    final cancel = CancelToken();
    _cancel = cancel;
    try {
      final key = await ref.read(secureKeyStoreProvider).readKey(profile.id) ?? '';
      final client = AiClientFactory.create(profile, key);
      final reply = await client.chat(
        DevilAdvocate.buildMessages(idea: text, positions: positions, includeAmounts: includeAmounts),
        cancelToken: cancel,
      );
      if (!mounted) return;
      setState(() => _answer = reply);
    } on AiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'Не удалось получить ответ. Проверьте настройки ИИ.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final profile = ref.watch(aiProfilesProvider).active;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 12, 16, 12 + MediaQuery.of(context).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Адвокат дьявола', style: theme.textTheme.titleLarge),
              const SizedBox(height: 4),
              const Text('Опишите свою идею. ИИ найдёт сильнейшие аргументы против неё, чтобы вы проверили решение.'),
              const SizedBox(height: 6),
              Text(profile == null ? 'ИИ не подключён.' : 'Профиль: ${profile.name} • ${profile.model}',
                  style: theme.textTheme.bodySmall),
              const SizedBox(height: 8),
              TextField(
                controller: _idea,
                minLines: 3,
                maxLines: 6,
                decoration: const InputDecoration(
                  labelText: 'Ваша идея',
                  hintText: 'Например: куплю отраслевой фонд нефти, потому что нефть подорожала',
                ),
              ),
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: _loading ? null : _run,
                icon: _loading
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.gavel),
                label: const Text('Найти аргументы против'),
              ),
              if (_error != null) ...[
                const SizedBox(height: 8),
                Text(_error!, style: TextStyle(color: theme.colorScheme.error)),
              ],
              if (_answer != null) ...[
                const SizedBox(height: 10),
                Card(child: Padding(padding: const EdgeInsets.all(12), child: SelectableText(_answer!))),
              ],
              const SizedBox(height: 8),
              Text(Disclaimer.short, style: theme.textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}
