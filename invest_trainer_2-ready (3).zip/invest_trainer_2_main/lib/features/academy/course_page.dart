import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../lessons_data.dart';
import '../../models.dart';
import 'lesson_page.dart';
import 'progress_repository.dart';

enum _Filter { all, todo, review, bookmarks }

/// Курс: поиск, фильтры, группировка по модулям, прогресс и кнопка «Продолжить».
class CoursePage extends ConsumerStatefulWidget {
  const CoursePage({super.key});

  @override
  ConsumerState<CoursePage> createState() => _CoursePageState();
}

class _CoursePageState extends ConsumerState<CoursePage> {
  String _query = '';
  _Filter _filter = _Filter.all;

  void _open(int lessonId) {
    Navigator.of(context, rootNavigator: true).push(
      MaterialPageRoute<void>(builder: (_) => LessonPage(lessonId: lessonId)),
    );
  }

  bool _matches(AcademyLesson l, ProgressState progress) {
    final lp = progress.of(l.id);
    switch (_filter) {
      case _Filter.all:
        break;
      case _Filter.todo:
        if (lp?.completed ?? false) return false;
      case _Filter.review:
        if (!(lp?.needsReview ?? false)) return false;
      case _Filter.bookmarks:
        if (!progress.isBookmarked(l.id)) return false;
    }
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return true;
    return l.title.toLowerCase().contains(q) ||
        l.category.toLowerCase().contains(q) ||
        l.moduleTitle.toLowerCase().contains(q) ||
        l.content.toLowerCase().contains(q);
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(progressProvider);
    final progress = async.valueOrNull ?? const ProgressState();
    final lessons = LessonsData.allLessons;
    final theme = Theme.of(context);

    AcademyLesson? next;
    for (final l in lessons) {
      if (!(progress.of(l.id)?.completed ?? false)) {
        next = l;
        break;
      }
    }

    final AcademyLesson? nextLesson = next;

    // Группировка по модулям с сохранением порядка.
    final modules = <int, List<AcademyLesson>>{};
    final titles = <int, String>{};
    for (final l in lessons) {
      modules.putIfAbsent(l.moduleId, () => []).add(l);
      titles.putIfAbsent(l.moduleId, () => l.moduleTitle);
    }
    final filtering = _query.trim().isNotEmpty || _filter != _Filter.all;

    final total = lessons.length;
    final done = progress.completedCount;

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Пройдено: $done из $total', style: theme.textTheme.titleMedium),
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: total == 0 ? 0 : done / total,
                  minHeight: 8,
                  borderRadius: BorderRadius.circular(4),
                ),
                if (async.hasError) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Прогресс не сохраняется: не удалось открыть базу данных.',
                    style: TextStyle(color: theme.colorScheme.error),
                  ),
                ],
                const SizedBox(height: 10),
                if (nextLesson != null)
                  FilledButton.icon(
                    onPressed: () => _open(nextLesson.id),
                    icon: const Icon(Icons.play_arrow),
                    label: Text(done == 0 ? 'Начать с урока 1' : 'Продолжить: урок ${nextLesson.id}'),
                  )
                else
                  const Text('Все уроки пройдены. Отличная работа!'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            hintText: 'Поиск по урокам и терминам',
          ),
          onChanged: (v) => setState(() => _query = v),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: [
            for (final f in _Filter.values)
              ChoiceChip(
                label: Text(switch (f) {
                  _Filter.all => 'Все',
                  _Filter.todo => 'Не пройдены',
                  _Filter.review => 'Работа над ошибками',
                  _Filter.bookmarks => 'Закладки',
                }),
                selected: _filter == f,
                onSelected: (_) => setState(() => _filter = f),
              ),
          ],
        ),
        const SizedBox(height: 8),
        for (final entry in modules.entries)
          _ModuleTile(
            key: ValueKey('mod-${entry.key}-${_filter.name}-$filtering'),
            title: titles[entry.key] ?? 'Модуль',
            lessons: entry.value.where((l) => _matches(l, progress)).toList(),
            totalInModule: entry.value.length,
            progress: progress,
            initiallyExpanded: filtering || (nextLesson != null && nextLesson.moduleId == entry.key),
            onOpen: _open,
          ),
      ],
    );
  }
}

class _ModuleTile extends StatelessWidget {
  const _ModuleTile({
    super.key,
    required this.title,
    required this.lessons,
    required this.totalInModule,
    required this.progress,
    required this.initiallyExpanded,
    required this.onOpen,
  });

  final String title;
  final List<AcademyLesson> lessons;
  final int totalInModule;
  final ProgressState progress;
  final bool initiallyExpanded;
  final ValueChanged<int> onOpen;

  @override
  Widget build(BuildContext context) {
    if (lessons.isEmpty) return const SizedBox.shrink();
    final doneInModule = lessons.where((l) => progress.of(l.id)?.completed ?? false).length;
    return Card(
      child: ExpansionTile(
        initiallyExpanded: initiallyExpanded,
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('Уроков: ${lessons.length} • пройдено: $doneInModule'),
        children: [
          for (final l in lessons)
            ListTile(
              dense: true,
              title: Text(l.title),
              subtitle: Text('${l.category} • ${l.readingTimeMinutes} мин'),
              leading: _statusIcon(progress.of(l.id)),
              trailing: progress.isBookmarked(l.id) ? const Icon(Icons.bookmark, size: 18) : null,
              onTap: () => onOpen(l.id),
            ),
        ],
      ),
    );
  }

  Widget _statusIcon(LessonProgress? lp) {
    if (lp == null || lp.attempts == 0) {
      return const Icon(Icons.radio_button_unchecked, color: Colors.grey);
    }
    if (lp.completed && lp.lastCorrect) {
      return const Icon(Icons.check_circle, color: Colors.green);
    }
    if (lp.completed) {
      return const Icon(Icons.check_circle_outline, color: Colors.orange);
    }
    return const Icon(Icons.error_outline, color: Colors.red);
  }
}
