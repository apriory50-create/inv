/// Термин глоссария. [pattern] — фрагмент регулярного выражения (без групп захвата),
/// по которому термин находится в тексте уроков с учетом окончаний.
class GlossaryEntry {
  final String term;
  final String meaning;
  final String pattern;

  const GlossaryEntry(this.term, this.meaning, this.pattern);
}
