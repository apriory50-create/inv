import 'package:flutter/material.dart';

import '../../academy_screen.dart';
import '../../calculators_screen.dart';
import '../../pro_filters_screen.dart';
import '../../section_tabs.dart';
import 'course_page.dart';
import 'glossary_page.dart';

/// Раздел «Академия»: основы, курс с прогрессом, глоссарий, калькуляторы и фильтры.
class AcademyPage extends StatelessWidget {
  const AcademyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SectionTabs(
      labels: ['Курс', 'Основы', 'Глоссарий', 'Калькуляторы', '5 фильтров'],
      children: [CoursePage(), AcademyScreen(), GlossaryPage(), CalculatorsScreen(), ProFiltersScreen()],
    );
  }
}
