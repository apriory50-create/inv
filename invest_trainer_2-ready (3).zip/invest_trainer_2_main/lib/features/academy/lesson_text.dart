import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'glossary_matcher.dart';
import 'glossary_entry.dart';

enum LessonBlockKind { header, bullet, paragraph }

class LessonBlock {
  final LessonBlockKind kind;
  final String text;
  final int indent;

  const LessonBlock(this.kind, this.text, {this.indent = 0});
}

const List<String> _headerMarkers = ['📖', '📚', '🟢', '🔴', '🕵', '🧮', '📋', '⚠', '🎯', '🟡', '📌'];

/// Разбирает текст урока на блоки: заголовки разделов, пункты и абзацы.
List<LessonBlock> parseLessonContent(String content) {
  final blocks = <LessonBlock>[];
  for (final raw in content.split('\n')) {
    final trimmed = raw.trim();
    if (trimmed.isEmpty) continue;
    final indent = raw.length - raw.trimLeft().length >= 2 ? 1 : 0;
    if (_headerMarkers.any((m) => trimmed.startsWith(m))) {
      blocks.add(LessonBlock(LessonBlockKind.header, trimmed));
    } else if (trimmed.startsWith('•')) {
      blocks.add(LessonBlock(LessonBlockKind.bullet, trimmed.substring(1).trim(), indent: indent));
    } else if (trimmed.startsWith('- ')) {
      blocks.add(LessonBlock(LessonBlockKind.bullet, trimmed.substring(2).trim(), indent: indent));
    } else {
      blocks.add(LessonBlock(LessonBlockKind.paragraph, trimmed, indent: indent));
    }
  }
  return blocks;
}

/// Текст урока: заголовки, пункты, выделение **жирным** и подсвеченные термины,
/// по нажатию на которые показывается объяснение.
class RichLessonText extends StatefulWidget {
  const RichLessonText({super.key, required this.content, required this.matcher});

  final String content;
  final GlossaryMatcher matcher;

  @override
  State<RichLessonText> createState() => _RichLessonTextState();
}

class _RichLessonTextState extends State<RichLessonText> {
  final List<TapGestureRecognizer> _recognizers = [];

  void _clear() {
    for (final r in _recognizers) {
      r.dispose();
    }
    _recognizers.clear();
  }

  @override
  void dispose() {
    _clear();
    super.dispose();
  }

  void _showTerm(GlossaryEntry entry) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(entry.term),
        content: Text(entry.meaning),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Понятно')),
        ],
      ),
    );
  }

  List<InlineSpan> _glossarySpans(String text, TextStyle style, Set<int> seen, Color linkColor) {
    final spans = <InlineSpan>[];
    var pos = 0;
    for (final m in widget.matcher.find(text)) {
      // Каждый термин подсвечиваем только при первом упоминании в уроке.
      if (!seen.add(m.index)) continue;
      if (m.start > pos) {
        spans.add(TextSpan(text: text.substring(pos, m.start), style: style));
      }
      final rec = TapGestureRecognizer()..onTap = () => _showTerm(m.entry);
      _recognizers.add(rec);
      spans.add(TextSpan(
        text: text.substring(m.start, m.end),
        style: style.copyWith(
          color: linkColor,
          decoration: TextDecoration.underline,
          decorationStyle: TextDecorationStyle.dotted,
        ),
        recognizer: rec,
      ));
      pos = m.end;
    }
    if (pos < text.length) {
      spans.add(TextSpan(text: text.substring(pos), style: style));
    }
    return spans;
  }

  List<InlineSpan> _inline(String text, TextStyle base, Set<int> seen, Color linkColor) {
    final spans = <InlineSpan>[];
    final parts = text.split('**');
    for (var i = 0; i < parts.length; i++) {
      final style = i.isOdd ? base.copyWith(fontWeight: FontWeight.bold) : base;
      spans.addAll(_glossarySpans(parts[i], style, seen, linkColor));
    }
    return spans;
  }

  @override
  Widget build(BuildContext context) {
    _clear();
    final theme = Theme.of(context);
    final base = theme.textTheme.bodyMedium!.copyWith(fontSize: 15, height: 1.45);
    final linkColor = theme.colorScheme.primary;
    final seen = <int>{};
    final children = <Widget>[];

    for (final b in parseLessonContent(widget.content)) {
      switch (b.kind) {
        case LessonBlockKind.header:
          children.add(Padding(
            padding: const EdgeInsets.only(top: 16, bottom: 4),
            child: Text(
              b.text,
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: theme.colorScheme.primary,
              ),
            ),
          ));
        case LessonBlockKind.bullet:
          children.add(Padding(
            padding: EdgeInsets.only(left: 8.0 + b.indent * 18, top: 3),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('•  ', style: base),
                Expanded(child: Text.rich(TextSpan(children: _inline(b.text, base, seen, linkColor)))),
              ],
            ),
          ));
        case LessonBlockKind.paragraph:
          children.add(Padding(
            padding: EdgeInsets.only(left: b.indent * 18.0, top: 4),
            child: Text.rich(TextSpan(children: _inline(b.text, base, seen, linkColor))),
          ));
      }
    }

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: children);
  }
}
