import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../lessons_data.dart';
import '../../models.dart';
import 'glossary_data.dart';
import 'glossary_matcher.dart';
import 'lesson_text.dart';
import 'progress_repository.dart';

final GlossaryMatcher _matcher = GlossaryMatcher(kGlossary);

/// Страница урока: текст с подсветкой терминов, ключевые правила, тест, заметка, закладка.
class LessonPage extends ConsumerStatefulWidget {
  const LessonPage({super.key, required this.lessonId});

  final int lessonId;

  @override
  ConsumerState<LessonPage> createState() => _LessonPageState();
}

class _LessonPageState extends ConsumerState<LessonPage> {
  bool _retry = false;
  int? _localChosen;

  List<AcademyLesson> get _all => LessonsData.allLessons;

  int get _index => _all.indexWhere((l) => l.id == widget.lessonId);

  void _open(AcademyLesson l) {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(builder: (_) => LessonPage(lessonId: l.id)),
    );
  }

  Future<void> _answer(AcademyLesson lesson, int chosen) async {
    setState(() {
      _localChosen = chosen;
      _retry = false;
    });
    try {
      await ref
          .read(progressProvider.notifier)
          .recordAnswer(lesson.id, chosen, chosen == lesson.correctOptionIndex);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Не удалось сохранить результат на устройстве.')),
      );
    }
  }

  Future<void> _editNote(int lessonId, String current) async {
    final controller = TextEditingController(text: current);
    final saved = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Моя заметка к уроку'),
        content: SizedBox(
          width: 440,
          child: TextField(
            controller: controller,
            minLines: 4,
            maxLines: 10,
            autofocus: true,
            decoration: const InputDecoration(hintText: 'Что важно запомнить?'),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Отмена')),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(controller.text),
            child: const Text('Сохранить'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (saved == null) return;
    final repo = await ref.read(progressRepositoryProvider.future);
    await repo.saveNote(lessonId, saved);
    ref.invalidate(lessonNoteProvider(lessonId));
  }

  @override
  Widget build(BuildContext context) {
    final idx = _index;
    if (idx < 0) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text('Урок не найден.')));
    }
    final lesson = _all[idx];
    final progress = ref.watch(progressProvider).valueOrNull ?? const ProgressState();
    final lp = progress.of(lesson.id);
    final bookmarked = progress.isBookmarked(lesson.id);
    final note = ref.watch(lessonNoteProvider(lesson.id)).valueOrNull ?? '';
    final theme = Theme.of(context);

    final chosen = _retry ? _localChosen : (_localChosen ?? lp?.lastAnswer);
    final answered = chosen != null && !_retry;

    return Scaffold(
      appBar: AppBar(
        title: Text('Урок ${lesson.id} из ${_all.last.id}'),
        actions: [
          IconButton(
            tooltip: 'Заметка',
            icon: Icon(note.isEmpty ? Icons.edit_note : Icons.sticky_note_2),
            onPressed: () => _editNote(lesson.id, note),
          ),
          IconButton(
            tooltip: bookmarked ? 'Убрать из закладок' : 'В закладки',
            icon: Icon(bookmarked ? Icons.bookmark : Icons.bookmark_border),
            onPressed: () => ref.read(progressProvider.notifier).toggleBookmark(lesson.id),
          ),
        ],
      ),
      body: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 860),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
            children: [
              Text(lesson.title, style: theme.textTheme.headlineSmall),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  Chip(label: Text(lesson.moduleTitle)),
                  Chip(label: Text(lesson.category)),
                  Chip(avatar: const Icon(Icons.schedule, size: 16), label: Text('${lesson.readingTimeMinutes} мин')),
                  if (lp?.completed ?? false)
                    const Chip(avatar: Icon(Icons.check_circle, size: 16, color: Colors.green), label: Text('Пройден')),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                'Подчёркнутые слова — термины: нажмите, чтобы увидеть объяснение.',
                style: theme.textTheme.bodySmall,
              ),
              RichLessonText(content: lesson.content, matcher: _matcher),
              const SizedBox(height: 16),
              Card(
                color: theme.colorScheme.secondaryContainer,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Главное — три правила', style: theme.textTheme.titleMedium),
                      const SizedBox(height: 6),
                      for (final r in lesson.keyRules)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text('• $r'),
                        ),
                    ],
                  ),
                ),
              ),
              if (note.isNotEmpty) ...[
                const SizedBox(height: 12),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.sticky_note_2_outlined),
                    title: const Text('Моя заметка'),
                    subtitle: Text(note),
                    onTap: () => _editNote(lesson.id, note),
                  ),
                ),
              ],
              const SizedBox(height: 16),
              _Quiz(
                lesson: lesson,
                chosen: answered ? chosen : null,
                onAnswer: (i) => _answer(lesson, i),
                onRetry: () => setState(() {
                  _retry = true;
                  _localChosen = null;
                }),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  if (idx > 0)
                    OutlinedButton.icon(
                      onPressed: () => _open(_all[idx - 1]),
                      icon: const Icon(Icons.chevron_left),
                      label: const Text('Назад'),
                    ),
                  const Spacer(),
                  if (idx < _all.length - 1)
                    FilledButton.icon(
                      onPressed: () => _open(_all[idx + 1]),
                      icon: const Icon(Icons.chevron_right),
                      label: const Text('Дальше'),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Quiz extends StatelessWidget {
  const _Quiz({
    required this.lesson,
    required this.chosen,
    required this.onAnswer,
    required this.onRetry,
  });

  final AcademyLesson lesson;
  final int? chosen;
  final ValueChanged<int> onAnswer;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final answered = chosen != null;
    final correct = chosen == lesson.correctOptionIndex;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Проверь себя', style: theme.textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(lesson.question, style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            for (var i = 0; i < lesson.options.length; i++)
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(
                  !answered
                      ? Icons.radio_button_unchecked
                      : i == lesson.correctOptionIndex
                          ? Icons.check_circle
                          : (i == chosen ? Icons.cancel : Icons.radio_button_unchecked),
                  color: !answered
                      ? null
                      : i == lesson.correctOptionIndex
                          ? Colors.green
                          : (i == chosen ? Colors.red : null),
                ),
                title: Text(lesson.options[i]),
                onTap: answered ? null : () => onAnswer(i),
              ),
            if (answered) ...[
              const SizedBox(height: 6),
              Text(
                correct ? 'Верно!' : 'Пока неверно. Перечитайте разбор ниже.',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: correct ? Colors.green : Colors.red,
                ),
              ),
              const SizedBox(height: 4),
              Text('Разбор: ${lesson.explanation}'),
              TextButton(onPressed: onRetry, child: const Text('Ответить заново')),
            ],
          ],
        ),
      ),
    );
  }
}
