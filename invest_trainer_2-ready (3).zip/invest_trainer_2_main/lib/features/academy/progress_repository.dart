import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:sqflite/sqflite.dart';

import '../../data/db/app_database.dart';

/// Результат работы пользователя с уроком.
@immutable
class LessonProgress {
  final int lessonId;

  /// Тест пройден верно хотя бы раз.
  final bool completed;
  final int? lastAnswer;
  final bool lastCorrect;
  final int attempts;

  const LessonProgress({
    required this.lessonId,
    this.completed = false,
    this.lastAnswer,
    this.lastCorrect = false,
    this.attempts = 0,
  });

  /// Последний ответ был неверным — урок попадает в «работу над ошибками».
  bool get needsReview => attempts > 0 && !lastCorrect;
}

class ProgressRepository {
  ProgressRepository(this._db);

  final Database _db;

  Future<Map<int, LessonProgress>> allProgress() async {
    final rows = await _db.query('lesson_progress');
    return {
      for (final r in rows)
        (r['lesson_id'] as int): LessonProgress(
          lessonId: r['lesson_id'] as int,
          completed: r['completed'] == 1,
          lastAnswer: r['last_answer'] as int?,
          lastCorrect: r['last_correct'] == 1,
          attempts: (r['attempts'] as int?) ?? 0,
        ),
    };
  }

  Future<void> recordAnswer({
    required int lessonId,
    required int chosen,
    required bool correct,
  }) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final rows = await _db.query(
      'lesson_progress',
      where: 'lesson_id = ?',
      whereArgs: [lessonId],
      limit: 1,
    );
    if (rows.isEmpty) {
      await _db.insert('lesson_progress', {
        'lesson_id': lessonId,
        'completed': correct ? 1 : 0,
        'best_score': correct ? 1 : 0,
        'last_answer': chosen,
        'last_correct': correct ? 1 : 0,
        'attempts': 1,
        'updated_at': now,
      });
    } else {
      final r = rows.first;
      final wasCompleted = r['completed'] == 1;
      final attempts = (r['attempts'] as int?) ?? 0;
      await _db.update(
        'lesson_progress',
        {
          'completed': (wasCompleted || correct) ? 1 : 0,
          'best_score': (wasCompleted || correct) ? 1 : 0,
          'last_answer': chosen,
          'last_correct': correct ? 1 : 0,
          'attempts': attempts + 1,
          'updated_at': now,
        },
        where: 'lesson_id = ?',
        whereArgs: [lessonId],
      );
    }
  }

  Future<Set<int>> allBookmarks() async {
    final rows = await _db.query('bookmarks');
    return {for (final r in rows) r['lesson_id'] as int};
  }

  Future<void> setBookmark(int lessonId, bool on) async {
    if (on) {
      await _db.insert(
        'bookmarks',
        {'lesson_id': lessonId, 'created_at': DateTime.now().millisecondsSinceEpoch},
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } else {
      await _db.delete('bookmarks', where: 'lesson_id = ?', whereArgs: [lessonId]);
    }
  }

  Future<String> note(int lessonId) async {
    final rows = await _db.query(
      'lesson_notes',
      where: 'lesson_id = ?',
      whereArgs: [lessonId],
      limit: 1,
    );
    return rows.isEmpty ? '' : (rows.first['body'] as String? ?? '');
  }

  Future<void> saveNote(int lessonId, String body) async {
    final text = body.trim();
    if (text.isEmpty) {
      await _db.delete('lesson_notes', where: 'lesson_id = ?', whereArgs: [lessonId]);
      return;
    }
    await _db.insert(
      'lesson_notes',
      {
        'lesson_id': lessonId,
        'body': text,
        'updated_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }
}

final progressRepositoryProvider = FutureProvider<ProgressRepository>((ref) async {
  final db = await ref.watch(databaseProvider.future);
  return ProgressRepository(db);
});

@immutable
class ProgressState {
  final Map<int, LessonProgress> byLesson;
  final Set<int> bookmarks;

  const ProgressState({this.byLesson = const {}, this.bookmarks = const {}});

  LessonProgress? of(int lessonId) => byLesson[lessonId];
  bool isBookmarked(int lessonId) => bookmarks.contains(lessonId);
  int get completedCount => byLesson.values.where((p) => p.completed).length;
}

class ProgressController extends AsyncNotifier<ProgressState> {
  @override
  Future<ProgressState> build() async {
    final repo = await ref.watch(progressRepositoryProvider.future);
    return ProgressState(
      byLesson: await repo.allProgress(),
      bookmarks: await repo.allBookmarks(),
    );
  }

  Future<void> recordAnswer(int lessonId, int chosen, bool correct) async {
    final repo = await ref.read(progressRepositoryProvider.future);
    await repo.recordAnswer(lessonId: lessonId, chosen: chosen, correct: correct);
    final cur = state.valueOrNull ?? const ProgressState();
    final old = cur.byLesson[lessonId];
    final map = {...cur.byLesson};
    map[lessonId] = LessonProgress(
      lessonId: lessonId,
      completed: (old?.completed ?? false) || correct,
      lastAnswer: chosen,
      lastCorrect: correct,
      attempts: (old?.attempts ?? 0) + 1,
    );
    state = AsyncData(ProgressState(byLesson: map, bookmarks: cur.bookmarks));
  }

  Future<void> toggleBookmark(int lessonId) async {
    final repo = await ref.read(progressRepositoryProvider.future);
    final cur = state.valueOrNull ?? const ProgressState();
    final on = !cur.bookmarks.contains(lessonId);
    await repo.setBookmark(lessonId, on);
    final marks = {...cur.bookmarks};
    if (on) {
      marks.add(lessonId);
    } else {
      marks.remove(lessonId);
    }
    state = AsyncData(ProgressState(byLesson: cur.byLesson, bookmarks: marks));
  }
}

final progressProvider =
    AsyncNotifierProvider<ProgressController, ProgressState>(ProgressController.new);

final lessonNoteProvider = FutureProvider.autoDispose.family<String, int>((ref, lessonId) async {
  final repo = await ref.watch(progressRepositoryProvider.future);
  return repo.note(lessonId);
});
