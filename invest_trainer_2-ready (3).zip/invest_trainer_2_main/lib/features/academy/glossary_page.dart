import 'package:flutter/material.dart';

import 'glossary_data.dart';

/// Глоссарий с поиском: термины объяснены простыми словами.
class GlossaryPage extends StatefulWidget {
  const GlossaryPage({super.key});

  @override
  State<GlossaryPage> createState() => _GlossaryPageState();
}

class _GlossaryPageState extends State<GlossaryPage> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final q = _query.trim().toLowerCase();
    final items = [...kGlossary]..sort((a, b) => a.term.toLowerCase().compareTo(b.term.toLowerCase()));
    final filtered = q.isEmpty
        ? items
        : items
            .where((e) => e.term.toLowerCase().contains(q) || e.meaning.toLowerCase().contains(q))
            .toList();

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        TextField(
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.search),
            hintText: 'Найти термин (всего: ${kGlossary.length})',
          ),
          onChanged: (v) => setState(() => _query = v),
        ),
        const SizedBox(height: 8),
        if (filtered.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('Ничего не найдено.')),
        for (final e in filtered)
          Card(
            child: ListTile(
              title: Text(e.term, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(e.meaning),
            ),
          ),
      ],
    );
  }
}
