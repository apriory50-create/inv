import 'package:flutter/material.dart';

import '../../core/share/share_service.dart';
import '../../core/share/share_texts.dart';
import '../../domain/sim/review.dart';
import '../../lessons_data.dart';
import '../academy/lesson_page.dart';
import 'sim_widgets.dart';

/// Разбор сценария: что произошло, что вы сделали, какие ошибки, что делать в следующий раз.
class ReviewPage extends StatelessWidget {
  const ReviewPage({super.key, required this.review});

  final ScenarioReview review;

  Widget _section(BuildContext context, String title, List<Widget> children) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _bullets(List<String> items) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (final t in items)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [const Text('•  '), Expanded(child: Text(t))],
              ),
            ),
        ],
      );

  void _openLesson(BuildContext context, int id) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => LessonPage(lessonId: id)));
  }

  @override
  Widget build(BuildContext context) {
    final sc = review.scenario;
    final color = verdictColor(review.verdict);
    final lessons = <int, String>{};
    for (final id in review.lessonIds) {
      for (final l in LessonsData.allLessons) {
        if (l.id == id) lessons[id] = l.title;
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Разбор сценария'),
        actions: [
          IconButton(
            tooltip: 'Поделиться разбором',
            icon: const Icon(Icons.ios_share),
            onPressed: () async {
              final messenger = ScaffoldMessenger.of(context);
              final msg = await ShareService.shareText(ShareTexts.review(review), subject: 'Разбор симулятора');
              messenger.showSnackBar(SnackBar(content: Text(msg)));
            },
          ),
        ],
      ),
      body: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 860),
          child: ListView(
            padding: const EdgeInsets.all(12),
            children: [
              Card(
                color: color.withOpacity(0.12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: color, width: 1.5),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(review.verdict.label, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 20)),
                      const SizedBox(height: 4),
                      Text(review.headline),
                      const SizedBox(height: 8),
                      Text(sc.headline, style: const TextStyle(fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ),
              _section(context, 'Что получилось в цифрах', [_bullets(review.summaryLines)]),
              _section(context, 'Что произошло простыми словами', [
                Text(sc.plain),
                const SizedBox(height: 8),
                const Text('Косвенные признаки, по которым это можно было заметить:', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                _bullets(sc.signs),
              ]),
              if (review.findings.isNotEmpty)
                _section(context, 'Ошибки и риски в ваших решениях', [
                  for (final f in review.findings)
                    ExpansionTile(
                      tilePadding: EdgeInsets.zero,
                      leading: Icon(Icons.warning_amber_outlined, color: Colors.orange.shade800),
                      title: Text(f.info.title),
                      subtitle: Text(f.detail),
                      childrenPadding: const EdgeInsets.fromLTRB(0, 0, 0, 8),
                      expandedCrossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(f.info.plain),
                        const SizedBox(height: 6),
                        TextButton.icon(
                          onPressed: () => _openLesson(context, f.info.lessonId),
                          icon: const Icon(Icons.school_outlined),
                          label: Text('Прочитать урок ${f.info.lessonId}'),
                        ),
                      ],
                    ),
                ])
              else
                _section(context, 'Ошибки', [const Text('Типичных ошибок в ваших решениях не найдено.')]),
              if (review.goodDecisions.isNotEmpty)
                _section(context, 'Что получилось хорошо', [_bullets(review.goodDecisions)]),
              _section(context, 'Что стоит рассмотреть в такой ситуации', [_bullets(sc.best)]),
              _section(context, 'Чего лучше не делать', [_bullets(sc.bad)]),
              if (lessons.isNotEmpty)
                _section(context, 'Уроки по теме', [
                  for (final entry in lessons.entries)
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.menu_book_outlined),
                      title: Text(entry.value),
                      onTap: () => _openLesson(context, entry.key),
                    ),
                ]),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  'Это учебная модель: реальные рынки ведут себя сложнее. Разбор не является индивидуальной инвестиционной рекомендацией.',
                  style: TextStyle(fontSize: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
