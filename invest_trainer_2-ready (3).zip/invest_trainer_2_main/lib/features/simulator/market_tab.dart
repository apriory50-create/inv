import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/format.dart';
import '../../domain/sim/engine_models.dart';
import 'instrument_sheet.dart';
import 'sim_controller.dart';

/// Рынок: все инструменты по группам. Нажмите на бумагу, чтобы прочитать про неё и купить или продать.
class MarketTab extends ConsumerWidget {
  const MarketTab({super.key});

  String _subtitle(InstrumentSpec spec, Quote q, double change30, int daysLeft) {
    if (!q.tradable) return 'Погашена';
    switch (spec.kind) {
      case InstrumentKind.bond:
        final pct = q.pricePctOfNominal == null ? '' : '${fmtPct(q.pricePctOfNominal!, sign: false)} номинала';
        final y = q.yieldPct == null ? 'дефолт' : 'доходность ${fmtPct(q.yieldPct!, sign: false)}';
        final years = (daysLeft / 365).toStringAsFixed(1).replaceAll('.', ',');
        return '$pct • $y • $years г.';
      case InstrumentKind.stock:
      case InstrumentKind.fund:
        return '${fmtRub(q.mid, digits: 2)} ₽ • за 30 дн. ${fmtPct(change30)}';
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sim = ref.watch(simProvider);
    final e = sim.engine;
        final byGroup = <AssetGroup, List<InstrumentSpec>>{};
    for (final s in e.catalog) {
      byGroup.putIfAbsent(s.group, () => []).add(s);
    }

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const Card(
          child: Padding(
            padding: EdgeInsets.all(12),
            child: Text(
              'Все эмитенты вымышленные, цены моделируются. Нажмите на бумагу: там простое объяснение, риски и кнопки «Купить» и «Продать».',
            ),
          ),
        ),
        for (final g in AssetGroup.values)
          if (byGroup[g] != null) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 14, 4, 4),
              child: Text(g.label, style: Theme.of(context).textTheme.titleMedium),
            ),
            for (final spec in byGroup[g]!)
              Card(
                child: ListTile(
                  title: Text(spec.name),
                  subtitle: Text(_subtitle(spec, e.quote(spec.id), e.priceChangePct(spec.id, 30), e.daysToMaturity(spec.id))),
                  trailing: e.units(spec.id) > 0
                      ? Chip(label: Text('${e.units(spec.id).toStringAsFixed(0)} шт.'))
                      : const Icon(Icons.chevron_right),
                  onTap: () => showModalBottomSheet<void>(
                    context: context,
                    isScrollControlled: true,
                    useSafeArea: true,
                    builder: (_) => InstrumentSheet(id: spec.id),
                  ),
                ),
              ),
          ],
      ],
    );
  }
}
