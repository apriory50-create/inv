import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/settings/settings_controller.dart';
import '../../domain/sim/engine_models.dart';
import '../../domain/sim/review.dart';
import '../../domain/sim/scenario_model.dart';
import '../../domain/sim/sim_engine.dart';
import '../../domain/sim/sim_save.dart';

class SimState {
  final SimEngine engine;
  final int rev; // счётчик изменений: заставляет интерфейс перерисоваться
  final ScenarioRecord? active;
  final List<ScenarioReview> reviews;

  const SimState({
    required this.engine,
    this.rev = 0,
    this.active,
    this.reviews = const [],
  });

  SimState copy({int? rev, ScenarioRecord? active, bool clearActive = false, List<ScenarioReview>? reviews}) {
    return SimState(
      engine: engine,
      rev: rev ?? this.rev,
      active: clearActive ? null : (active ?? this.active),
      reviews: reviews ?? this.reviews,
    );
  }

  Set<String> get completedScenarioIds => {for (final r in reviews) r.scenario.id};

  /// Как часто встречается каждый тип ошибок в пройденных разборах.
  Map<MistakeType, int> get mistakeCounts {
    final counts = <MistakeType, int>{};
    for (final r in reviews) {
      for (final f in r.findings) {
        counts[f.type] = (counts[f.type] ?? 0) + 1;
      }
    }
    return counts;
  }
}

class SimController extends Notifier<SimState> {
  static const _kSave = 'sim.save.v1';

  /// Состояние восстанавливается из SharedPreferences; при ошибке данных начинается новая игра.
  @override
  SimState build() {
    final raw = ref.read(sharedPreferencesProvider).getString(_kSave);
    if (raw != null) {
      final data = SimSave.decode(raw);
      if (data != null) {
        return SimState(engine: data.engine, active: data.active, reviews: data.reviews);
      }
    }
    return SimState(engine: SimEngine(seed: _newSeed()));
  }

  void _save() {
    final st = state;
    final json = SimSave.encode(engine: st.engine, reviews: st.reviews, active: st.active);
    unawaited(ref.read(sharedPreferencesProvider).setString(_kSave, json));
  }

  static int _newSeed() => DateTime.now().millisecondsSinceEpoch % 1000000;

  SimEngine get engine => state.engine;

  void _bump({ScenarioRecord? active, bool clearActive = false, List<ScenarioReview>? reviews}) {
    state = state.copy(rev: state.rev + 1, active: active, clearActive: clearActive, reviews: reviews);
    _save();
  }

  TradeResult buy(String id, int lots) {
    final r = engine.buy(id, lots);
    _bump();
    return r;
  }

  TradeResult sell(String id, int lots) {
    final r = engine.sell(id, lots);
    _bump();
    return r;
  }

  int placeLimit(String id, TradeSide side, int lots, double price) {
    final orderId = engine.placeLimit(id, side, lots, price);
    _bump();
    return orderId;
  }

  void cancelOrder(int orderId) {
    engine.cancelOrder(orderId);
    _bump();
  }

  List<SimEvent> advance(int days) {
    final events = engine.advance(days);
    _bump();
    return events;
  }

  bool submitOffer(String id) {
    final ok = engine.submitForOffer(id);
    _bump();
    return ok;
  }

  /// Запускает сценарий. Нельзя запустить новый, пока не завершён текущий.
  bool startScenario(Scenario s) {
    if (state.active != null) return false;
    final rec = engine.applyScenario(s);
    _bump(active: rec);
    return true;
  }

  /// Завершает сценарий и возвращает разбор.
  ScenarioReview? finishScenario() {
    final rec = state.active;
    if (rec == null) return null;
    final review = ReviewEngine.review(engine, rec);
    _bump(clearActive: true, reviews: [...state.reviews, review]);
    return review;
  }

  void newGame({double cash = 1000000}) {
    state = SimState(engine: SimEngine(seed: _newSeed(), startCash: cash));
    _save();
  }
}

final simProvider = NotifierProvider<SimController, SimState>(SimController.new);
