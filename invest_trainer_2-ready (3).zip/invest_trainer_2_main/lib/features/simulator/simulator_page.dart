import 'package:flutter/material.dart';

import 'sim_page.dart';

/// Раздел «Симулятор» (точка входа для роутера).
class SimulatorPage extends StatelessWidget {
  const SimulatorPage({super.key});

  @override
  Widget build(BuildContext context) => const SimPage();
}
