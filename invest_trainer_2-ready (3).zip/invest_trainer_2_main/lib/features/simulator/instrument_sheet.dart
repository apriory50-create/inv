import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/format.dart';
import '../../domain/sim/engine_models.dart';
import '../../domain/sim/portfolio_snapshot.dart';
import '../../domain/sim/trade_preview.dart';
import 'sim_controller.dart';
import 'sim_widgets.dart';

/// Карточка инструмента: объяснение «для чайника», котировка, покупка и продажа, лимитные заявки, оферта.
class InstrumentSheet extends ConsumerStatefulWidget {
  const InstrumentSheet({super.key, required this.id});

  final String id;

  @override
  ConsumerState<InstrumentSheet> createState() => _InstrumentSheetState();
}

class _InstrumentSheetState extends ConsumerState<InstrumentSheet> {
  int _lots = 1;
  final _limit = TextEditingController();
  String? _message;
  bool _ok = true;

  @override
  void dispose() {
    _limit.dispose();
    super.dispose();
  }

  void _show(String text, bool ok) => setState(() {
        _message = text;
        _ok = ok;
      });

  void _trade(bool buy) {
    final ctl = ref.read(simProvider.notifier);
    final r = buy ? ctl.buy(widget.id, _lots) : ctl.sell(widget.id, _lots);
    _show(r.message, r.ok);
  }

  void _limitOrder(bool buy) {
    final price = double.tryParse(_limit.text.trim().replaceAll(',', '.'));
    if (price == null || price <= 0) {
      _show('Укажите цену лимитной заявки числом, например 99,5.', false);
      return;
    }
    ref.read(simProvider.notifier).placeLimit(widget.id, buy ? TradeSide.buy : TradeSide.sell, _lots, price);
    _show('Лимитная заявка создана. Она сработает, когда цена достигнет уровня (действует 30 дней).', true);
  }

  @override
  Widget build(BuildContext context) {
    final sim = ref.watch(simProvider);
    final e = sim.engine;
    final st = e.state(widget.id)!;
    final spec = st.spec;
    final q = e.quote(widget.id);
    final snap = e.snapshot();
    final theme = Theme.of(context);

    final held = e.units(widget.id);
    PositionView? pos;
    for (final p in snap.positions) {
      if (p.id == widget.id) pos = p;
    }

    final lotUnits = spec.lotSize.toDouble();
    final unitCost = q.ask + q.accruedPerUnit;
    final estimate = _lots * lotUnits * unitCost;
    final maxBuy = q.tradable && unitCost > 0
        ? math.max(0, (e.cash / (lotUnits * unitCost * (1 + e.config.feeRate))).floor())
        : 0;
    final maxSell = (held / lotUnits).floor();
    final bond = st.bond;
    final orders = e.orders.where((o) => o.instrumentId == widget.id).toList();

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 12, 16, 12 + MediaQuery.of(context).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(spec.name, style: theme.textTheme.titleLarge),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                children: [
                  Chip(label: Text(spec.group.label)),
                  if (spec.kind != InstrumentKind.fund && spec.sector != Sector.government && spec.sector != Sector.diversified)
                    Chip(label: Text(spec.sector.label)),
                  if (spec.rating.isNotEmpty) Chip(label: Text('Рейтинг ${spec.rating}')),
                ],
              ),
              const SizedBox(height: 8),
              Text('Что это', style: theme.textTheme.titleSmall),
              Text(spec.description),
              const SizedBox(height: 6),
              Text('Когда подходит', style: theme.textTheme.titleSmall),
              Text(spec.suitsWhen),
              const SizedBox(height: 6),
              Text('Главные риски', style: theme.textTheme.titleSmall),
              Text(spec.risksPlain),
              const Divider(height: 24),
              if (!q.tradable)
                const Text('Выпуск погашен: торги недоступны.', style: TextStyle(fontWeight: FontWeight.bold))
              else ...[
                KeyValueRow('Цена покупки', '${fmtRub(q.ask, digits: 2)} ₽'),
                KeyValueRow('Цена продажи', '${fmtRub(q.bid, digits: 2)} ₽'),
                if (bond != null) ...[
                  if (q.pricePctOfNominal != null)
                    KeyValueRow('Цена в % от номинала', fmtPct(q.pricePctOfNominal!, sign: false)),
                  if (q.accruedPerUnit > 0)
                    KeyValueRow('НКД на 1 бумагу (платится продавцу)', '${fmtRub(q.accruedPerUnit, digits: 2)} ₽'),
                  if (q.yieldPct != null) KeyValueRow('Доходность к погашению', fmtPct(q.yieldPct!, sign: false)),
                  KeyValueRow('Купон', fmtPct(bond.defaulted ? 0 : bond.couponRate, sign: false)),
                  KeyValueRow('Дюрация', '${e.durationOf(widget.id).toStringAsFixed(1).replaceAll('.', ',')} г.'),
                  KeyValueRow('До погашения', '${(e.daysToMaturity(widget.id) / 365).toStringAsFixed(1).replaceAll('.', ',')} г.'),
                  if (bond.defaulted)
                    Text('Эмитент в дефолте. Купоны не платятся.', style: TextStyle(color: theme.colorScheme.error)),
                ] else if (spec.kind == InstrumentKind.stock) ...[
                  KeyValueRow('Дивидендная доходность', fmtPct(st.divYield * 100, sign: false)),
                  KeyValueRow('Лот', '${spec.lotSize} шт.'),
                ] else ...[
                  KeyValueRow('Комиссия фонда в год', fmtPct(spec.ter * 100, digits: 2, sign: false)),
                ],
                KeyValueRow('Изменение цены за 30 дней', fmtPct(e.priceChangePct(widget.id, 30))),
              ],
              if (e.offerWindowOpen(widget.id)) ...[
                const SizedBox(height: 8),
                Card(
                  color: theme.colorScheme.tertiaryContainer,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Скоро оферта', style: TextStyle(fontWeight: FontWeight.bold)),
                        Text(
                          'После оферты купон станет ${spec.offerNewCoupon}%. Выкуп по номиналу происходит только по вашей заявке.',
                        ),
                        const SizedBox(height: 6),
                        if (e.offerSubmitted(widget.id))
                          const Text('Заявка подана.', style: TextStyle(fontWeight: FontWeight.bold))
                        else if (held > 0)
                          FilledButton(
                            onPressed: () {
                              final ok = ref.read(simProvider.notifier).submitOffer(widget.id);
                              _show(ok ? 'Заявка на оферту подана.' : 'Не удалось подать заявку.', ok);
                            },
                            child: const Text('Подать заявку на выкуп по номиналу'),
                          )
                        else
                          const Text('Чтобы подать заявку, нужно держать эту облигацию.'),
                      ],
                    ),
                  ),
                ),
              ],
              const Divider(height: 24),
              Text('У вас в портфеле', style: theme.textTheme.titleSmall),
              if (pos == null)
                const Text('Пока нет.')
              else ...[
                KeyValueRow('Количество', '${held.toStringAsFixed(0)} шт.'),
                KeyValueRow('Стоимость', '${fmtRub(pos.value)} ₽'),
                KeyValueRow('Результат', '${fmtRub(pos.pnl)} ₽ (${fmtPct(pos.pnlPct)})'),
              ],
              const SizedBox(height: 12),
              Text('Сделка', style: theme.textTheme.titleSmall),
              Row(
                children: [
                  IconButton(
                    onPressed: _lots > 1 ? () => setState(() => _lots--) : null,
                    icon: const Icon(Icons.remove_circle_outline),
                  ),
                  Text('$_lots лот(ов) = ${(_lots * lotUnits).toStringAsFixed(0)} шт.'),
                  IconButton(
                    onPressed: () => setState(() => _lots++),
                    icon: const Icon(Icons.add_circle_outline),
                  ),
                ],
              ),
              Wrap(
                spacing: 6,
                children: [
                  for (final n in const [1, 5, 10, 50, 100])
                    ActionChip(label: Text('$n'), onPressed: () => setState(() => _lots = n)),
                  ActionChip(
                    label: const Text('Макс. покупка'),
                    onPressed: maxBuy > 0 ? () => setState(() => _lots = maxBuy) : null,
                  ),
                  ActionChip(
                    label: const Text('Всё продать'),
                    onPressed: maxSell > 0 ? () => setState(() => _lots = maxSell) : null,
                  ),
                ],
              ),
              if (q.tradable) Text('Ориентировочная сумма покупки: ${fmtRub(estimate)} ₽ + комиссия'),
              if (q.tradable)
                _PreviewBlock(
                  buy: TradePreview.buy(e, widget.id, _lots),
                  sell: maxSell > 0 ? TradePreview.sell(e, widget.id, _lots > maxSell ? maxSell : _lots) : null,
                ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: FilledButton(
                      onPressed: q.tradable ? () => _trade(true) : null,
                      child: const Text('Купить'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: q.tradable && held > 0 ? () => _trade(false) : null,
                      child: const Text('Продать'),
                    ),
                  ),
                ],
              ),
              if (_message != null) ...[
                const SizedBox(height: 8),
                Text(
                  _message!,
                  style: TextStyle(
                    color: _ok ? Colors.green.shade700 : theme.colorScheme.error,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: const Text('Лимитная заявка'),
                subtitle: const Text('Купить не дороже или продать не дешевле заданной цены'),
                children: [
                  TextField(
                    controller: _limit,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(labelText: 'Цена за 1 бумагу, ₽'),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(child: FilledButton.tonal(onPressed: () => _limitOrder(true), child: const Text('Купить не дороже'))),
                      const SizedBox(width: 8),
                      Expanded(child: FilledButton.tonal(onPressed: () => _limitOrder(false), child: const Text('Продать не дешевле'))),
                    ],
                  ),
                  for (final o in orders)
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      title: Text('${o.side == TradeSide.buy ? 'Купить' : 'Продать'} ${o.lots.round()} лот(ов) по ${fmtRub(o.limitPrice, digits: 2)} ₽'),
                      trailing: IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () => ref.read(simProvider.notifier).cancelOrder(o.orderId),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Предпросмотр сделки: предупреждения выделены, пояснения — обычным текстом.
class _PreviewBlock extends StatelessWidget {
  const _PreviewBlock({required this.buy, this.sell});

  final TradePreviewResult buy;
  final TradePreviewResult? sell;

  Widget _block(BuildContext context, String title, TradePreviewResult r) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: theme.textTheme.titleSmall),
        for (final w in r.warnings)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.warning_amber_rounded, size: 18, color: theme.colorScheme.error),
                const SizedBox(width: 6),
                Expanded(child: Text(w, style: TextStyle(color: theme.colorScheme.error))),
              ],
            ),
          ),
        for (final n in r.notes)
          Padding(
            padding: const EdgeInsets.only(top: 3),
            child: Text('• $n', style: theme.textTheme.bodySmall),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(top: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Перед сделкой', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            _block(context, 'Покупка', buy),
            if (sell != null) ...[
              const SizedBox(height: 8),
              _block(context, 'Продажа', sell!),
            ],
            const SizedBox(height: 8),
            Text('Учебная оценка, не рекомендация. Решение за вами.',
                style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}
