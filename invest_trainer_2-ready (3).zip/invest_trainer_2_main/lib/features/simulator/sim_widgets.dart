import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../domain/sim/engine_models.dart';
import '../../domain/sim/review.dart';

/// Подпись «ключ — значение» в одну строку.
class KeyValueRow extends StatelessWidget {
  const KeyValueRow(this.label, this.value, {super.key, this.bold = false});

  final String label;
  final String value;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: Text(label)),
          const SizedBox(width: 8),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal),
            ),
          ),
        ],
      ),
    );
  }
}

/// Полоса доли с подписью.
class ShareBar extends StatelessWidget {
  const ShareBar({super.key, required this.label, required this.share, this.trailing});

  final String label;
  final double share; // 0..1
  final String? trailing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label)),
              Text(trailing ?? '${(share * 100).toStringAsFixed(1).replaceAll('.', ',')}%'),
            ],
          ),
          const SizedBox(height: 2),
          LinearProgressIndicator(
            value: share.clamp(0.0, 1.0).toDouble(),
            minHeight: 6,
            borderRadius: BorderRadius.circular(4),
          ),
        ],
      ),
    );
  }
}

/// Простой линейный график.
class Sparkline extends StatelessWidget {
  const Sparkline({super.key, required this.values, this.height = 90});

  final List<double> values;
  final double height;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(painter: _SparklinePainter(values, color)),
    );
  }
}

class _SparklinePainter extends CustomPainter {
  _SparklinePainter(this.values, this.color);

  final List<double> values;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    if (values.length < 2) return;
    var minV = values.reduce(math.min);
    var maxV = values.reduce(math.max);
    if (maxV - minV < 1e-9) maxV = minV + 1;
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final x = i / (values.length - 1) * size.width;
      final y = size.height - (values[i] - minV) / (maxV - minV) * size.height;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(
      path,
      Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );
  }

  @override
  bool shouldRepaint(covariant _SparklinePainter oldDelegate) =>
      oldDelegate.values != values || oldDelegate.color != color;
}

IconData eventIcon(EventType t) {
  switch (t) {
    case EventType.coupon:
      return Icons.payments_outlined;
    case EventType.dividend:
      return Icons.account_balance_wallet_outlined;
    case EventType.amortization:
    case EventType.maturity:
      return Icons.event_available_outlined;
    case EventType.offerNotice:
    case EventType.offerResult:
      return Icons.campaign_outlined;
    case EventType.defaultEvent:
      return Icons.warning_amber_outlined;
    case EventType.orderFilled:
      return Icons.check_circle_outline;
    case EventType.orderCancelled:
      return Icons.cancel_outlined;
    case EventType.scenario:
      return Icons.newspaper_outlined;
    case EventType.info:
      return Icons.info_outline;
  }
}

Color verdictColor(Verdict v) {
  switch (v) {
    case Verdict.excellent:
      return Colors.green.shade700;
    case Verdict.good:
      return Colors.blue.shade700;
    case Verdict.risky:
      return Colors.orange.shade800;
    case Verdict.mistake:
      return Colors.red.shade700;
  }
}

String difficultyStars(int d) => '★' * d + '☆' * (3 - d);
