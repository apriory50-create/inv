import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/format.dart';
import '../../domain/sim/engine_models.dart';
import '../../domain/sim/scenario_model.dart';
import 'instrument_sheet.dart';
import 'sim_controller.dart';
import 'sim_widgets.dart';

/// Портфель симулятора: структура, доходность, просадка, ожидаемый доход, статистика ошибок.
class SimPortfolioTab extends ConsumerWidget {
  const SimPortfolioTab({super.key});

  List<double> _downsample(List<double> v, int maxPoints) {
    if (v.length <= maxPoints) return v;
    final step = v.length / maxPoints;
    return [for (var i = 0; i < maxPoints; i++) v[(i * step).floor()], v.last];
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sim = ref.watch(simProvider);
    final e = sim.engine;
    final snap = e.snapshot();
    final theme = Theme.of(context);
    final change = snap.total - e.initialCash;
    final changePct = e.initialCash > 0 ? change / e.initialCash * 100 : 0.0;
    final counts = sim.mistakeCounts;
    final topMistakes = counts.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Итоги', style: theme.textTheme.titleMedium),
                const SizedBox(height: 6),
                KeyValueRow('Капитал', '${fmtRub(snap.total)} ₽', bold: true),
                KeyValueRow('Результат с начала игры', '${fmtRub(change)} ₽ (${fmtPct(changePct)})'),
                KeyValueRow('Свободные деньги', '${fmtRub(snap.cash)} ₽'),
                KeyValueRow('Вложено', '${fmtRub(snap.invested)} ₽'),
                KeyValueRow('Макс. просадка', fmtPct(e.maxDrawdownPct())),
                if (snap.duration > 0)
                  KeyValueRow('Дюрация облигаций', '${snap.duration.toStringAsFixed(1).replaceAll('.', ',')} г.'),
                KeyValueRow('Ожидаемый доход за год (до налога)', '${fmtRub(snap.income12m)} ₽'),
                KeyValueRow('Комиссии заплачено', '${fmtRub(snap.feesPaid)} ₽'),
                KeyValueRow('Налогов заплачено', '${fmtRub(snap.taxesPaid)} ₽'),
                const SizedBox(height: 8),
                Sparkline(values: _downsample(e.valueHistory.map((d) => d.value).toList(), 200)),
                Text('Динамика капитала', style: theme.textTheme.bodySmall),
              ],
            ),
          ),
        ),
        if (snap.positions.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Text('Портфель пуст. Откройте вкладку «Рынок», прочитайте про бумаги и сделайте первые покупки. '
                  'Совет: не вкладывайте всё в одну бумагу.'),
            ),
          )
        else ...[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Структура по видам активов', style: theme.textTheme.titleMedium),
                  const SizedBox(height: 8),
                  ShareBar(label: 'Деньги', share: snap.cashWeight),
                  for (final g in AssetGroup.values)
                    if ((snap.byGroup[g] ?? 0) > 0) ShareBar(label: g.label, share: snap.groupWeight(g)),
                ],
              ),
            ),
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('По отраслям', style: theme.textTheme.titleMedium),
                  const SizedBox(height: 8),
                  for (final entry in snap.bySector.entries)
                    ShareBar(label: entry.key.label, share: snap.total > 0 ? entry.value / snap.total : 0),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 12, 4, 4),
            child: Text('Позиции', style: theme.textTheme.titleMedium),
          ),
          for (final p in snap.positions)
            Card(
              child: ListTile(
                title: Text(p.name),
                subtitle: Text('${p.units.toStringAsFixed(0)} шт. • доля ${fmtPct(p.weight * 100, sign: false)}'),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text('${fmtRub(p.value)} ₽'),
                    Text(
                      fmtPct(p.pnlPct),
                      style: TextStyle(color: p.pnl >= 0 ? Colors.green.shade700 : Colors.red.shade700),
                    ),
                  ],
                ),
                onTap: () => showModalBottomSheet<void>(
                  context: context,
                  isScrollControlled: true,
                  useSafeArea: true,
                  builder: (_) => InstrumentSheet(id: p.id),
                ),
              ),
            ),
        ],
        if (sim.reviews.isNotEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Ваша статистика', style: theme.textTheme.titleMedium),
                  const SizedBox(height: 6),
                  Text('Пройдено сценариев: ${sim.reviews.length}'),
                  if (topMistakes.isEmpty)
                    const Text('Повторяющихся ошибок пока нет.')
                  else ...[
                    const SizedBox(height: 4),
                    const Text('Чаще всего встречается:'),
                    for (final m in topMistakes.take(3))
                      Text('• ${kMistakes[m.key]!.title} — ${m.value} раз(а)'),
                  ],
                ],
              ),
            ),
          ),
      ],
    );
  }
}
