import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/sim/scenario_catalog.dart';
import '../../domain/sim/scenario_model.dart';
import 'sim_controller.dart';
import 'sim_widgets.dart';

/// Библиотека сценариев: новости, решения ЦБ, дефолты и т. д. Выберите сценарий и решите, что делать.
class ScenariosTab extends ConsumerStatefulWidget {
  const ScenariosTab({super.key});

  @override
  ConsumerState<ScenariosTab> createState() => _ScenariosTabState();
}

class _ScenariosTabState extends ConsumerState<ScenariosTab> {
  String? _category;
  int _difficulty = 0; // 0 — любая
  final _rng = math.Random();

  List<Scenario> get _filtered => ScenarioCatalog.all()
      .where((s) => (_category == null || s.category == _category) && (_difficulty == 0 || s.difficulty == _difficulty))
      .toList();

  void _start(Scenario s) {
    final ok = ref.read(simProvider.notifier).startScenario(s);
    final messenger = ScaffoldMessenger.of(context);
    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(SnackBar(
      content: Text(ok
          ? 'Сценарий запущен. Решите, что делать с портфелем, прокрутите время и завершите сценарий для разбора.'
          : 'Сначала завершите текущий сценарий.'),
    ));
  }

  void _details(Scenario s, bool active, bool done) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(s.headline, style: Theme.of(ctx).textTheme.titleLarge),
              const SizedBox(height: 4),
              Text('${s.category} • сложность ${difficultyStars(s.difficulty)}'),
              const SizedBox(height: 12),
              Text(s.news),
              const SizedBox(height: 12),
              const Text(
                'Объяснение и разбор появятся после завершения сценария. Сначала подумайте, что бы вы сделали.',
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: active
                    ? null
                    : () {
                        Navigator.of(ctx).pop();
                        _start(s);
                      },
                icon: const Icon(Icons.play_arrow),
                label: Text(active ? 'Сначала завершите текущий сценарий' : (done ? 'Пройти ещё раз' : 'Запустить сценарий')),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final sim = ref.watch(simProvider);
    final active = sim.active != null;
    final done = sim.completedScenarioIds;
    final list = _filtered;
    final categories = ScenarioCatalog.categories();

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Text('Сценариев: ${ScenarioCatalog.all().length}. Пройдено: ${done.length}.',
            style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ChoiceChip(label: const Text('Все'), selected: _category == null, onSelected: (_) => setState(() => _category = null)),
              ),
              for (final c in categories)
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ChoiceChip(label: Text(c), selected: _category == c, onSelected: (_) => setState(() => _category = c)),
                ),
            ],
          ),
        ),
        Wrap(
          spacing: 6,
          children: [
            for (var d = 0; d <= 3; d++)
              ChoiceChip(
                label: Text(d == 0 ? 'Любая сложность' : difficultyStars(d)),
                selected: _difficulty == d,
                onSelected: (_) => setState(() => _difficulty = d),
              ),
          ],
        ),
        const SizedBox(height: 6),
        Align(
          alignment: Alignment.centerLeft,
          child: OutlinedButton.icon(
            onPressed: active || list.isEmpty
                ? null
                : () {
                    final fresh = list.where((s) => !done.contains(s.id)).toList();
                    final pool = fresh.isEmpty ? list : fresh;
                    _start(pool[_rng.nextInt(pool.length)]);
                  },
            icon: const Icon(Icons.casino_outlined),
            label: const Text('Случайный сценарий'),
          ),
        ),
        const SizedBox(height: 6),
        if (list.isEmpty) const Text('По выбранным фильтрам сценариев нет.'),
        for (final s in list)
          Card(
            child: ListTile(
              leading: done.contains(s.id) ? const Icon(Icons.check_circle, color: Colors.green) : const Icon(Icons.radio_button_unchecked),
              title: Text(s.headline),
              subtitle: Text('${s.category} • ${difficultyStars(s.difficulty)}'),
              onTap: () => _details(s, active, done.contains(s.id)),
            ),
          ),
      ],
    );
  }
}
