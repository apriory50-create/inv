import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/format.dart';
import '../../domain/sim/engine_models.dart';
import 'sim_controller.dart';
import 'sim_widgets.dart';

/// Журнал: события рынка (купоны, дивиденды, оферты, дефолты) и ваши сделки.
class JournalTab extends ConsumerWidget {
  const JournalTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sim = ref.watch(simProvider);
    final e = sim.engine;
    final start = e.config.startDate;
    String dateOf(int day) => fmtDate(DateTime(start.year, start.month, start.day + day));

    final events = e.events.reversed.take(150).toList();
    final trades = e.trades.reversed.take(150).toList();

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Text('События', style: Theme.of(context).textTheme.titleMedium),
        if (events.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text('Пока ничего не произошло. Прокрутите время или запустите сценарий.'),
          ),
        for (final ev in events)
          Card(
            child: ListTile(
              dense: true,
              leading: Icon(eventIcon(ev.type)),
              title: Text(ev.text),
              subtitle: Text(dateOf(ev.day)),
            ),
          ),
        const SizedBox(height: 12),
        Text('Ваши сделки', style: Theme.of(context).textTheme.titleMedium),
        if (trades.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text('Сделок пока нет.'),
          ),
        for (final t in trades)
          Card(
            child: ListTile(
              dense: true,
              leading: Icon(t.side == TradeSide.buy ? Icons.add_shopping_cart : Icons.sell_outlined),
              title: Text(
                '${t.side == TradeSide.buy ? 'Покупка' : 'Продажа'}: ${e.state(t.id)!.spec.name}, ${t.units.toStringAsFixed(0)} шт. по ${fmtRub(t.price, digits: 2)} ₽',
              ),
              subtitle: Text(
                '${dateOf(t.day)} • комиссия ${fmtRub(t.fee, digits: 2)} ₽'
                '${t.tax > 0 ? ' • налог ${fmtRub(t.tax, digits: 2)} ₽' : ''}'
                '${t.side == TradeSide.sell ? ' • результат ${fmtRub(t.realizedPnl, digits: 2)} ₽' : ''}',
              ),
            ),
          ),
      ],
    );
  }
}
