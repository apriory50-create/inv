import 'package:flutter/material.dart';

/// Переключатель разделов внутри вкладки. Состояние каждого раздела сохраняется.
class SectionTabs extends StatefulWidget {
  final List<String> labels;
  final List<Widget> children;

  const SectionTabs({super.key, required this.labels, required this.children})
      : assert(labels.length == children.length);

  @override
  State<SectionTabs> createState() => _SectionTabsState();
}

class _SectionTabsState extends State<SectionTabs> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 48,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            itemCount: widget.labels.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (_, i) => ChoiceChip(
              label: Text(widget.labels[i]),
              selected: _index == i,
              onSelected: (_) => setState(() => _index = i),
            ),
          ),
        ),
        Expanded(
          child: IndexedStack(index: _index, children: widget.children),
        ),
      ],
    );
  }
}
