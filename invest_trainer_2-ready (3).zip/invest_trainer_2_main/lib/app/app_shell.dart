import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../core/legal/disclaimer.dart';
import '../core/settings/settings_controller.dart';

class _Destination {
  final String label;
  final IconData icon;
  final IconData selectedIcon;
  const _Destination(this.label, this.icon, this.selectedIcon);
}

const List<_Destination> _destinations = [
  _Destination('Академия', Icons.school_outlined, Icons.school),
  _Destination('Симулятор', Icons.candlestick_chart_outlined, Icons.candlestick_chart),
  _Destination('Портфель', Icons.pie_chart_outline, Icons.pie_chart),
  _Destination('Новости', Icons.newspaper_outlined, Icons.newspaper),
  _Destination('Настройки', Icons.settings_outlined, Icons.settings),
];

const List<LogicalKeyboardKey> _digitKeys = [
  LogicalKeyboardKey.digit1,
  LogicalKeyboardKey.digit2,
  LogicalKeyboardKey.digit3,
  LogicalKeyboardKey.digit4,
  LogicalKeyboardKey.digit5,
];

/// Адаптивная оболочка: на узких экранах (Android) — нижняя панель,
/// на широких (Windows) — боковая панель. Ctrl+1…5 переключают разделы.
class AppShell extends ConsumerStatefulWidget {
  const AppShell({super.key, required this.navigationShell});

  final StatefulNavigationShell navigationShell;

  @override
  ConsumerState<AppShell> createState() => _AppShellState();
}

class _AppShellState extends ConsumerState<AppShell> {
  static const double _wideBreakpoint = 840;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeShowDisclaimer());
  }

  Future<void> _maybeShowDisclaimer() async {
    if (!mounted) return;
    if (ref.read(settingsProvider).disclaimerAccepted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Важно перед началом'),
        content: const SingleChildScrollView(child: Text(Disclaimer.full)),
        actions: [
          FilledButton(
            onPressed: () {
              ref.read(settingsProvider.notifier).acceptDisclaimer();
              Navigator.of(ctx).pop();
            },
            child: const Text('Понятно'),
          ),
        ],
      ),
    );
  }

  void _go(int index) {
    widget.navigationShell.goBranch(
      index,
      initialLocation: index == widget.navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    final index = widget.navigationShell.currentIndex;

    return CallbackShortcuts(
      bindings: <ShortcutActivator, VoidCallback>{
        for (var i = 0; i < _destinations.length; i++)
          SingleActivator(_digitKeys[i], control: true): () => _go(i),
      },
      child: Focus(
        autofocus: true,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final wide = constraints.maxWidth >= _wideBreakpoint;
            return Scaffold(
              appBar: AppBar(title: Text(_destinations[index].label)),
              body: wide
                  ? Row(
                      children: [
                        NavigationRail(
                          selectedIndex: index,
                          onDestinationSelected: _go,
                          labelType: NavigationRailLabelType.all,
                          destinations: [
                            for (final d in _destinations)
                              NavigationRailDestination(
                                icon: Icon(d.icon),
                                selectedIcon: Icon(d.selectedIcon),
                                label: Text(d.label),
                              ),
                          ],
                        ),
                        const VerticalDivider(width: 1),
                        Expanded(child: widget.navigationShell),
                      ],
                    )
                  : widget.navigationShell,
              bottomNavigationBar: wide
                  ? null
                  : NavigationBar(
                      selectedIndex: index,
                      onDestinationSelected: _go,
                      destinations: [
                        for (final d in _destinations)
                          NavigationDestination(
                            icon: Icon(d.icon),
                            selectedIcon: Icon(d.selectedIcon),
                            label: d.label,
                          ),
                      ],
                    ),
            );
          },
        ),
      ),
    );
  }
}
