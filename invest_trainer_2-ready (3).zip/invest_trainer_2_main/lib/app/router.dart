import 'package:go_router/go_router.dart';

import '../features/academy/academy_page.dart';
import '../features/news/news_page.dart';
import '../features/portfolio/portfolio_page.dart';
import '../features/settings/settings_page.dart';
import '../features/simulator/simulator_page.dart';
import 'app_shell.dart';

/// Пять разделов приложения. StatefulShellRoute сохраняет состояние каждого раздела
/// при переключении (портфель симулятора и прокрутка не сбрасываются).
final GoRouter appRouter = GoRouter(
  initialLocation: '/academy',
  routes: [
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) => AppShell(navigationShell: navigationShell),
      branches: [
        StatefulShellBranch(routes: [
          GoRoute(path: '/academy', builder: (context, state) => const AcademyPage()),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: '/simulator', builder: (context, state) => const SimulatorPage()),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: '/portfolio', builder: (context, state) => const PortfolioPage()),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: '/news', builder: (context, state) => const NewsPage()),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: '/settings', builder: (context, state) => const SettingsPage()),
        ]),
      ],
    ),
  ],
);
