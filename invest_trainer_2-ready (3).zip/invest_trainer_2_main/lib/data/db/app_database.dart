import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart' show databaseFactoryFfi;

/// Локальная база приложения (SQLite). Версионирование схемы — через [_migrations].
class AppDatabase {
  AppDatabase._();

  static Database? _db;
  static const String fileName = 'invest_academy.db';

  static const List<String> schemaV1 = [
    '''CREATE TABLE lesson_progress(
      lesson_id INTEGER PRIMARY KEY,
      completed INTEGER NOT NULL DEFAULT 0,
      best_score INTEGER NOT NULL DEFAULT 0,
      updated_at INTEGER NOT NULL
    )''',
    '''CREATE TABLE lesson_notes(
      lesson_id INTEGER PRIMARY KEY,
      body TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    )''',
    '''CREATE TABLE bookmarks(
      lesson_id INTEGER PRIMARY KEY,
      created_at INTEGER NOT NULL
    )''',
    '''CREATE TABLE portfolio_positions(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticker TEXT NOT NULL,
      name TEXT NOT NULL,
      kind TEXT NOT NULL,
      quantity REAL NOT NULL,
      avg_price REAL NOT NULL,
      currency TEXT NOT NULL DEFAULT 'RUB',
      note TEXT,
      created_at INTEGER NOT NULL
    )''',
    '''CREATE TABLE news_sources(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      url TEXT NOT NULL,
      kind TEXT NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 1
    )''',
    '''CREATE TABLE journal(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at INTEGER NOT NULL,
      ticker TEXT,
      action TEXT NOT NULL,
      reason TEXT,
      outcome TEXT
    )''',
  ];

  /// Миграции: ключ — версия, на которую обновляемся.
  static const Map<int, List<String>> _migrations = {
    3: [
      '''CREATE TABLE IF NOT EXISTS news_items(
        id TEXT PRIMARY KEY,
        source TEXT NOT NULL,
        title TEXT NOT NULL,
        summary TEXT NOT NULL,
        url TEXT NOT NULL,
        published INTEGER,
        fetched INTEGER NOT NULL
      )''',
    ],
    2: [
      'ALTER TABLE lesson_progress ADD COLUMN last_answer INTEGER',
      'ALTER TABLE lesson_progress ADD COLUMN last_correct INTEGER NOT NULL DEFAULT 0',
      'ALTER TABLE lesson_progress ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0',
    ],
  };

  static const int version = 3;

  /// Применяет миграции (from, to].
  static Future<void> _migrate(Database db, int from, int to) async {
    for (var v = from + 1; v <= to; v++) {
      final stmts = _migrations[v];
      if (stmts == null) continue;
      for (final stmt in stmts) {
        await db.execute(stmt);
      }
    }
  }

  static bool get _isDesktop => Platform.isWindows || Platform.isLinux || Platform.isMacOS;

  static Future<Database> open() async {
    final existing = _db;
    if (existing != null) return existing;
    final dir = await getApplicationSupportDirectory();
    final path = p.join(dir.path, fileName);
    final DatabaseFactory factory = _isDesktop ? databaseFactoryFfi : databaseFactory;
    final db = await factory.openDatabase(
      path,
      options: OpenDatabaseOptions(
        version: version,
        onCreate: (db, v) async {
          for (final stmt in schemaV1) {
            await db.execute(stmt);
          }
          await _migrate(db, 1, v);
        },
        onUpgrade: (db, oldVersion, newVersion) => _migrate(db, oldVersion, newVersion),
      ),
    );
    _db = db;
    return db;
  }
}

final databaseProvider = FutureProvider<Database>((ref) => AppDatabase.open());
