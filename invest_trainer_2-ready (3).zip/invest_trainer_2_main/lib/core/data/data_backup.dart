import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

import '../../domain/sim/sim_save.dart';

/// Резервная копия и перенос данных в один JSON-файл.
///
/// Входит: прогресс уроков, закладки и заметки, портфель, журнал, источники и фильтры новостей,
/// профили ИИ (без ключей), сохранение симулятора, настройки интерфейса.
/// НЕ входит: ключи API (они только в защищённом хранилище устройства), кэш новостей, флаг принятия оговорки.
/// Файл не шифруется: храните его там, где вам доверяете.
class DataBackup {
  const DataBackup._();

  static const String appId = 'invest_trainer';
  static const int version = 1;

  static const List<String> _tables = [
    'lesson_progress',
    'lesson_notes',
    'bookmarks',
    'portfolio_positions',
    'journal',
    'news_sources',
  ];

  static const List<String> _prefKeys = [
    'sim.save.v1',
    'news.filters.v1',
    'ai.profiles',
    'ai.activeProfileId',
    'settings.themeMode',
    'settings.fontScale',
    'settings.sendAmountsToAi',
  ];

  /// Собирает все разрешённые данные в JSON-строку.
  static Future<String> export(Database db, SharedPreferences prefs) async {
    final tables = <String, Object?>{};
    for (final t in _tables) {
      tables[t] = await db.query(t);
    }
    final bundle = <String, Object?>{
      'app': appId,
      'version': version,
      'createdAt': DateTime.now().toUtc().toIso8601String(),
      'tables': tables,
      'prefs': {for (final k in _prefKeys) k: _readPref(prefs, k)},
    };
    return const JsonEncoder.withIndent('  ').convert(bundle);
  }

  static Object? _readPref(SharedPreferences prefs, String key) {
    final v = prefs.get(key);
    return v;
  }

  /// Проверяет файл и возвращает описание содержимого. Ошибка — текст для пользователя.
  static Object? _decodeChecked(String raw) {
    final Object? decoded;
    try {
      decoded = jsonDecode(raw);
    } catch (_) {
      throw const FormatException('Это не файл резервной копии: текст не разбирается как JSON.');
    }
    if (decoded is! Map || decoded['app'] != appId) {
      throw const FormatException('Файл создан не в этом приложении.');
    }
    final v = (decoded['version'] as num?)?.toInt() ?? 0;
    if (v < 1 || v > version) {
      throw const FormatException('Файл создан в более новой версии приложения. Обновите приложение.');
    }
    final tables = decoded['tables'];
    if (tables is! Map) throw const FormatException('В файле нет данных таблиц.');
    final prefs = decoded['prefs'];
    if (prefs is! Map) throw const FormatException('В файле нет настроек.');
    final sim = prefs['sim.save.v1'];
    if (sim is String && SimSave.decode(sim) == null) {
      throw const FormatException('Сохранение симулятора повреждено, импорт отменён.');
    }
    return decoded;
  }

  /// Краткое описание файла для окна подтверждения.
  static String describe(String raw) {
    final m = _decodeChecked(raw) as Map;
    final tables = m['tables'] as Map;
    final prefs = m['prefs'] as Map;
    int count(String t) => (tables[t] as List? ?? const []).length;
    final sim = prefs['sim.save.v1'];
    final profiles = prefs['ai.profiles'];
    var profileCount = 0;
    if (profiles is String) {
      try {
        profileCount = (jsonDecode(profiles) as List).length;
      } catch (_) {}
    }
    return 'Создан: ${m['createdAt'] ?? '—'}\n'
        'Уроки с результатами: ${count('lesson_progress')}, закладки: ${count('bookmarks')}, заметки: ${count('lesson_notes')}\n'
        'Бумаги в портфеле: ${count('portfolio_positions')}, источники новостей: ${count('news_sources')}\n'
        'Симулятор: ${sim is String ? 'есть сохранение' : 'нет сохранения'}\n'
        'Профили ИИ: $profileCount (ключи API придётся ввести заново)';
  }

  /// Заменяет все данные содержимым файла. Перед вызовом пользователь должен подтвердить действие.
  static Future<void> restore(String raw, Database db, SharedPreferences prefs) async {
    final m = _decodeChecked(raw) as Map;
    final tables = m['tables'] as Map;
    final prefsIn = m['prefs'] as Map;

    await db.transaction((txn) async {
      for (final t in _tables) {
        await txn.delete(t);
      }
      for (final t in _tables) {
        for (final row in (tables[t] as List? ?? const [])) {
          await txn.insert(t, Map<String, Object?>.from(row as Map));
        }
      }
    });

    for (final k in _prefKeys) {
      final v = prefsIn[k];
      if (v == null) {
        await prefs.remove(k);
      } else if (v is String) {
        await prefs.setString(k, v);
      } else if (v is int) {
        await prefs.setInt(k, v);
      } else if (v is double) {
        await prefs.setDouble(k, v);
      } else if (v is bool) {
        await prefs.setBool(k, v);
      }
    }
  }

  /// Удаляет все данные приложения (кроме ключей, которые хранятся отдельно).
  static Future<void> wipe(Database db, SharedPreferences prefs) async {
    await db.transaction((txn) async {
      for (final t in _tables) {
        await txn.delete(t);
      }
    });
    for (final k in _prefKeys) {
      await prefs.remove(k);
    }
  }
}
