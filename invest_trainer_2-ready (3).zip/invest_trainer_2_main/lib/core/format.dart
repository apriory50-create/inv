/// Форматирование чисел и дат для интерфейса (без зависимости от intl).
String fmtRub(double v, {int digits = 0}) {
  final neg = v < 0;
  final fixed = v.abs().toStringAsFixed(digits);
  final parts = fixed.split('.');
  final intPart = parts[0];
  final buf = StringBuffer();
  for (var i = 0; i < intPart.length; i++) {
    if (i > 0 && (intPart.length - i) % 3 == 0) buf.write(' ');
    buf.write(intPart[i]);
  }
  final frac = parts.length > 1 ? ',${parts[1]}' : '';
  final result = '$buf$frac';
  return neg && result.replaceAll(RegExp(r'[0 ,]'), '').isNotEmpty ? '−$result' : result;
}

String fmtPct(double v, {int digits = 1, bool sign = true}) {
  final s = v.abs().toStringAsFixed(digits).replaceAll('.', ',');
  if (!sign) return '$s%';
  if (v > 0) return '+$s%';
  if (v < 0 && double.parse(v.abs().toStringAsFixed(digits)) != 0) return '−$s%';
  return '$s%';
}

String fmtDate(DateTime d) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${two(d.day)}.${two(d.month)}.${d.year}';
}
