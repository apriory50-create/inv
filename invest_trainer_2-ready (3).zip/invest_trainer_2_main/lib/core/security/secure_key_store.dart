import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Хранилище секретов (ключей API) в защищённом хранилище ОС:
/// Android Keystore / Windows Credential Locker. Ключи никогда не пишутся в логи,
/// настройки и экспорт.
class SecureKeyStore {
  SecureKeyStore({FlutterSecureStorage? storage})
      : _storage = storage ??
            const FlutterSecureStorage(
              aOptions: AndroidOptions(encryptedSharedPreferences: true),
            );

  final FlutterSecureStorage _storage;

  static String _name(String profileId) => 'ai_key_$profileId';

  Future<void> saveKey(String profileId, String key) =>
      _storage.write(key: _name(profileId), value: key);

  Future<String?> readKey(String profileId) => _storage.read(key: _name(profileId));

  Future<bool> hasKey(String profileId) async {
    final v = await _storage.read(key: _name(profileId));
    return v != null && v.isNotEmpty;
  }

  Future<void> deleteKey(String profileId) => _storage.delete(key: _name(profileId));

  /// Безопасное отображение ключа: только последние 4 символа.
  static String mask(String key) {
    if (key.isEmpty) return '';
    if (key.length <= 8) return '••••';
    return '••••${key.substring(key.length - 4)}';
  }
}

final secureKeyStoreProvider = Provider<SecureKeyStore>((ref) => SecureKeyStore());
