import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Экземпляр SharedPreferences. Переопределяется в main().
final sharedPreferencesProvider = Provider<SharedPreferences>(
  (ref) => throw UnimplementedError('sharedPreferencesProvider нужно переопределить в main()'),
);

@immutable
class SettingsState {
  final ThemeMode themeMode;
  final double fontScale;
  final bool disclaimerAccepted;

  /// Отправлять ли в ИИ суммы (иначе только проценты и названия).
  final bool sendAmountsToAi;

  const SettingsState({
    this.themeMode = ThemeMode.system,
    this.fontScale = 1.0,
    this.disclaimerAccepted = false,
    this.sendAmountsToAi = false,
  });

  SettingsState copyWith({
    ThemeMode? themeMode,
    double? fontScale,
    bool? disclaimerAccepted,
    bool? sendAmountsToAi,
  }) {
    return SettingsState(
      themeMode: themeMode ?? this.themeMode,
      fontScale: fontScale ?? this.fontScale,
      disclaimerAccepted: disclaimerAccepted ?? this.disclaimerAccepted,
      sendAmountsToAi: sendAmountsToAi ?? this.sendAmountsToAi,
    );
  }
}

class SettingsController extends Notifier<SettingsState> {
  static const _kTheme = 'settings.themeMode';
  static const _kFont = 'settings.fontScale';
  static const _kDisclaimer = 'settings.disclaimerAccepted';
  static const _kSendAmounts = 'settings.sendAmountsToAi';

  SharedPreferences get _prefs => ref.read(sharedPreferencesProvider);

  @override
  SettingsState build() {
    final p = _prefs;
    final themeIndex = (p.getInt(_kTheme) ?? ThemeMode.system.index)
        .clamp(0, ThemeMode.values.length - 1)
        .toInt();
    final font = (p.getDouble(_kFont) ?? 1.0).clamp(0.85, 1.6).toDouble();
    return SettingsState(
      themeMode: ThemeMode.values[themeIndex],
      fontScale: font,
      disclaimerAccepted: p.getBool(_kDisclaimer) ?? false,
      sendAmountsToAi: p.getBool(_kSendAmounts) ?? false,
    );
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    state = state.copyWith(themeMode: mode);
    await _prefs.setInt(_kTheme, mode.index);
  }

  Future<void> setFontScale(double value) async {
    final v = value.clamp(0.85, 1.6).toDouble();
    state = state.copyWith(fontScale: v);
    await _prefs.setDouble(_kFont, v);
  }

  Future<void> acceptDisclaimer() async {
    state = state.copyWith(disclaimerAccepted: true);
    await _prefs.setBool(_kDisclaimer, true);
  }

  Future<void> setSendAmountsToAi(bool value) async {
    state = state.copyWith(sendAmountsToAi: value);
    await _prefs.setBool(_kSendAmounts, value);
  }
}

final settingsProvider =
    NotifierProvider<SettingsController, SettingsState>(SettingsController.new);
