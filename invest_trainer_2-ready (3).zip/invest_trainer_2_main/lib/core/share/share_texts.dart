import '../../domain/sim/review.dart';
import '../../features/portfolio/portfolio_models.dart';
import '../format.dart';
import '../legal/disclaimer.dart';

/// Тексты для «Поделиться». Без сумм в рублях и без количества бумаг: только проценты и названия.
class ShareTexts {
  const ShareTexts._();

  static String review(ScenarioReview r) {
    final buf = StringBuffer()
      ..writeln('Симулятор инвестора: ${r.scenario.headline}')
      ..writeln('Вердикт: ${r.verdict.label}. ${r.headline}')
      ..writeln('Изменение капитала: ${fmtPct(r.changePct)}')
      ..writeln('Если бы ничего не меняли: ${fmtPct(r.doNothingPct)}');
    if (r.findings.isNotEmpty) {
      buf.writeln('Что заметил разбор:');
      for (final f in r.findings) {
        buf.writeln('• ${f.info.title}');
      }
    }
    buf
      ..writeln()
      ..writeln(Disclaimer.short);
    return buf.toString();
  }

  /// Структура портфеля по видам активов в процентах (без сумм и количества).
  static String portfolioStructure(List<Position> positions) {
    final total = positions.fold<double>(0, (s, p) => s + p.cost);
    if (positions.isEmpty || total <= 0) {
      return 'Портфель пуст.\n\n${Disclaimer.short}';
    }
    final byKind = <PositionKind, double>{};
    for (final p in positions) {
      byKind[p.kind] = (byKind[p.kind] ?? 0) + p.cost;
    }
    final entries = byKind.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final buf = StringBuffer('Структура моего портфеля (по стоимости покупки):\n');
    for (final e in entries) {
      buf.writeln('• ${e.key.label}: ${fmtPct(e.value / total * 100, sign: false)}');
    }
    buf
      ..writeln()
      ..writeln(Disclaimer.short);
    return buf.toString();
  }
}
