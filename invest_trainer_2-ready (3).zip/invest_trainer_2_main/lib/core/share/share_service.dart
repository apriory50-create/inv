import 'dart:io';

import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

/// «Поделиться»: на Android — системное меню, на настольных системах — буфер обмена или путь к файлу.
class ShareService {
  const ShareService._();

  static bool get _nativeShare => Platform.isAndroid;

  /// Возвращает сообщение для пользователя о том, что произошло.
  static Future<String> shareText(String text, {String? subject}) async {
    if (_nativeShare) {
      await Share.share(text, subject: subject);
      return 'Открыто меню «Поделиться».';
    }
    await Clipboard.setData(ClipboardData(text: text));
    return 'Текст скопирован в буфер обмена.';
  }

  static Future<String> shareFile(String path, {String? subject}) async {
    if (_nativeShare) {
      await Share.shareXFiles([XFile(path)], subject: subject);
      return 'Открыто меню «Поделиться».';
    }
    await Clipboard.setData(ClipboardData(text: path));
    return 'Файл сохранён: $path (путь скопирован).';
  }
}
