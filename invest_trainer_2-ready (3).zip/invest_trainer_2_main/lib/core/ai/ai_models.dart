import 'package:flutter/foundation.dart';

enum AiProviderType {
  openaiCompatible(
    'OpenAI-совместимый (OpenAI, OpenRouter, Ollama, LM Studio и др.)',
    'https://api.openai.com/v1',
    'например, gpt-4o-mini',
  ),
  anthropic(
    'Anthropic (Claude)',
    'https://api.anthropic.com',
    'например, claude-sonnet-5-5',
  ),
  gemini(
    'Google Gemini',
    'https://generativelanguage.googleapis.com',
    'например, gemini-1.5-flash',
  );

  const AiProviderType(this.label, this.defaultBaseUrl, this.modelHint);

  final String label;
  final String defaultBaseUrl;
  final String modelHint;
}

/// Роль сообщения: system, user, assistant.
@immutable
class AiMessage {
  final String role;
  final String content;

  const AiMessage(this.role, this.content);
  const AiMessage.system(String content) : this('system', content);
  const AiMessage.user(String content) : this('user', content);
  const AiMessage.assistant(String content) : this('assistant', content);
}

/// Профиль подключения к ИИ. Ключ API здесь НЕ хранится (он в SecureKeyStore).
@immutable
class AiProfile {
  final String id;
  final String name;
  final AiProviderType type;
  final String baseUrl;
  final String model;
  final double temperature;
  final int maxTokens;
  final String systemPrompt;

  const AiProfile({
    required this.id,
    required this.name,
    required this.type,
    required this.baseUrl,
    required this.model,
    this.temperature = 0.3,
    this.maxTokens = 1500,
    this.systemPrompt = '',
  });

  AiProfile copyWith({
    String? name,
    AiProviderType? type,
    String? baseUrl,
    String? model,
    double? temperature,
    int? maxTokens,
    String? systemPrompt,
  }) {
    return AiProfile(
      id: id,
      name: name ?? this.name,
      type: type ?? this.type,
      baseUrl: baseUrl ?? this.baseUrl,
      model: model ?? this.model,
      temperature: temperature ?? this.temperature,
      maxTokens: maxTokens ?? this.maxTokens,
      systemPrompt: systemPrompt ?? this.systemPrompt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'type': type.name,
        'baseUrl': baseUrl,
        'model': model,
        'temperature': temperature,
        'maxTokens': maxTokens,
        'systemPrompt': systemPrompt,
      };

  factory AiProfile.fromJson(Map<String, dynamic> json) {
    final typeName = json['type'] as String? ?? AiProviderType.openaiCompatible.name;
    final type = AiProviderType.values.firstWhere(
      (t) => t.name == typeName,
      orElse: () => AiProviderType.openaiCompatible,
    );
    return AiProfile(
      id: json['id'] as String,
      name: json['name'] as String? ?? 'Профиль',
      type: type,
      baseUrl: json['baseUrl'] as String? ?? type.defaultBaseUrl,
      model: json['model'] as String? ?? '',
      temperature: (json['temperature'] as num?)?.toDouble() ?? 0.3,
      maxTokens: (json['maxTokens'] as num?)?.toInt() ?? 1500,
      systemPrompt: json['systemPrompt'] as String? ?? '',
    );
  }
}

class AiException implements Exception {
  final String message;
  const AiException(this.message);

  @override
  String toString() => message;
}
