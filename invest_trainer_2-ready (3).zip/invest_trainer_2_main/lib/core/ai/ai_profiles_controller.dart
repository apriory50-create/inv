import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../security/secure_key_store.dart';
import '../settings/settings_controller.dart';
import 'ai_models.dart';

@immutable
class AiProfilesState {
  final List<AiProfile> profiles;
  final String? activeId;

  const AiProfilesState({this.profiles = const [], this.activeId});

  AiProfile? get active {
    for (final p in profiles) {
      if (p.id == activeId) return p;
    }
    return profiles.isEmpty ? null : profiles.first;
  }
}

/// Профили ИИ хранятся в SharedPreferences (без ключей), ключи — в SecureKeyStore.
class AiProfilesController extends Notifier<AiProfilesState> {
  static const _kProfiles = 'ai.profiles';
  static const _kActive = 'ai.activeProfileId';

  @override
  AiProfilesState build() {
    final prefs = ref.read(sharedPreferencesProvider);
    final raw = prefs.getString(_kProfiles);
    final list = <AiProfile>[];
    if (raw != null && raw.isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          for (final item in decoded) {
            if (item is Map<String, dynamic>) list.add(AiProfile.fromJson(item));
          }
        }
      } catch (_) {
        // Повреждённые данные игнорируем: пользователь заведет профиль заново.
      }
    }
    return AiProfilesState(profiles: list, activeId: prefs.getString(_kActive));
  }

  SecureKeyStore get _keys => ref.read(secureKeyStoreProvider);

  static String newId() => DateTime.now().microsecondsSinceEpoch.toString();

  Future<void> _persist(AiProfilesState next) async {
    state = next;
    final prefs = ref.read(sharedPreferencesProvider);
    await prefs.setString(_kProfiles, jsonEncode(next.profiles.map((p) => p.toJson()).toList()));
    final active = next.activeId;
    if (active == null) {
      await prefs.remove(_kActive);
    } else {
      await prefs.setString(_kActive, active);
    }
  }

  /// Создает или обновляет профиль. Если [apiKey] пустой или null — прежний ключ сохраняется.
  Future<void> upsert(AiProfile profile, {String? apiKey}) async {
    if (apiKey != null && apiKey.trim().isNotEmpty) {
      await _keys.saveKey(profile.id, apiKey.trim());
    }
    final list = [...state.profiles];
    final i = list.indexWhere((p) => p.id == profile.id);
    if (i >= 0) {
      list[i] = profile;
    } else {
      list.add(profile);
    }
    await _persist(AiProfilesState(
      profiles: list,
      activeId: state.activeId ?? profile.id,
    ));
  }

  Future<void> remove(String id) async {
    await _keys.deleteKey(id);
    final list = state.profiles.where((p) => p.id != id).toList();
    final active = state.activeId == id ? (list.isEmpty ? null : list.first.id) : state.activeId;
    await _persist(AiProfilesState(profiles: list, activeId: active));
  }

  Future<void> setActive(String id) =>
      _persist(AiProfilesState(profiles: state.profiles, activeId: id));
}

final aiProfilesProvider =
    NotifierProvider<AiProfilesController, AiProfilesState>(AiProfilesController.new);
