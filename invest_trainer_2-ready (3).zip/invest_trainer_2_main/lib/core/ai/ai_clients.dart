import 'package:dio/dio.dart';

import 'ai_models.dart';

/// Единый интерфейс для любых ИИ-провайдеров.
abstract class AiClient {
  Future<String> chat(List<AiMessage> messages, {CancelToken? cancelToken});
}

class AiClientFactory {
  const AiClientFactory._();

  static AiClient create(AiProfile profile, String apiKey) {
    switch (profile.type) {
      case AiProviderType.openaiCompatible:
        return OpenAiCompatibleClient(profile, apiKey);
      case AiProviderType.anthropic:
        return AnthropicClient(profile, apiKey);
      case AiProviderType.gemini:
        return GeminiClient(profile, apiKey);
    }
  }
}

Dio _newDio() {
  return Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 20),
      sendTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 120),
      responseType: ResponseType.json,
      validateStatus: (status) => status != null && status >= 200 && status < 300,
    ),
  );
}

String _trimSlash(String url) {
  var u = url.trim();
  while (u.endsWith('/')) {
    u = u.substring(0, u.length - 1);
  }
  return u;
}

/// Переводит сетевую ошибку в понятный текст. Заголовки запроса (ключи) в текст не попадают.
String _errorText(DioException e) {
  switch (e.type) {
    case DioExceptionType.connectionTimeout:
    case DioExceptionType.sendTimeout:
    case DioExceptionType.receiveTimeout:
      return 'Превышено время ожидания ответа. Проверьте интернет и повторите.';
    case DioExceptionType.connectionError:
      return 'Нет соединения с сервисом. Проверьте интернет и адрес сервера.';
    case DioExceptionType.cancel:
      return 'Запрос отменен.';
    case DioExceptionType.badResponse:
      final code = e.response?.statusCode ?? 0;
      if (code == 401 || code == 403) return 'Неверный ключ API или нет доступа ($code).';
      if (code == 404) return 'Неверный адрес или имя модели (404).';
      if (code == 429) return 'Превышен лимит запросов или закончились средства (429).';
      if (code >= 500) return 'Ошибка на стороне сервиса ($code). Попробуйте позже.';
      return 'Сервис отклонил запрос (код $code). Проверьте настройки профиля.';
    default:
      return 'Ошибка сети. Проверьте подключение и настройки профиля.';
  }
}

class OpenAiCompatibleClient implements AiClient {
  OpenAiCompatibleClient(this.profile, this.apiKey);

  final AiProfile profile;
  final String apiKey;

  @override
  Future<String> chat(List<AiMessage> messages, {CancelToken? cancelToken}) async {
    final base = _trimSlash(profile.baseUrl);
    final msgs = <Map<String, String>>[
      if (profile.systemPrompt.trim().isNotEmpty)
        {'role': 'system', 'content': profile.systemPrompt},
      for (final m in messages) {'role': m.role, 'content': m.content},
    ];
    try {
      final r = await _newDio().post<dynamic>(
        '$base/chat/completions',
        data: {
          'model': profile.model,
          'messages': msgs,
          'temperature': profile.temperature,
          'max_tokens': profile.maxTokens,
        },
        options: Options(headers: {
          if (apiKey.isNotEmpty) 'Authorization': 'Bearer $apiKey',
        }),
        cancelToken: cancelToken,
      );
      final data = r.data;
      if (data is Map) {
        final choices = data['choices'];
        if (choices is List && choices.isNotEmpty && choices.first is Map) {
          final message = (choices.first as Map)['message'];
          if (message is Map && message['content'] is String) {
            return (message['content'] as String).trim();
          }
        }
      }
      throw const AiException('Сервис вернул пустой или непонятный ответ.');
    } on DioException catch (e) {
      throw AiException(_errorText(e));
    }
  }
}

class AnthropicClient implements AiClient {
  AnthropicClient(this.profile, this.apiKey);

  final AiProfile profile;
  final String apiKey;

  @override
  Future<String> chat(List<AiMessage> messages, {CancelToken? cancelToken}) async {
    final base = _trimSlash(profile.baseUrl);
    final systemParts = <String>[
      if (profile.systemPrompt.trim().isNotEmpty) profile.systemPrompt,
      for (final m in messages)
        if (m.role == 'system') m.content,
    ];
    final msgs = <Map<String, String>>[
      for (final m in messages)
        if (m.role != 'system') {'role': m.role, 'content': m.content},
    ];
    try {
      final r = await _newDio().post<dynamic>(
        '$base/v1/messages',
        data: {
          'model': profile.model,
          'max_tokens': profile.maxTokens,
          'temperature': profile.temperature,
          if (systemParts.isNotEmpty) 'system': systemParts.join('\n\n'),
          'messages': msgs,
        },
        options: Options(headers: {
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        }),
        cancelToken: cancelToken,
      );
      final data = r.data;
      if (data is Map && data['content'] is List) {
        final text = (data['content'] as List)
            .whereType<Map>()
            .where((b) => b['type'] == 'text' && b['text'] is String)
            .map((b) => b['text'] as String)
            .join('\n')
            .trim();
        if (text.isNotEmpty) return text;
      }
      throw const AiException('Сервис вернул пустой или непонятный ответ.');
    } on DioException catch (e) {
      throw AiException(_errorText(e));
    }
  }
}

class GeminiClient implements AiClient {
  GeminiClient(this.profile, this.apiKey);

  final AiProfile profile;
  final String apiKey;

  @override
  Future<String> chat(List<AiMessage> messages, {CancelToken? cancelToken}) async {
    final base = _trimSlash(profile.baseUrl);
    final systemParts = <String>[
      if (profile.systemPrompt.trim().isNotEmpty) profile.systemPrompt,
      for (final m in messages)
        if (m.role == 'system') m.content,
    ];
    final contents = <Map<String, dynamic>>[
      for (final m in messages)
        if (m.role != 'system')
          {
            'role': m.role == 'assistant' ? 'model' : 'user',
            'parts': [
              {'text': m.content},
            ],
          },
    ];
    try {
      final r = await _newDio().post<dynamic>(
        '$base/v1beta/models/${profile.model}:generateContent',
        data: {
          'contents': contents,
          if (systemParts.isNotEmpty)
            'systemInstruction': {
              'parts': [
                {'text': systemParts.join('\n\n')},
              ],
            },
          'generationConfig': {
            'temperature': profile.temperature,
            'maxOutputTokens': profile.maxTokens,
          },
        },
        options: Options(headers: {'x-goog-api-key': apiKey}),
        cancelToken: cancelToken,
      );
      final data = r.data;
      if (data is Map && data['candidates'] is List && (data['candidates'] as List).isNotEmpty) {
        final first = (data['candidates'] as List).first;
        if (first is Map && first['content'] is Map) {
          final parts = (first['content'] as Map)['parts'];
          if (parts is List) {
            final text = parts
                .whereType<Map>()
                .where((p) => p['text'] is String)
                .map((p) => p['text'] as String)
                .join('\n')
                .trim();
            if (text.isNotEmpty) return text;
          }
        }
      }
      throw const AiException('Сервис вернул пустой или непонятный ответ.');
    } on DioException catch (e) {
      throw AiException(_errorText(e));
    }
  }
}
