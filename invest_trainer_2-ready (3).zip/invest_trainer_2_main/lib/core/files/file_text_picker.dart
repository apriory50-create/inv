import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';

class PickedText {
  final String name;
  final String text;

  const PickedText(this.name, this.text);
}

/// Выбор текстового файла (JSON, CSV) через системный диалог.
class FileTextPicker {
  const FileTextPicker._();

  /// null — пользователь отменил выбор. Ошибка чтения — FormatException с текстом для пользователя.
  static Future<PickedText?> pick({required List<String> extensions}) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: extensions,
      withData: true,
    );
    if (result == null || result.files.isEmpty) return null;
    final f = result.files.single;
    var bytes = f.bytes;
    if (bytes == null && f.path != null) {
      bytes = await File(f.path!).readAsBytes();
    }
    if (bytes == null) throw const FormatException('Не удалось прочитать выбранный файл.');
    if (bytes.length > 5 * 1024 * 1024) {
      throw const FormatException('Файл слишком большой (больше 5 МБ).');
    }
    return PickedText(f.name, utf8.decode(bytes, allowMalformed: true));
  }
}
