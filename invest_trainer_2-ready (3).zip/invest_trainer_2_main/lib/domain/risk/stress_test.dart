import '../../features/portfolio/portfolio_models.dart';

/// Одна позиция реального портфеля для стресс-теста.
class StressPosition {
  final String ticker;
  final PositionKind kind;

  /// Текущая стоимость (по котировке или по цене покупки, если котировки нет).
  final double value;

  const StressPosition({required this.ticker, required this.kind, required this.value});
}

/// Сценарий стресса. Изменения задаются в понятных величинах.
class StressScenario {
  final String name;
  final String description;

  /// Изменение ключевой ставки, п. п. Отрицательное значение — снижение ставки.
  final double rateShockPp;

  /// Движение рынка акций, %.
  final double marketPct;

  /// Изменение курса иностранной валюты к рублю, %. Положительное — рубль слабеет.
  final double currencyPct;

  const StressScenario({
    required this.name,
    required this.description,
    this.rateShockPp = 0,
    this.marketPct = 0,
    this.currencyPct = 0,
  });
}

class StressResult {
  final StressScenario scenario;
  final double changeRub;
  final double changePct;
  final Map<PositionKind, double> byKind;

  const StressResult({required this.scenario, required this.changeRub, required this.changePct, required this.byKind});
}

/// Стресс-тест реального портфеля. Модель намеренно простая: каждая группа реагирует на один фактор.
/// Допущения перечислены в [assumptions] и показываются пользователю.
class PortfolioStress {
  const PortfolioStress._();

  /// Средняя дюрация облигаций, если пользователь её не указал (лет).
  static const double bondDuration = 3.0;

  /// Бета акций к рынку.
  static const double stockBeta = 1.0;

  /// Бета фондов акций к рынку.
  static const double fundBeta = 0.9;

  static const List<String> assumptions = [
    'Облигации: средняя дюрация $bondDuration г.; изменение цены ≈ −дюрация × изменение ставки. Фонды облигаций считаем как акции.',
    'Акции: реагируют на рынок с бетой $stockBeta, фонды — с бетой $fundBeta.',
    'Валюта и золото: растут в рублях, когда рубль слабеет, на величину курса.',
    'Деньги на счёте не меняются. Инфляция и налоги не учитываются.',
    'Это упрощённая модель, а не прогноз. Реальные реакции рынка могут сильно отличаться.',
  ];

  static const List<StressScenario> presets = [
    StressScenario(
      name: 'Ставка +3 п. п.',
      description: 'ЦБ резко поднимает ставку, рынок акций слегка снижается.',
      rateShockPp: 3,
      marketPct: -5,
    ),
    StressScenario(
      name: 'Рынок акций −30%',
      description: 'Глубокое падение рынка акций при слабом рубле.',
      marketPct: -30,
      currencyPct: 10,
    ),
    StressScenario(
      name: 'Рубль −20%',
      description: 'Резкое ослабление рубля, ставка растёт на 2 п. п., рынок снижается.',
      rateShockPp: 2,
      marketPct: -8,
      currencyPct: 20,
    ),
    StressScenario(
      name: 'Мягкий кризис',
      description: 'Ставка снижается на 2 п. п., рынок падает на 15%, рубль немного слабеет.',
      rateShockPp: -2,
      marketPct: -15,
      currencyPct: 5,
    ),
  ];

  static double _positionChange(StressPosition p, StressScenario s) {
    switch (p.kind) {
      case PositionKind.bond:
        return p.value * (-bondDuration * s.rateShockPp / 100);
      case PositionKind.stock:
        return p.value * (stockBeta * s.marketPct / 100);
      case PositionKind.fund:
        return p.value * (fundBeta * s.marketPct / 100);
      case PositionKind.currency:
      case PositionKind.gold:
        return p.value * (s.currencyPct / 100);
      case PositionKind.cash:
        return 0;
      case PositionKind.other:
        return p.value * (s.marketPct / 100);
    }
  }

  static StressResult run(List<StressPosition> positions, StressScenario s) {
    final total = positions.fold<double>(0, (sum, p) => sum + p.value);
    var change = 0.0;
    final byKind = <PositionKind, double>{};
    for (final p in positions) {
      final c = _positionChange(p, s);
      change += c;
      byKind[p.kind] = (byKind[p.kind] ?? 0) + c;
    }
    return StressResult(
      scenario: s,
      changeRub: change,
      changePct: total > 0 ? change / total * 100 : 0,
      byKind: byKind,
    );
  }

  static List<StressResult> runAll(List<StressPosition> positions, [List<StressScenario> scenarios = presets]) =>
      [for (final s in scenarios) run(positions, s)];
}
