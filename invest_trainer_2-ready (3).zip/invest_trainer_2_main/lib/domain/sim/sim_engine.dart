import 'dart:math' as math;

import 'bond_math.dart';
import 'engine_models.dart';
import 'instrument_catalog.dart';
import 'portfolio_snapshot.dart';
import 'scenario_model.dart';

class _Shock {
  final double yieldDelta; // п. п. (облигации и облигационные фонды)
  final double logReturn; // логарифмическая доходность (акции, фонды)
  final int days;
  int left;

  _Shock(this.yieldDelta, this.logReturn, this.days) : left = days;
}

/// Состояние облигации.
class BondState {
  double yieldPct; // для флоатера — дополнительный спред, п. п.
  double couponRate;
  double remainingFrac = 1.0; // остаток номинала
  double indexFactor = 1.0; // индексация (линкеры)
  int couponsLeft;
  int daysToNext;
  int daysSince;
  int amortLeft;
  bool defaulted = false;
  bool matured = false;
  bool offerDone = false;
  bool offerNoticeSent = false;
  double recoveryPct = 0;

  BondState({
    required this.yieldPct,
    required this.couponRate,
    required this.couponsLeft,
    required this.daysToNext,
    required this.daysSince,
    required this.amortLeft,
  });
}

class InstrumentState {
  final InstrumentSpec spec;
  double price; // за 1 штуку, без НКД
  double divYield;
  double fundYield; // доходность облигационного фонда
  BondState? bond;
  _Shock? _shock;
  final List<double> history = [];

  InstrumentState(this.spec, this.price)
      : divYield = spec.divYield,
        fundYield = spec.fundYield;
}

/// Движок симулятора рынка и портфеля. Детерминирован при одинаковом seed.
class SimEngine {
  SimEngine({
    int seed = 1,
    double startCash = 1000000,
    SimConfig? config,
    List<InstrumentSpec>? catalog,
  })  : config = config ?? SimConfig(),
        _seed = seed,
        _rng = math.Random(seed),
        cash = startCash,
        initialCash = startCash {
    for (final spec in (catalog ?? InstrumentCatalog.build())) {
      final st = _initState(spec);
      _states[spec.id] = st;
      st.history.add(st.price);
    }
    valueHistory.add(DayValue(0, totalValue()));
  }

  final SimConfig config;
  final int _seed;
  math.Random _rng;
  final double initialCash;

  int day = 0;
  double cash;
  double keyRate = 16.0;
  double inflation = 9.0;
  double fxIndex = 1.0;
  double feesPaid = 0;
  double taxesPaid = 0;
  double lossCarry = 0;
  double incomeReceived = 0; // купоны и дивиденды после налога

  final Map<String, InstrumentState> _states = {};
  final Map<String, List<Lot>> _lots = {};
  final Set<String> _offerSubmitted = {};
  final List<LimitOrder> orders = [];
  final List<TradeRecord> trades = [];
  final List<SimEvent> events = [];
  final List<MissedOffer> missedOffers = [];
  final List<DayValue> valueHistory = [];
  int _nextOrderId = 1;

  // ---------------------------------------------------------------- доступ

  List<InstrumentSpec> get catalog => _states.values.map((s) => s.spec).toList();

  InstrumentState? state(String id) => _states[id];

  DateTime get date => DateTime(config.startDate.year, config.startDate.month, config.startDate.day + day);

  double units(String id) {
    var u = 0.0;
    for (final l in _lots[id] ?? const <Lot>[]) {
      u += l.units;
    }
    return u;
  }

  List<Lot> lotsOf(String id) => List.unmodifiable(_lots[id] ?? const <Lot>[]);

  /// Дней до погашения.
  int daysToMaturity(String id) {
    final b = _states[id]?.bond;
    if (b == null || b.matured) return 0;
    final period = _states[id]!.spec.couponPeriodDays;
    return b.daysToNext + (b.couponsLeft - 1) * period;
  }

  /// Открыто ли окно для подачи заявки на оферту.
  bool offerWindowOpen(String id) {
    final st = _states[id];
    final b = st?.bond;
    final at = st?.spec.offerAtCouponsLeft;
    return b != null && at != null && !b.offerDone && b.couponsLeft == at + 1;
  }

  bool offerSubmitted(String id) => _offerSubmitted.contains(id);

  // ---------------------------------------------------------------- инициализация

  InstrumentState _initState(InstrumentSpec spec) {
    if (spec.kind != InstrumentKind.bond) {
      return InstrumentState(spec, spec.startPrice);
    }
    final period = spec.couponPeriodDays;
    final n = math.max(1, spec.maturityDays ~/ period);
    final daysToNext = spec.maturityDays - (n - 1) * period;
    final floater = spec.couponType == CouponType.floater;
    final b = BondState(
      yieldPct: floater ? 0.0 : spec.startYield,
      couponRate: floater ? keyRate + spec.spreadToKey : spec.couponRate,
      couponsLeft: n,
      daysToNext: daysToNext,
      daysSince: period - daysToNext,
      amortLeft: spec.amortPayments,
    );
    final st = InstrumentState(spec, 0)..bond = b;
    _updateBondPrice(st);
    return st;
  }

  // ---------------------------------------------------------------- цены

  double _gauss() {
    final u1 = 1 - _rng.nextDouble();
    final u2 = _rng.nextDouble();
    return math.sqrt(-2 * math.log(u1)) * math.cos(2 * math.pi * u2);
  }

  double _round(double p) => p < 10 ? double.parse(p.toStringAsFixed(4)) : double.parse(p.toStringAsFixed(2));

  double _fx(InstrumentSpec s) => s.fxLinked ? fxIndex : 1.0;

  double _scale(InstrumentState st) {
    final b = st.bond!;
    return st.spec.nominal * b.indexFactor * _fx(st.spec);
  }

  double _unitNominal(InstrumentState st) => _scale(st) * st.bond!.remainingFrac;

  double _accruedPerUnit(InstrumentState st) {
    final b = st.bond;
    if (b == null || b.matured || b.defaulted) return 0;
    final s = st.spec;
    return BondMath.accruedFrac(
          couponRatePct: b.couponRate,
          freq: s.couponsPerYear,
          remainingFrac: b.remainingFrac,
          daysSince: b.daysSince,
          period: s.couponPeriodDays,
        ) *
        _scale(st);
  }

  List<CashFlow> _flows(InstrumentState st) {
    final s = st.spec;
    final b = st.bond!;
    return BondMath.cashFlows(
      couponsLeft: b.couponsLeft,
      daysToNext: b.daysToNext,
      period: s.couponPeriodDays,
      couponRatePct: b.couponRate,
      freq: s.couponsPerYear,
      remainingFrac: b.remainingFrac,
      amortPayments: s.amortPayments,
      amortLeft: b.amortLeft,
    );
  }

  void _updateBondPrice(InstrumentState st) {
    final s = st.spec;
    final b = st.bond!;
    if (b.matured) {
      st.price = 0;
      return;
    }
    final scale = _scale(st);
    if (b.defaulted) {
      st.price = _round(math.max(0.01, b.recoveryPct / 100 * scale * b.remainingFrac));
      return;
    }
    if (s.couponType == CouponType.floater) {
      final pct = math.max(1.0, 100 - 0.25 * b.yieldPct);
      st.price = _round(pct / 100 * scale * b.remainingFrac);
      return;
    }
    final flows = _flows(st);
    final dirty = BondMath.dirtyFrac(flows, b.yieldPct, s.couponsPerYear, s.couponPeriodDays);
    final accr = BondMath.accruedFrac(
      couponRatePct: b.couponRate,
      freq: s.couponsPerYear,
      remainingFrac: b.remainingFrac,
      daysSince: b.daysSince,
      period: s.couponPeriodDays,
    );
    final clean = math.max(0.01 * b.remainingFrac, dirty - accr);
    st.price = _round(clean * scale);
  }

  /// Модифицированная дюрация облигации (лет); у фондов — заданная.
  double durationOf(String id) {
    final st = _states[id];
    if (st == null) return 0;
    final s = st.spec;
    if (s.kind == InstrumentKind.fund) {
      return s.fundType == FundType.bond ? s.fundDuration : 0;
    }
    final b = st.bond;
    if (b == null || b.matured || b.defaulted) return 0;
    if (s.couponType == CouponType.floater) return 0.25;
    return BondMath.modifiedDuration(_flows(st), b.yieldPct, s.couponsPerYear, s.couponPeriodDays);
  }

  Quote quote(String id) {
    final st = _states[id]!;
    final s = st.spec;
    var half = s.spreadBps / 20000;
    if (s.kind != InstrumentKind.bond) {
      return Quote(mid: st.price, bid: _round(st.price * (1 - half)), ask: _round(st.price * (1 + half)));
    }
    final b = st.bond!;
    if (b.matured) {
      return const Quote(mid: 0, bid: 0, ask: 0, tradable: false);
    }
    if (b.defaulted) half = 0.075;
    final nominal = _unitNominal(st);
    final yieldShown = s.couponType == CouponType.floater ? b.couponRate + b.yieldPct : b.yieldPct;
    return Quote(
      mid: st.price,
      bid: _round(st.price * (1 - half)),
      ask: _round(st.price * (1 + half)),
      accruedPerUnit: _accruedPerUnit(st),
      yieldPct: b.defaulted ? null : yieldShown,
      pricePctOfNominal: nominal > 0 ? st.price / nominal * 100 : null,
    );
  }

  /// Изменение цены инструмента между двумя днями, %.
  double priceChangeBetween(String id, int fromDay, int toDay) {
    final h = _states[id]!.history;
    final a = math.max(0, math.min(fromDay, h.length - 1));
    final z = math.max(0, math.min(toDay, h.length - 1));
    if (h[a] <= 0) return 0;
    return (h[z] / h[a] - 1) * 100;
  }

  /// Изменение цены инструмента за последние [days] дней, %.
  double priceChangePct(String id, int days, {int? endDay}) {
    final h = _states[id]!.history;
    final end = math.min(endDay ?? day, h.length - 1);
    final start = math.max(0, end - days);
    if (h[start] <= 0) return 0;
    return (h[end] / h[start] - 1) * 100;
  }

  // ---------------------------------------------------------------- ход времени

  /// Продвигает время на [days] дней и возвращает произошедшие события.
  List<SimEvent> advance(int days) {
    final out = <SimEvent>[];
    for (var i = 0; i < days; i++) {
      _stepDay(out);
    }
    return out;
  }

  void _add(List<SimEvent> out, SimEvent e) {
    out.add(e);
    events.add(e);
  }

  void _stepDay(List<SimEvent> out) {
    day++;
    final m = config.marketDrift + config.marketVol * _gauss();
    for (final st in _states.values) {
      switch (st.spec.kind) {
        case InstrumentKind.bond:
          _stepBond(st, out);
        case InstrumentKind.stock:
          _stepStock(st, m, out);
        case InstrumentKind.fund:
          _stepFund(st, m);
      }
      st.history.add(st.price);
    }
    _processOrders(out);
    valueHistory.add(DayValue(day, totalValue()));
  }

  /// Забирает долю шока на сегодня.
  (double, double) _takeShock(InstrumentState st) {
    final sh = st._shock;
    if (sh == null || sh.left <= 0) return (0.0, 0.0);
    sh.left--;
    return (sh.yieldDelta / sh.days, sh.logReturn / sh.days);
  }

  void _stepStock(InstrumentState st, double m, List<SimEvent> out) {
    final s = st.spec;
    final (_, shockLog) = _takeShock(st);
    final totalDaily = s.annualVol / math.sqrt(252);
    final sysDaily = s.beta * config.marketVol;
    final idio = math.sqrt(math.max(0.0, totalDaily * totalDaily - sysDaily * sysDaily));
    final r = s.beta * m + idio * _gauss() + shockLog;
    st.price = _round(math.max(0.01, st.price * math.exp(r)));

    if (st.divYield > 0 && day % 365 == s.divDay) {
      final div = _round(st.price * st.divYield);
      final held = units(s.id);
      if (held > 0) {
        final gross = held * div;
        final tax = gross * config.taxRate;
        cash += gross - tax;
        taxesPaid += tax;
        incomeReceived += gross - tax;
        _add(
          out,
          SimEvent(day, EventType.dividend,
              'Дивиденды по ${s.name}: ${_fmt(gross)} ₽ (после налога ${_fmt(gross - tax)} ₽). Цена акции упала на размер дивиденда — это дивидендный гэп.',
              instrumentId: s.id, amount: gross - tax),
        );
      }
      st.price = _round(math.max(0.01, st.price - div));
    }
  }

  void _stepFund(InstrumentState st, double m) {
    final s = st.spec;
    final (shockYield, shockLog) = _takeShock(st);
    double r;
    switch (s.fundType!) {
      case FundType.money:
        r = (keyRate / 100 - s.ter) / 365;
      case FundType.bond:
        final dy = 0.02 * _gauss() + shockYield;
        st.fundYield += dy;
        r = (st.fundYield / 100 - s.ter) / 365 - s.fundDuration * dy / 100;
      case FundType.gold:
        r = 0.0002 + s.annualVol / math.sqrt(252) * _gauss() - s.ter / 365 + shockLog;
      case FundType.indexFund:
      case FundType.sector:
        final idio = s.annualVol * 0.25 / math.sqrt(252);
        r = s.beta * m + idio * _gauss() - s.ter / 365 + shockLog;
    }
    st.price = _round(math.max(0.01, st.price * math.exp(r)));
  }

  void _stepBond(InstrumentState st, List<SimEvent> out) {
    final s = st.spec;
    final b = st.bond!;
    if (b.matured) return;
    final (shockYield, _) = _takeShock(st);

    if (b.defaulted) {
      b.daysSince++;
      return;
    }

    b.daysToNext--;
    b.daysSince++;
    if (s.couponType == CouponType.floater) {
      b.couponRate = math.max(0.1, keyRate + s.spreadToKey);
      b.yieldPct = math.max(-2.0, b.yieldPct + 0.01 * _gauss() + shockYield);
    } else {
      b.yieldPct = math.max(0.1, b.yieldPct + 0.025 * _gauss() + shockYield);
    }
    if (s.couponType == CouponType.linker) {
      b.indexFactor *= 1 + inflation / 100 / 365;
    }

    // Уведомление об оферте за 10 дней.
    final at = s.offerAtCouponsLeft;
    if (at != null && !b.offerDone && !b.offerNoticeSent && b.couponsLeft == at + 1 && b.daysToNext <= 10) {
      b.offerNoticeSent = true;
      _add(
        out,
        SimEvent(
          day,
          EventType.offerNotice,
          'Скоро оферта по ${s.name}: эмитент объявил, что после неё купон станет ${s.offerNewCoupon}% годовых. '
          'Если новый купон вас не устраивает, подайте заявку на выкуп по номиналу заранее — автоматически он не выкупается.',
          instrumentId: s.id,
        ),
      );
    }

    if (b.daysToNext <= 0) {
      _payCoupon(st, out);
    }
    _updateBondPrice(st);
  }

  void _payCoupon(InstrumentState st, List<SimEvent> out) {
    final s = st.spec;
    final b = st.bond!;
    final period = s.couponPeriodDays;
    final scale = _scale(st);
    final balBefore = b.remainingFrac;
    final couponPerUnit = b.couponRate / 100 / s.couponsPerYear * balBefore * scale;

    double amortFrac;
    if (s.amortPayments > 0) {
      amortFrac = b.couponsLeft <= b.amortLeft ? math.min(1.0 / s.amortPayments, balBefore) : 0.0;
    } else {
      amortFrac = b.couponsLeft == 1 ? balBefore : 0.0;
    }
    final amortPerUnit = amortFrac * scale;

    final lots = _lots[s.id];
    final held = units(s.id);
    if (held > 0 && lots != null) {
      final grossCoupon = held * couponPerUnit;
      var nkdOffset = 0.0;
      for (final l in lots) {
        nkdOffset += l.units * l.nkdPerUnit;
        l.nkdPerUnit = 0;
      }
      final tax = math.max(0.0, grossCoupon - nkdOffset) * config.taxRate;
      taxesPaid += tax;
      cash += grossCoupon - tax;
      incomeReceived += grossCoupon - tax;
      _add(
        out,
        SimEvent(day, EventType.coupon,
            'Купон по ${s.name}: ${_fmt(grossCoupon)} ₽ (после налога ${_fmt(grossCoupon - tax)} ₽).',
            instrumentId: s.id, amount: grossCoupon - tax),
      );

      if (amortFrac > 0) {
        var gain = 0.0;
        final shareOfCost = balBefore > 0 ? amortFrac / balBefore : 1.0;
        for (final l in lots) {
          gain += l.units * (amortPerUnit - l.costPerUnit * shareOfCost);
          l.costPerUnit *= (1 - shareOfCost);
        }
        final amortTax = _taxOnGain(gain);
        cash += held * amortPerUnit - amortTax;
        _add(
          out,
          SimEvent(
            day,
            amortFrac >= balBefore - 1e-9 ? EventType.maturity : EventType.amortization,
            amortFrac >= balBefore - 1e-9
                ? 'Погашение ${s.name}: вам возвращено ${_fmt(held * amortPerUnit)} ₽ номинала.'
                : 'Амортизация ${s.name}: возвращена часть номинала, ${_fmt(held * amortPerUnit)} ₽.',
            instrumentId: s.id,
            amount: held * amortPerUnit - amortTax,
          ),
        );
      }
    }

    b.remainingFrac = math.max(0.0, balBefore - amortFrac);
    if (s.amortPayments > 0 && amortFrac > 0) b.amortLeft--;
    b.couponsLeft--;
    b.daysToNext = period;
    b.daysSince = 0;

    if (b.couponsLeft <= 0 || b.remainingFrac <= 1e-9) {
      b.matured = true;
      _lots.remove(s.id);
      _offerSubmitted.remove(s.id);
      st.price = 0;
      return;
    }

    final at = s.offerAtCouponsLeft;
    if (at != null && !b.offerDone && b.couponsLeft == at) {
      _runOffer(st, out);
    }
  }

  void _runOffer(InstrumentState st, List<SimEvent> out) {
    final s = st.spec;
    final b = st.bond!;
    final held = units(s.id);
    b.offerDone = true;
    if (_offerSubmitted.contains(s.id) && held > 0) {
      final par = _unitNominal(st);
      var gain = 0.0;
      for (final l in _lots[s.id] ?? const <Lot>[]) {
        gain += l.units * (par - l.costPerUnit);
      }
      final tax = _taxOnGain(gain);
      cash += held * par - tax;
      _lots.remove(s.id);
      _add(
        out,
        SimEvent(day, EventType.offerResult,
            'Оферта по ${s.name}: ваша заявка исполнена, выкуплено на ${_fmt(held * par)} ₽ по номиналу.',
            instrumentId: s.id, amount: held * par - tax),
      );
    } else {
      final old = b.couponRate;
      b.couponRate = s.offerNewCoupon;
      if (held > 0) {
        missedOffers.add(MissedOffer(day, s.id, held));
        _add(
          out,
          SimEvent(day, EventType.offerResult,
              'Оферта по ${s.name}: вы не подали заявку. Купон снижен с ${old.toStringAsFixed(1)}% до ${s.offerNewCoupon}%, цена облигации резко упала.',
              instrumentId: s.id),
        );
      } else {
        _add(
          out,
          SimEvent(day, EventType.offerResult,
              'Оферта по ${s.name}: купон снижен с ${old.toStringAsFixed(1)}% до ${s.offerNewCoupon}%.',
              instrumentId: s.id),
        );
      }
    }
  }

  /// Подать заявку на оферту (только пока окно открыто).
  bool submitForOffer(String id) {
    if (!offerWindowOpen(id) || units(id) <= 0) return false;
    _offerSubmitted.add(id);
    return true;
  }

  // ---------------------------------------------------------------- налоги

  double _taxOnGain(double gain) {
    if (gain <= 0) {
      lossCarry += -gain;
      return 0;
    }
    final used = math.min(lossCarry, gain);
    lossCarry -= used;
    final tax = (gain - used) * config.taxRate;
    taxesPaid += tax;
    return tax;
  }

  // ---------------------------------------------------------------- сделки

  String _fmt(double v) => v.toStringAsFixed(2);

  TradeResult buy(String id, int lots) {
    final st = _states[id];
    if (st == null) return const TradeResult.fail('Такой бумаги нет.');
    if (lots <= 0) return const TradeResult.fail('Укажите количество лотов больше нуля.');
    final s = st.spec;
    final q = quote(id);
    if (!q.tradable) return const TradeResult.fail('Выпуск погашен, торги недоступны.');
    final units = lots * s.lotSize.toDouble();
    final nkd = units * q.accruedPerUnit;
    final deal = units * q.ask + nkd;
    final fee = deal * config.feeRate;
    if (cash + 1e-9 < deal + fee) {
      return TradeResult.fail('Недостаточно денег: нужно ${_fmt(deal + fee)} ₽, доступно ${_fmt(cash)} ₽.');
    }
    cash -= deal + fee;
    feesPaid += fee;
    _lots.putIfAbsent(id, () => []).add(
      Lot(units: units, costPerUnit: q.ask + fee / units, nkdPerUnit: q.accruedPerUnit, day: day),
    );
    trades.add(TradeRecord(day: day, id: id, side: TradeSide.buy, units: units, price: q.ask, nkd: nkd, fee: fee));
    return TradeResult(
      ok: true,
      message: 'Куплено ${units.toStringAsFixed(0)} шт. ${s.name} по ${_fmt(q.ask)} ₽'
          '${nkd > 0 ? ' (НКД ${_fmt(nkd)} ₽)' : ''}. Комиссия ${_fmt(fee)} ₽.',
      fee: fee,
      nkd: nkd,
      gross: deal,
      price: q.ask,
    );
  }

  TradeResult sell(String id, int lots) {
    final st = _states[id];
    if (st == null) return const TradeResult.fail('Такой бумаги нет.');
    if (lots <= 0) return const TradeResult.fail('Укажите количество лотов больше нуля.');
    final s = st.spec;
    final q = quote(id);
    if (!q.tradable) return const TradeResult.fail('Выпуск погашен, торги недоступны.');
    final unitsToSell = lots * s.lotSize.toDouble();
    if (units(id) + 1e-9 < unitsToSell) {
      return TradeResult.fail('Недостаточно бумаг: у вас ${units(id).toStringAsFixed(0)} шт.');
    }
    final list = _lots[id]!;
    final nkd = unitsToSell * q.accruedPerUnit;
    final gross = unitsToSell * q.bid + nkd;
    final fee = gross * config.feeRate;

    var remaining = unitsToSell;
    var taxableGain = 0.0;
    var realized = 0.0;
    for (final lot in List<Lot>.of(list)) {
      if (remaining <= 1e-9) break;
      final take = math.min(lot.units, remaining);
      final lotGain = take * (q.bid - lot.costPerUnit) + take * (q.accruedPerUnit - lot.nkdPerUnit);
      var taxable = lotGain;
      final held = day - lot.day;
      if (config.ldvEnabled && held >= 1095 && lotGain > 0) {
        final limit = 3000000.0 * (held / 365).floor();
        taxable = lotGain - math.min(lotGain, limit);
      }
      taxableGain += taxable;
      realized += lotGain;
      lot.units -= take;
      remaining -= take;
    }
    list.removeWhere((l) => l.units <= 1e-9);
    if (list.isEmpty) _lots.remove(id);

    taxableGain -= fee;
    realized -= fee;
    final tax = _taxOnGain(taxableGain);
    cash += gross - fee - tax;
    feesPaid += fee;
    trades.add(TradeRecord(
      day: day,
      id: id,
      side: TradeSide.sell,
      units: unitsToSell,
      price: q.bid,
      nkd: nkd,
      fee: fee,
      tax: tax,
      realizedPnl: realized,
    ));
    return TradeResult(
      ok: true,
      message: 'Продано ${unitsToSell.toStringAsFixed(0)} шт. ${s.name} по ${_fmt(q.bid)} ₽. '
          'Комиссия ${_fmt(fee)} ₽, налог ${_fmt(tax)} ₽. Результат сделки: ${realized >= 0 ? '+' : ''}${_fmt(realized)} ₽.',
      fee: fee,
      tax: tax,
      nkd: nkd,
      gross: gross,
      price: q.bid,
    );
  }

  /// Лимитная заявка. Возвращает её номер.
  int placeLimit(String id, TradeSide side, int lots, double limitPrice) {
    final order = LimitOrder(
      orderId: _nextOrderId++,
      instrumentId: id,
      side: side,
      lots: lots.toDouble(),
      limitPrice: limitPrice,
      createdDay: day,
    );
    orders.add(order);
    return order.orderId;
  }

  bool cancelOrder(int orderId) {
    final before = orders.length;
    orders.removeWhere((o) => o.orderId == orderId);
    return orders.length < before;
  }

  void _processOrders(List<SimEvent> out) {
    for (final o in List<LimitOrder>.of(orders)) {
      final st = _states[o.instrumentId];
      if (st == null) {
        orders.remove(o);
        continue;
      }
      if (day - o.createdDay > 30) {
        orders.remove(o);
        _add(out, SimEvent(day, EventType.orderCancelled,
            'Лимитная заявка по ${st.spec.name} снята: срок действия (30 дней) истёк.', instrumentId: o.instrumentId));
        continue;
      }
      final q = quote(o.instrumentId);
      if (!q.tradable) {
        orders.remove(o);
        continue;
      }
      final hit = o.side == TradeSide.buy ? q.ask <= o.limitPrice : q.bid >= o.limitPrice;
      if (!hit) continue;
      final res = o.side == TradeSide.buy ? buy(o.instrumentId, o.lots.round()) : sell(o.instrumentId, o.lots.round());
      orders.remove(o);
      _add(out, SimEvent(day, res.ok ? EventType.orderFilled : EventType.orderCancelled,
          res.ok ? 'Лимитная заявка исполнена. ${res.message}' : 'Лимитная заявка не исполнена: ${res.message}',
          instrumentId: o.instrumentId));
    }
  }

  // ---------------------------------------------------------------- сценарии

  double _yieldDeltaFor(InstrumentSpec s, ScenarioParams p) {
    final extra = p.instrumentYield[s.id] ?? 0.0;
    if (s.kind == InstrumentKind.fund) {
      return s.fundType == FundType.bond ? 0.6 * (p.keyRateDelta + p.curveShift + p.creditSpreadDelta) + extra : 0.0;
    }
    if (s.kind != InstrumentKind.bond) return 0;
    if (s.couponType == CouponType.floater) return s.creditBeta * p.creditSpreadDelta + extra;
    return s.curveBeta * (p.keyRateDelta + p.curveShift) + s.creditBeta * p.creditSpreadDelta + extra;
  }

  /// Ожидаемое изменение цены в % (без шума), нужно для разбора.
  double expectedPct(String id, ScenarioParams p) {
    final st = _states[id];
    if (st == null) return 0;
    final s = st.spec;
    switch (s.kind) {
      case InstrumentKind.bond:
        final b = st.bond!;
        if (b.matured) return 0;
        if (p.defaultIssuers.contains(s.issuer)) {
          final rec = s.bondType == BondType.highYield ? 25.0 : 40.0;
          return -(100 - rec);
        }
        if (b.defaulted) return 0;
        final yd = _yieldDeltaFor(s, p);
        var pct = -durationOf(id) * yd;
        if (s.fxLinked) pct += p.fxDelta;
        return pct;
      case InstrumentKind.fund:
        switch (s.fundType!) {
          case FundType.money:
            return 0;
          case FundType.bond:
            return -s.fundDuration * _yieldDeltaFor(s, p);
          case FundType.gold:
            return s.fxSens * p.fxDelta + p.goldShift;
          case FundType.indexFund:
          case FundType.sector:
            return _equityPct(s, p);
        }
      case InstrumentKind.stock:
        return _equityPct(s, p);
    }
  }

  double _equityPct(InstrumentSpec s, ScenarioParams p) {
    return s.beta * p.marketShift +
        (p.sectorShift[s.sector] ?? 0) +
        s.fxSens * p.fxDelta -
        s.rateSens * p.keyRateDelta +
        (p.instrumentShift[s.id] ?? 0);
  }

  _Shock? _shockFor(InstrumentState st, ScenarioParams p) {
    final s = st.spec;
    final days = math.max(1, p.rampDays);
    switch (s.kind) {
      case InstrumentKind.bond:
        final yd = _yieldDeltaFor(s, p);
        return yd == 0 ? null : _Shock(yd, 0, days);
      case InstrumentKind.fund:
        switch (s.fundType!) {
          case FundType.money:
            return null;
          case FundType.bond:
            final yd = _yieldDeltaFor(s, p);
            return yd == 0 ? null : _Shock(yd, 0, days);
          case FundType.gold:
          case FundType.indexFund:
          case FundType.sector:
            final pct = expectedPct(s.id, p);
            return pct == 0 ? null : _Shock(0, math.log(math.max(0.05, 1 + pct / 100)), days);
        }
      case InstrumentKind.stock:
        final pct = _equityPct(s, p);
        return pct == 0 ? null : _Shock(0, math.log(math.max(0.05, 1 + pct / 100)), days);
    }
  }

  /// Применяет сценарий: меняет ставку, курс, запускает шоки цен. Возвращает запись для разбора.
  ScenarioRecord applyScenario(Scenario sc) {
    final rec = ScenarioRecord(
      scenario: sc,
      startDay: day,
      before: snapshot(),
      tradeStart: trades.length,
      eventStart: events.length,
    );
    final p = sc.params;
    keyRate = (keyRate + p.keyRateDelta).clamp(1.0, 45.0).toDouble();
    inflation = (inflation + p.inflationDelta).clamp(0.0, 60.0).toDouble();
    fxIndex = math.max(0.2, fxIndex * (1 + p.fxDelta / 100));

    for (final st in _states.values) {
      st._shock = _shockFor(st, p);
      final newDiv = p.divYieldSet[st.spec.id];
      if (newDiv != null) st.divYield = newDiv;
      final b = st.bond;
      if (b != null && !b.defaulted && !b.matured && p.defaultIssuers.contains(st.spec.issuer)) {
        b.defaulted = true;
        b.recoveryPct = st.spec.bondType == BondType.highYield ? 25.0 : 40.0;
        _updateBondPrice(st);
        events.add(SimEvent(day, EventType.defaultEvent,
            'Дефолт: ${st.spec.issuer} не выплатил долг по ${st.spec.name}. Ориентировочная цена восстановления — ${b.recoveryPct.toStringAsFixed(0)}% номинала.',
            instrumentId: st.spec.id));
      }
    }
    events.add(SimEvent(day, EventType.scenario, sc.headline));
    return rec;
  }

  // ---------------------------------------------------------------- портфель

  double positionValue(String id) {
    final st = _states[id]!;
    final u = units(id);
    if (u <= 0) return 0;
    return u * (st.price + _accruedPerUnit(st));
  }

  double totalValue() {
    var v = cash;
    for (final id in _lots.keys) {
      v += positionValue(id);
    }
    return v;
  }

  PortfolioSnapshot snapshot() {
    final total = totalValue();
    final positions = <PositionView>[];
    final byGroup = <AssetGroup, double>{};
    final bySector = <Sector, double>{};
    final byIssuer = <String, double>{};
    var durNum = 0.0;
    var durDen = 0.0;
    var income = 0.0;

    for (final entry in _lots.entries) {
      final id = entry.key;
      final st = _states[id]!;
      final s = st.spec;
      final u = units(id);
      if (u <= 0) continue;
      final value = positionValue(id);
      var cost = 0.0;
      for (final l in entry.value) {
        cost += l.units * (l.costPerUnit + l.nkdPerUnit);
      }
      final d = durationOf(id);
      positions.add(PositionView(
        id: id,
        name: s.name,
        group: s.group,
        sector: s.sector,
        issuer: s.issuer,
        units: u,
        value: value,
        weight: total > 0 ? value / total : 0,
        costBasis: cost,
        pnl: value - cost,
        duration: d,
      ));
      byGroup[s.group] = (byGroup[s.group] ?? 0) + value;
      bySector[s.sector] = (bySector[s.sector] ?? 0) + value;
      // Фонды и ОФЗ в концентрацию по эмитентам не включаем: фонды диверсифицированы, ОФЗ — риск государства.
      if (s.kind != InstrumentKind.fund && s.bondType != BondType.ofz) {
        byIssuer[s.issuer] = (byIssuer[s.issuer] ?? 0) + value;
      }
      if (s.kind == InstrumentKind.bond || (s.fundType == FundType.bond)) {
        durNum += d * value;
        durDen += value;
      }
      if (s.kind == InstrumentKind.bond) {
        final b = st.bond!;
        if (!b.defaulted && !b.matured) {
          income += u * b.couponRate / 100 * _unitNominal(st);
        }
      } else if (s.kind == InstrumentKind.stock) {
        income += u * st.price * st.divYield;
      }
    }
    positions.sort((a, b) => b.value.compareTo(a.value));
    return PortfolioSnapshot(
      day: day,
      cash: cash,
      total: total,
      positions: positions,
      byGroup: byGroup,
      bySector: bySector,
      byIssuer: byIssuer,
      duration: durDen > 0 ? durNum / durDen : 0,
      income12m: income,
      feesPaid: feesPaid,
      taxesPaid: taxesPaid,
    );
  }

  /// Максимальная просадка капитала за всё время, %.
  double maxDrawdownPct() {
    var peak = 0.0;
    var worst = 0.0;
    for (final v in valueHistory) {
      if (v.value > peak) peak = v.value;
      if (peak > 0) {
        final dd = (v.value / peak - 1) * 100;
        if (dd < worst) worst = dd;
      }
    }
    return worst;
  }

  // ---------------------------------------------------------------- сохранение

  static double _d(Object? v) => (v as num).toDouble();

  /// Полное состояние симуляции в виде JSON-совместимых значений.
  /// Журналы не обрезаются: индексы событий и сделок нужны для разбора активного сценария.
  Map<String, Object?> toJson() {
    return {
      'v': 1,
      'seed': _seed,
      'startCash': initialCash,
      'startDate': config.startDate.toIso8601String(),
      'day': day,
      'cash': cash,
      'keyRate': keyRate,
      'inflation': inflation,
      'fxIndex': fxIndex,
      'feesPaid': feesPaid,
      'taxesPaid': taxesPaid,
      'lossCarry': lossCarry,
      'incomeReceived': incomeReceived,
      'nextOrderId': _nextOrderId,
      'states': {for (final e in _states.entries) e.key: _stateJson(e.value)},
      'lots': {
        for (final e in _lots.entries)
          e.key: [
            for (final l in e.value) {'u': l.units, 'c': l.costPerUnit, 'n': l.nkdPerUnit, 'd': l.day},
          ],
      },
      'offerSubmitted': _offerSubmitted.toList(),
      'orders': [
        for (final o in orders)
          {'id': o.orderId, 'inst': o.instrumentId, 'side': o.side.name, 'lots': o.lots, 'price': o.limitPrice, 'created': o.createdDay},
      ],
      'trades': [
        for (final t in trades)
          {
            'day': t.day,
            'id': t.id,
            'side': t.side.name,
            'units': t.units,
            'price': t.price,
            'nkd': t.nkd,
            'fee': t.fee,
            'tax': t.tax,
            'pnl': t.realizedPnl,
          },
      ],
      'events': [
        for (final ev in events)
          {'day': ev.day, 'type': ev.type.name, 'text': ev.text, 'inst': ev.instrumentId, 'amount': ev.amount},
      ],
      'missed': [
        for (final m in missedOffers) {'day': m.day, 'inst': m.instrumentId, 'units': m.unitsHeld},
      ],
      'values': [
        for (final v in valueHistory) [v.day, v.value],
      ],
    };
  }

  static Map<String, Object?> _stateJson(InstrumentState st) {
    final b = st.bond;
    final sh = st._shock;
    return {
      'price': st.price,
      'div': st.divYield,
      'fund': st.fundYield,
      'history': st.history,
      'bond': b == null
          ? null
          : {
              'y': b.yieldPct,
              'c': b.couponRate,
              'rem': b.remainingFrac,
              'idx': b.indexFactor,
              'cl': b.couponsLeft,
              'dtn': b.daysToNext,
              'ds': b.daysSince,
              'al': b.amortLeft,
              'def': b.defaulted,
              'mat': b.matured,
              'offDone': b.offerDone,
              'offNotice': b.offerNoticeSent,
              'rec': b.recoveryPct,
            },
      'shock': sh == null ? null : {'y': sh.yieldDelta, 'l': sh.logReturn, 'd': sh.days, 'left': sh.left},
    };
  }

  /// Восстанавливает движок из [toJson]. Генератор случайных чисел перезапускается от seed и дня:
  /// состояние совпадает точно, а будущие случайные движения будут другими, чем без перезапуска.
  static SimEngine fromJson(Map<String, Object?> j) {
    final seed = (j['seed'] as num).toInt();
    final startCash = _d(j['startCash']);
    final startDate = DateTime.parse(j['startDate'] as String);
    final e = SimEngine(seed: seed, startCash: startCash, config: SimConfig(startDate: startDate));

    e.day = (j['day'] as num).toInt();
    e.cash = _d(j['cash']);
    e.keyRate = _d(j['keyRate']);
    e.inflation = _d(j['inflation']);
    e.fxIndex = _d(j['fxIndex']);
    e.feesPaid = _d(j['feesPaid']);
    e.taxesPaid = _d(j['taxesPaid']);
    e.lossCarry = _d(j['lossCarry']);
    e.incomeReceived = _d(j['incomeReceived']);
    e._nextOrderId = (j['nextOrderId'] as num).toInt();

    final states = j['states'] as Map;
    for (final entry in states.entries) {
      final st = e._states[entry.key as String];
      if (st == null) continue; // инструмент исчез из каталога
      final m = entry.value as Map;
      st.price = _d(m['price']);
      st.divYield = _d(m['div']);
      st.fundYield = _d(m['fund']);
      st.history
        ..clear()
        ..addAll([for (final x in m['history'] as List) _d(x)]);
      final bm = m['bond'] as Map?;
      final b = st.bond;
      if (bm != null && b != null) {
        b.yieldPct = _d(bm['y']);
        b.couponRate = _d(bm['c']);
        b.remainingFrac = _d(bm['rem']);
        b.indexFactor = _d(bm['idx']);
        b.couponsLeft = (bm['cl'] as num).toInt();
        b.daysToNext = (bm['dtn'] as num).toInt();
        b.daysSince = (bm['ds'] as num).toInt();
        b.amortLeft = (bm['al'] as num).toInt();
        b.defaulted = bm['def'] as bool;
        b.matured = bm['mat'] as bool;
        b.offerDone = bm['offDone'] as bool;
        b.offerNoticeSent = bm['offNotice'] as bool;
        b.recoveryPct = _d(bm['rec']);
      }
      final sm = m['shock'] as Map?;
      st._shock = sm == null
          ? null
          : (_Shock(_d(sm['y']), _d(sm['l']), (sm['d'] as num).toInt())..left = (sm['left'] as num).toInt());
    }

    e._lots.clear();
    final lots = j['lots'] as Map;
    for (final entry in lots.entries) {
      e._lots[entry.key as String] = [
        for (final l in entry.value as List)
          Lot(
            units: _d((l as Map)['u']),
            costPerUnit: _d(l['c']),
            nkdPerUnit: _d(l['n']),
            day: (l['d'] as num).toInt(),
          ),
      ];
    }

    e._offerSubmitted
      ..clear()
      ..addAll([for (final x in j['offerSubmitted'] as List) x as String]);

    e.orders.clear();
    for (final o in j['orders'] as List) {
      final m = o as Map;
      e.orders.add(LimitOrder(
        orderId: (m['id'] as num).toInt(),
        instrumentId: m['inst'] as String,
        side: TradeSide.values.byName(m['side'] as String),
        lots: _d(m['lots']),
        limitPrice: _d(m['price']),
        createdDay: (m['created'] as num).toInt(),
      ));
    }

    e.trades.clear();
    for (final t in j['trades'] as List) {
      final m = t as Map;
      e.trades.add(TradeRecord(
        day: (m['day'] as num).toInt(),
        id: m['id'] as String,
        side: TradeSide.values.byName(m['side'] as String),
        units: _d(m['units']),
        price: _d(m['price']),
        nkd: _d(m['nkd']),
        fee: _d(m['fee']),
        tax: _d(m['tax']),
        realizedPnl: _d(m['pnl']),
      ));
    }

    e.events.clear();
    for (final ev in j['events'] as List) {
      final m = ev as Map;
      e.events.add(SimEvent(
        (m['day'] as num).toInt(),
        EventType.values.byName(m['type'] as String),
        m['text'] as String,
        instrumentId: m['inst'] as String?,
        amount: _d(m['amount']),
      ));
    }

    e.missedOffers.clear();
    for (final x in j['missed'] as List) {
      final m = x as Map;
      e.missedOffers.add(MissedOffer((m['day'] as num).toInt(), m['inst'] as String, _d(m['units'])));
    }

    e.valueHistory.clear();
    for (final x in j['values'] as List) {
      final pair = x as List;
      e.valueHistory.add(DayValue((pair[0] as num).toInt(), _d(pair[1])));
    }

    e._rng = math.Random(seed + e.day * 7919);
    return e;
  }
}
