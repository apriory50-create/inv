import 'engine_models.dart';
import 'instrument_catalog.dart';
import 'scenario_model.dart';

String fmtNum(double v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toString();

/// Помощник для сборки сценариев с автоматической нумерацией.
class ScenarioBuilder {
  ScenarioBuilder() : _names = {for (final s in InstrumentCatalog.build()) s.id: s.name};

  final List<Scenario> items = [];
  final Map<String, String> _names;

  String nm(String id) => _names[id] ?? id;

  void add({
    required String category,
    int difficulty = 1,
    required String headline,
    required String news,
    required String plain,
    required List<String> signs,
    required ScenarioParams params,
    required List<String> best,
    required List<String> bad,
    List<MistakeType> mistakes = const [],
    List<int> lessons = const [],
    List<RecommendedMove> rec = const [],
  }) {
    items.add(Scenario(
      id: 'S${(items.length + 1).toString().padLeft(3, '0')}',
      category: category,
      difficulty: difficulty,
      headline: headline,
      news: news,
      plain: plain,
      signs: signs,
      params: params,
      best: best,
      bad: bad,
      mistakes: mistakes,
      lessonIds: lessons,
      recommended: rec,
    ));
  }
}

// Типовые рекомендации для разбора «что если».
const RecommendedMove kMoveToFloaters = RecommendedMove(
  fromGroups: [AssetGroup.ofzFixed, AssetGroup.corpBond, AssetGroup.bondFund],
  toIds: ['OFZ-F', 'F-MM'],
  pct: 0.4,
  why: 'Перевести часть длинных облигаций с фиксированным купоном во флоатеры и денежный рынок: они меньше падают при росте ставки.',
);

const RecommendedMove kMoveToLongBonds = RecommendedMove(
  fromGroups: [AssetGroup.moneyFund, AssetGroup.ofzFloater],
  toIds: ['OFZ-M', 'OFZ-L'],
  pct: 0.3,
  why: 'Часть денег из денежного рынка и флоатеров зафиксировать в среднесрочных и длинных ОФЗ, пока доходности высокие.',
);

const RecommendedMove kMoveToSafety = RecommendedMove(
  fromGroups: [AssetGroup.stock, AssetGroup.highYield],
  toIds: ['F-MM', 'OFZ-S'],
  pct: 0.25,
  why: 'Снизить долю самых рискованных активов и переложить в денежный рынок и короткие ОФЗ.',
);

const RecommendedMove kMoveToFxProtection = RecommendedMove(
  fromGroups: [AssetGroup.moneyFund],
  toIds: ['F-GLD', 'FXB-1'],
  pct: 0.2,
  why: 'Небольшая часть защитного капитала в золоте и валютных облигациях защищает от ослабления рубля.',
);

const RecommendedMove kMoveFromCredit = RecommendedMove(
  fromGroups: [AssetGroup.highYield, AssetGroup.corpBond],
  toIds: ['OFZ-S', 'F-MM'],
  pct: 0.5,
  why: 'При росте кредитных рисков переложить часть слабых заемщиков в ОФЗ и денежный рынок.',
);

const RecommendedMove kTakeProfit = RecommendedMove(
  fromGroups: [AssetGroup.stock],
  toIds: ['F-MM', 'OFZ-F'],
  pct: 0.2,
  why: 'После резкого роста зафиксировать часть прибыли и вернуть доли к плановым.',
);

const RecommendedMove kBuyTheDip = RecommendedMove(
  fromGroups: [AssetGroup.moneyFund],
  toIds: ['F-IDX'],
  pct: 0.25,
  why: 'Если бизнес не изменился, часть резерва из денежного рынка можно частями вложить в широкий индекс.',
);
