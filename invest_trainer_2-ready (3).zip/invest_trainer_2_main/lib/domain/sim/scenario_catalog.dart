import 'scenario_builder.dart';
import 'scenario_catalog_a.dart';
import 'scenario_catalog_b.dart';
import 'scenario_model.dart';

/// Каталог сценариев симулятора (200+).
class ScenarioCatalog {
  const ScenarioCatalog._();

  static List<Scenario>? _cache;

  static List<Scenario> all() => _cache ??= _build();

  static List<Scenario> _build() {
    final b = ScenarioBuilder();
    addScenariosA(b);
    addScenariosB(b);
    return List.unmodifiable(b.items);
  }

  static Scenario? byId(String id) {
    for (final s in all()) {
      if (s.id == id) return s;
    }
    return null;
  }

  static List<String> categories() {
    final seen = <String>[];
    for (final s in all()) {
      if (!seen.contains(s.category)) seen.add(s.category);
    }
    return seen;
  }

  static List<Scenario> inCategory(String category) =>
      all().where((s) => s.category == category).toList();
}
