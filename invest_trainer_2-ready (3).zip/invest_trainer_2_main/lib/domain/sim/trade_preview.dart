import 'engine_models.dart';
import 'sim_engine.dart';

/// Предпросмотр сделки: сколько стоит, что изменится в портфеле и на что обратить внимание.
/// Чистая логика поверх движка, без интерфейса. Все предупреждения — учебные.
class TradePreviewResult {
  final double gross;
  final double fee;
  final double nkd;
  final double total;

  /// Важные предупреждения: сделку стоит перепроверить до подтверждения.
  final List<String> warnings;

  /// Пояснения и напоминания, не блокирующие сделку.
  final List<String> notes;

  const TradePreviewResult({
    required this.gross,
    required this.fee,
    required this.nkd,
    required this.total,
    this.warnings = const [],
    this.notes = const [],
  });

  bool get hasWarnings => warnings.isNotEmpty;
}

class TradePreview {
  const TradePreview._();

  /// Порог доли одного эмитента, после которого предупреждаем (в долях капитала).
  static const double issuerWarnShare = 0.25;

  /// Порог доли высокодоходных облигаций.
  static const double highYieldWarnShare = 0.10;

  /// Дюрация, с которой облигацию считаем длинной.
  static const double longDuration = 5.0;

  static TradePreviewResult buy(SimEngine e, String id, int lots) {
    final st = e.state(id)!;
    final spec = st.spec;
    final q = e.quote(id);
    final units = lots * spec.lotSize.toDouble();
    final nkd = units * q.accruedPerUnit;
    final gross = units * q.ask;
    final fee = (gross + nkd) * e.config.feeRate;
    final total = gross + nkd + fee;
    final snap = e.snapshot();
    final spreadCost = units * (q.ask - q.mid);

    final warnings = <String>[];
    final notes = <String>[];

    if (total > snap.cash + 1e-9) {
      warnings.add('Не хватает денег: нужно ${total.toStringAsFixed(0)} ₽, доступно ${snap.cash.toStringAsFixed(0)} ₽.');
    }

    final totalAfter = snap.total - fee - spreadCost;
    if (totalAfter > 0) {
      // Оценка доли эмитента после покупки. Фонды и ОФЗ в концентрацию не входят (см. снимок портфеля).
      final issuerNow = spec.kind == InstrumentKind.fund || spec.bondType == BondType.ofz
          ? 0.0
          : (snap.byIssuer[spec.issuer] ?? 0.0);
      if (spec.kind != InstrumentKind.fund && spec.bondType != BondType.ofz) {
        final share = (issuerNow + units * q.mid) / totalAfter;
        if (share > issuerWarnShare) {
          warnings.add('Доля эмитента «${spec.issuer}» станет ${(share * 100).toStringAsFixed(0)}% капитала. '
              'Больше ${(issuerWarnShare * 100).toStringAsFixed(0)}% — это много для одного эмитента.');
        } else if (share > 0.10) {
          notes.add('Доля эмитента «${spec.issuer}» станет ${(share * 100).toStringAsFixed(0)}%.');
        }
      }
      if (spec.bondType == BondType.highYield) {
        final hyNow = snap.groupWeight(AssetGroup.highYield) * snap.total;
        final hyShare = (hyNow + units * q.mid) / totalAfter;
        if (hyShare > highYieldWarnShare) {
          warnings.add('ВДО станут ${(hyShare * 100).toStringAsFixed(0)}% портфеля. '
              'Высокодоходные облигации легко дают дефолт: обычно их держат несколькими процентами.');
        }
      }
    }

    if (spec.kind == InstrumentKind.bond && spec.couponType != CouponType.floater) {
      final d = e.durationOf(id);
      if (d >= longDuration) {
        warnings.add('Длинная облигация: дюрация ${d.toStringAsFixed(1)} г. При росте ставки на 2 п. п. цена может упасть примерно на ${(2 * d).toStringAsFixed(0)}%.');
      } else if (d > 0) {
        notes.add('Дюрация ${d.toStringAsFixed(1)} г.: при росте ставки на 1 п. п. цена примерно изменится на ${d.toStringAsFixed(1)}%.');
      }
    }

    if (spec.kind == InstrumentKind.bond && spec.offerAtCouponsLeft != null && !(st.bond?.offerDone ?? true)) {
      notes.add('У выпуска есть оферта. Следите за датой: если условия изменятся, выкуп только по вашей заявке.');
    }

    if (spec.kind == InstrumentKind.stock && spec.divYield > 0) {
      final untilEx = ((spec.divDay - e.day % 365) + 365) % 365;
      if (untilEx >= 1 && untilEx <= 5) {
        warnings.add('До дивидендной отсечки $untilEx дн. После неё цена обычно падает примерно на размер дивиденда. '
            'Покупка ради выплаты не даёт бесплатной прибыли.');
      }
    }

    if (nkd > 0) {
      notes.add('Вы платите продавцу НКД ${nkd.toStringAsFixed(0)} ₽. Это не потеря: он вернётся с ближайшим купоном.');
    }

    if (spec.spreadBps >= 40) {
      notes.add('Широкий спред (${spec.spreadBps.toStringAsFixed(0)} б. п.): сделка заметно дороже обычной.');
    }

    notes.add('Издержки сделки около ${(fee + spreadCost).toStringAsFixed(0)} ₽ (комиссия и спред).');

    return TradePreviewResult(gross: gross, fee: fee, nkd: nkd, total: total, warnings: warnings, notes: notes);
  }

  static TradePreviewResult sell(SimEngine e, String id, int lots) {
    final st = e.state(id)!;
    final spec = st.spec;
    final q = e.quote(id);
    final units = lots * spec.lotSize.toDouble();
    final held = e.units(id);
    final nkd = units * q.accruedPerUnit;
    final gross = units * q.bid;
    final fee = (gross + nkd) * e.config.feeRate;
    final total = gross + nkd - fee;

    final lotsHeld = e.lotsOf(id);
    var cost = 0.0;
    for (final l in lotsHeld) {
      cost += l.units * l.costPerUnit;
    }
    final avgCost = held > 0 ? cost / held : 0.0;
    final pnl = (q.bid - avgCost) * units;

    final warnings = <String>[];
    final notes = <String>[];

    if (units >= held - 1e-9) {
      notes.add('Вы продаёте всю позицию.');
    } else if (held > 0 && units / held > 0.5) {
      notes.add('Вы продаёте больше половины позиции.');
    }
    if (pnl > 0) {
      final tax = pnl * e.config.taxRate;
      notes.add('Оценка налога с прибыли ≈ ${tax.toStringAsFixed(0)} ₽ (без учёта перенесённых убытков).');
    } else if (pnl < 0) {
      notes.add('Продажа с убытком ≈ ${pnl.toStringAsFixed(0)} ₽. Он уменьшит налог с прибыли по другим сделкам.');
    }
    if (spec.kind == InstrumentKind.bond && spec.couponType != CouponType.floater && units > 0) {
      notes.add('Продажа облигации до погашения: цену определяет рынок, а не номинал.');
    }
    notes.add('Издержки продажи около ${fee.toStringAsFixed(0)} ₽ (комиссия).');

    return TradePreviewResult(gross: gross, fee: fee, nkd: nkd, total: total, warnings: warnings, notes: notes);
  }
}
