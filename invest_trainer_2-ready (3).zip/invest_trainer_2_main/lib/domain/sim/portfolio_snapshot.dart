import 'engine_models.dart';

class PositionView {
  final String id;
  final String name;
  final AssetGroup group;
  final Sector sector;
  final String issuer;
  final double units;
  final double value; // по рыночной цене, с НКД
  final double weight; // доля в капитале
  final double costBasis;
  final double pnl;
  final double duration;

  const PositionView({
    required this.id,
    required this.name,
    required this.group,
    required this.sector,
    required this.issuer,
    required this.units,
    required this.value,
    required this.weight,
    required this.costBasis,
    required this.pnl,
    required this.duration,
  });

  double get pnlPct => costBasis > 0 ? pnl / costBasis * 100 : 0;
}

/// Снимок портфеля на конкретный день.
class PortfolioSnapshot {
  final int day;
  final double cash;
  final double total;
  final List<PositionView> positions;
  final Map<AssetGroup, double> byGroup;
  final Map<Sector, double> bySector;
  final Map<String, double> byIssuer;
  final double duration; // средневзвешенная дюрация облигационной части, лет
  final double income12m; // ожидаемый купонный и дивидендный доход за год до налогов
  final double feesPaid;
  final double taxesPaid;

  const PortfolioSnapshot({
    required this.day,
    required this.cash,
    required this.total,
    required this.positions,
    required this.byGroup,
    required this.bySector,
    required this.byIssuer,
    required this.duration,
    required this.income12m,
    required this.feesPaid,
    required this.taxesPaid,
  });

  double get invested => total - cash;

  double groupWeight(AssetGroup g) => total > 0 ? (byGroup[g] ?? 0) / total : 0;

  double get cashWeight => total > 0 ? cash / total : 0;

  double valueOfGroup(AssetGroup g) => byGroup[g] ?? 0;

  double get maxIssuerWeight {
    var m = 0.0;
    for (final v in byIssuer.values) {
      if (total > 0 && v / total > m) m = v / total;
    }
    return m;
  }

  /// Значение одной позиции или 0.
  double valueOf(String id) {
    for (final p in positions) {
      if (p.id == id) return p.value;
    }
    return 0;
  }
}

class DayValue {
  final int day;
  final double value;
  const DayValue(this.day, this.value);
}
