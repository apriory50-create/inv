import 'engine_models.dart';
import 'portfolio_snapshot.dart';

/// Типичные ошибки инвестора. Каждая связана с уроком Академии.
enum MistakeType {
  fomo,
  panicSell,
  concentration,
  durationInHike,
  dividendTrap,
  missedOffer,
  averagingDown,
  cashDrag,
  overtrading,
  vdoOversize,
  noDiversification,
}

class MistakeInfo {
  final String title;
  final String plain;
  final int lessonId;
  const MistakeInfo(this.title, this.plain, this.lessonId);
}

const Map<MistakeType, MistakeInfo> kMistakes = {
  MistakeType.fomo: MistakeInfo(
    'Покупка «на эмоциях» (FOMO)',
    'Вы купили бумагу после резкого роста, боясь «упустить выгоду». В такие моменты крупные игроки часто фиксируют прибыль, а цена возвращается назад.',
    8,
  ),
  MistakeType.panicSell: MistakeInfo(
    'Продажа на панике',
    'Вы продали бумагу с убытком из-за страха, хотя в самой компании ничего не изменилось. Так вы превратили временное падение в реальный убыток.',
    8,
  ),
  MistakeType.concentration: MistakeInfo(
    'Слишком большая доля одного эмитента',
    'Когда один эмитент занимает большую часть портфеля, его проблемы бьют по всему капиталу. Диверсификация защищает от таких ситуаций.',
    9,
  ),
  MistakeType.durationInHike: MistakeInfo(
    'Рост дюрации при повышении ставки',
    'Вы увеличили долю длинных облигаций в момент, когда ставка росла. Цена длинных облигаций падает при росте ставки сильнее всего.',
    20,
  ),
  MistakeType.dividendTrap: MistakeInfo(
    'Покупка ради дивиденда перед отсечкой',
    'Вы купили акцию за несколько дней до дивидендной отсечки. После отсечки цена падает примерно на размер дивиденда, поэтому «быстрой прибыли» нет, а налог платить придётся.',
    32,
  ),
  MistakeType.missedOffer: MistakeInfo(
    'Пропущена оферта',
    'Эмитент снизил купон, а вы не подали заявку на выкуп по номиналу. Цена облигации резко упала. Оферту нужно отслеживать заранее.',
    22,
  ),
  MistakeType.averagingDown: MistakeInfo(
    'Докупка падающей бумаги без анализа',
    'Вы докупили бумагу, которая сильно упала, не выяснив причину. Если проблема в самом эмитенте, усреднение увеличивает убыток.',
    58,
  ),
  MistakeType.cashDrag: MistakeInfo(
    'Слишком много денег без дела',
    'Большая доля свободных денег при росте рынка снижает результат: инфляция и ставка уже работают против «пустых» денег. Часть можно держать в фонде денежного рынка.',
    29,
  ),
  MistakeType.overtrading: MistakeInfo(
    'Слишком частые сделки',
    'Много сделок за короткий срок — это комиссии, спред и налоги. Они постепенно съедают результат, а реакция на каждое колебание редко помогает.',
    111,
  ),
  MistakeType.vdoOversize: MistakeInfo(
    'Слишком большая доля ВДО',
    'Высокодоходные облигации легко дают дефолт. Больше 5–10% капитала в них — риск потерять заметную часть портфеля.',
    25,
  ),
  MistakeType.noDiversification: MistakeInfo(
    'Портфель из 1–3 эмитентов',
    'Если в портфеле очень мало эмитентов, любая плохая новость по одному из них сильно бьёт по результату.',
    9,
  ),
};

/// Параметры сценария: как событие влияет на рынок.
class ScenarioParams {
  final double keyRateDelta; // изменение ключевой ставки, п. п.
  final double curveShift; // сдвиг доходностей облигаций без изменения ставки (ожидания), п. п.
  final double marketShift; // общее движение рынка акций, %
  final double fxDelta; // рост курса иностранной валюты (ослабление рубля), %
  final double creditSpreadDelta; // расширение кредитных спредов, п. п.
  final double inflationDelta; // изменение инфляции, п. п.
  final double goldShift; // дополнительное движение золота, %
  final Map<Sector, double> sectorShift; // % по отраслям
  final Map<String, double> instrumentShift; // % по конкретным акциям и фондам
  final Map<String, double> instrumentYield; // п. п. по конкретным облигациям
  final List<String> defaultIssuers; // эмитенты, объявившие дефолт
  final Map<String, double> divYieldSet; // новая дивидендная доходность (доля)
  final int rampDays; // за сколько дней проявляется эффект
  final bool fundamentalsChanged; // изменился ли бизнес (для оценки «паники»)

  const ScenarioParams({
    this.keyRateDelta = 0,
    this.curveShift = 0,
    this.marketShift = 0,
    this.fxDelta = 0,
    this.creditSpreadDelta = 0,
    this.inflationDelta = 0,
    this.goldShift = 0,
    this.sectorShift = const {},
    this.instrumentShift = const {},
    this.instrumentYield = const {},
    this.defaultIssuers = const [],
    this.divYieldSet = const {},
    this.rampDays = 3,
    this.fundamentalsChanged = true,
  });
}

/// Машиночитаемая рекомендация: часть капитала из групп [fromGroups] перекладывается в [toIds].
class RecommendedMove {
  final List<AssetGroup> fromGroups;
  final List<String> toIds;
  final double pct; // доля стоимости исходных групп, 0..1
  final String why;

  const RecommendedMove({
    required this.fromGroups,
    required this.toIds,
    required this.pct,
    required this.why,
  });
}

class Scenario {
  final String id;
  final String category;
  final int difficulty; // 1..3
  final String headline;
  final String news;
  final String plain; // что произошло простыми словами
  final List<String> signs; // косвенные признаки
  final ScenarioParams params;
  final List<String> best; // что стоит рассмотреть
  final List<String> bad; // чего лучше не делать
  final List<MistakeType> mistakes; // какие ошибки типичны
  final List<int> lessonIds;
  final List<RecommendedMove> recommended;

  const Scenario({
    required this.id,
    required this.category,
    required this.difficulty,
    required this.headline,
    required this.news,
    required this.plain,
    required this.signs,
    required this.params,
    required this.best,
    required this.bad,
    required this.mistakes,
    required this.lessonIds,
    this.recommended = const [],
  });
}

/// Запись о запущенном сценарии: нужна для итогового разбора.
class ScenarioRecord {
  final Scenario scenario;
  final int startDay;
  final PortfolioSnapshot before;
  final int tradeStart;
  final int eventStart;

  const ScenarioRecord({
    required this.scenario,
    required this.startDay,
    required this.before,
    required this.tradeStart,
    required this.eventStart,
  });
}

/// Пропущенная оферта (для разбора ошибок).
class MissedOffer {
  final int day;
  final String instrumentId;
  final double unitsHeld;
  const MissedOffer(this.day, this.instrumentId, this.unitsHeld);
}
