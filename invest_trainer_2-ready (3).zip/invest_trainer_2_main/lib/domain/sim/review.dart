import 'dart:math' as math;

import 'engine_models.dart';
import 'scenario_model.dart';
import 'sim_engine.dart';

enum Verdict { excellent, good, risky, mistake }

extension VerdictLabel on Verdict {
  String get label {
    switch (this) {
      case Verdict.excellent:
        return 'Отлично';
      case Verdict.good:
        return 'Нормально';
      case Verdict.risky:
        return 'Рискованно';
      case Verdict.mistake:
        return 'Есть серьёзные ошибки';
    }
  }
}

class Finding {
  final MistakeType type;
  final String detail;
  const Finding(this.type, this.detail);

  MistakeInfo get info => kMistakes[type]!;
}

class ScenarioReview {
  final Scenario scenario;
  final int startDay;
  final int endDay;
  final double valueBefore;
  final double valueAfter;
  final double changeRub;
  final double changePct;
  final double doNothingPct;
  final double? recommendedPct;
  final String recommendedWhy;
  final Verdict verdict;
  final String headline;
  final List<String> summaryLines;
  final List<Finding> findings;
  final List<String> goodDecisions;
  final List<String> nextTimeChecklist;
  final List<int> lessonIds;

  const ScenarioReview({
    required this.scenario,
    required this.startDay,
    required this.endDay,
    required this.valueBefore,
    required this.valueAfter,
    required this.changeRub,
    required this.changePct,
    required this.doNothingPct,
    required this.recommendedPct,
    required this.recommendedWhy,
    required this.verdict,
    required this.headline,
    required this.summaryLines,
    required this.findings,
    required this.goodDecisions,
    required this.nextTimeChecklist,
    required this.lessonIds,
  });
}

/// Разбор действий пользователя после сценария: что произошло, что было бы при других решениях и какие ошибки допущены.
class ReviewEngine {
  const ReviewEngine._();

  static const _severe = {
    MistakeType.panicSell,
    MistakeType.concentration,
    MistakeType.missedOffer,
    MistakeType.averagingDown,
    MistakeType.vdoOversize,
  };

  static String _sign(double v) => v >= 0 ? '+' : '';
  static String _pct(double v) => '${_sign(v)}${v.toStringAsFixed(1)}%';
  static String _rub(double v) => '${_sign(v)}${v.toStringAsFixed(0)} ₽';

  /// Ожидаемое изменение стоимости портфеля (в % от капитала), если держать позиции без изменений.
  static double expectedChangePct(SimEngine e, Map<String, double> values, double total, ScenarioParams p) {
    if (total <= 0) return 0;
    var delta = 0.0;
    values.forEach((id, v) {
      delta += v * e.expectedPct(id, p) / 100;
    });
    return delta / total * 100;
  }

  /// Применяет рекомендованные перекладки к значениям позиций. Возвращает false, если ни одна не применима.
  static bool _applyMoves(SimEngine e, Map<String, double> values, List<RecommendedMove> moves) {
    var applied = false;
    for (final m in moves) {
      final fromIds = values.keys.where((id) => m.fromGroups.contains(e.state(id)!.spec.group)).toList();
      final sumFrom = fromIds.fold<double>(0, (s, id) => s + values[id]!);
      if (sumFrom <= 0) continue;
      final amount = sumFrom * m.pct;
      for (final id in fromIds) {
        values[id] = values[id]! - amount * (values[id]! / sumFrom);
      }
      final targets = m.toIds.where((id) => e.state(id) != null).toList();
      if (targets.isEmpty) continue;
      for (final id in targets) {
        values[id] = (values[id] ?? 0) + amount / targets.length;
      }
      applied = true;
    }
    return applied;
  }

  static ScenarioReview review(SimEngine e, ScenarioRecord rec) {
    final sc = rec.scenario;
    final p = sc.params;
    final before = rec.before;
    final after = e.snapshot();
    final endDay = e.day;
    final trades = e.trades.sublist(math.min(rec.tradeStart, e.trades.length));

    final valueBefore = before.total;
    final valueAfter = after.total;
    final changeRub = valueAfter - valueBefore;
    final changePct = valueBefore > 0 ? changeRub / valueBefore * 100 : 0.0;

    // «Ничего не делать» и «рекомендация» — на снимке «до».
    final baseValues = {for (final pos in before.positions) pos.id: pos.value};
    final doNothing = expectedChangePct(e, baseValues, valueBefore, p);
    double? recommended;
    if (sc.recommended.isNotEmpty) {
      final moved = Map<String, double>.of(baseValues);
      if (_applyMoves(e, moved, sc.recommended)) {
        recommended = expectedChangePct(e, moved, valueBefore, p);
      }
    }
    final recommendedWhy = sc.recommended.map((m) => m.why).join(' ');

    final findings = <Finding>[];
    final good = <String>[];

    // ---- паника
    if (!p.fundamentalsChanged) {
      for (final t in trades) {
        final spec = e.state(t.id)!.spec;
        if (t.side != TradeSide.sell || spec.kind == InstrumentKind.bond) continue;
        final drop = e.priceChangeBetween(t.id, rec.startDay, t.day);
        if (drop <= -4 && t.realizedPnl < 0) {
          findings.add(Finding(
            MistakeType.panicSell,
            'Вы продали «${spec.name}» с убытком ${_rub(t.realizedPnl)} после падения цены на ${drop.abs().toStringAsFixed(1)}%, хотя в самом бизнесе новости не ухудшились.',
          ));
        }
      }
    }
    // ---- FOMO, ловушка дивидендов, усреднение
    for (final t in trades) {
      if (t.side != TradeSide.buy) continue;
      final spec = e.state(t.id)!.spec;
      final rise = e.priceChangeBetween(t.id, t.day - 5, t.day);
      if (spec.kind != InstrumentKind.bond && rise >= 8) {
        findings.add(Finding(
          MistakeType.fomo,
          'Вы купили «${spec.name}» после роста цены на ${rise.toStringAsFixed(1)}% за 5 дней. Такие покупки часто совпадают с локальной вершиной.',
        ));
      }
      if (spec.kind == InstrumentKind.stock && spec.divYield > 0) {
        final untilEx = ((spec.divDay - t.day % 365) + 365) % 365;
        if (untilEx >= 1 && untilEx <= 5) {
          findings.add(Finding(
            MistakeType.dividendTrap,
            'Вы купили «${spec.name}» за $untilEx дн. до дивидендной отсечки: после неё цена упадёт примерно на размер дивиденда.',
          ));
        }
      }
      final held = before.valueOf(t.id) > 0;
      final fall = e.priceChangeBetween(t.id, rec.startDay, t.day);
      if (held && fall <= -12) {
        findings.add(Finding(
          MistakeType.averagingDown,
          'Вы докупили «${spec.name}», которая упала на ${fall.abs().toStringAsFixed(1)}%. Это оправдано, только если причина падения не в самом эмитенте.',
        ));
      }
    }
    // ---- частые сделки
    if (trades.length >= 8) {
      final fees = after.feesPaid - before.feesPaid;
      findings.add(Finding(
        MistakeType.overtrading,
        'За сценарий вы совершили ${trades.length} сделок; комиссии составили ${fees.toStringAsFixed(0)} ₽, к ним добавляются спред и налоги.',
      ));
    }
    // ---- структура после сценария
    if (after.invested > 0) {
      if (after.maxIssuerWeight > 0.25) {
        String name = '';
        var best = 0.0;
        after.byIssuer.forEach((k, v) {
          if (v > best) {
            best = v;
            name = k;
          }
        });
        findings.add(Finding(
          MistakeType.concentration,
          'На эмитента «$name» приходится ${(after.maxIssuerWeight * 100).toStringAsFixed(0)}% капитала. Для одного эмитента это слишком много.',
        ));
      }
      final vdo = after.groupWeight(AssetGroup.highYield);
      if (vdo > 0.10) {
        findings.add(Finding(
          MistakeType.vdoOversize,
          'Высокодоходные облигации занимают ${(vdo * 100).toStringAsFixed(0)}% портфеля. Разумный предел — несколько процентов.',
        ));
      }
      final direct = after.byIssuer.values.fold<double>(0, (a, b) => a + b);
      if (direct > 0 && direct / after.total > 0.3 && after.byIssuer.length <= 3) {
        findings.add(Finding(
          MistakeType.noDiversification,
          'В портфеле всего ${after.byIssuer.length} эмитента(ов) — плохая новость по одному из них сильно ударит по капиталу.',
        ));
      }
    }
    // ---- дюрация в цикле повышения ставки
    if (p.keyRateDelta >= 0.9) {
      final boughtLong = trades.any((t) => t.side == TradeSide.buy && e.state(t.id)!.spec.group.isFixedIncomeLong);
      if (boughtLong && after.duration > before.duration + 0.3) {
        findings.add(Finding(
          MistakeType.durationInHike,
          'Дюрация облигаций выросла с ${before.duration.toStringAsFixed(1)} до ${after.duration.toStringAsFixed(1)} года именно тогда, когда ставка выросла.',
        ));
      } else if (after.duration < before.duration - 0.3) {
        good.add('Вы сократили дюрацию облигаций с ${before.duration.toStringAsFixed(1)} до ${after.duration.toStringAsFixed(1)} года — правильная реакция на повышение ставки.');
      }
    }
    // ---- оферта
    for (final m in e.missedOffers) {
      if (m.day >= rec.startDay) {
        findings.add(Finding(
          MistakeType.missedOffer,
          'По «${e.state(m.instrumentId)!.spec.name}» вы пропустили оферту: купон снижен, цена облигации резко упала.',
        ));
      }
    }
    for (final ev in e.events.sublist(math.min(rec.eventStart, e.events.length))) {
      if (ev.type == EventType.offerResult && ev.text.contains('заявка исполнена')) {
        good.add('Вы вовремя подали заявку на оферту и вернули номинал: ${ev.text}');
      }
    }
    // ---- лишний кэш при росте рынка
    if (p.marketShift >= 3) {
      final idle = after.cash + after.valueOfGroup(AssetGroup.moneyFund);
      if (after.total > 0 && idle / after.total > 0.6) {
        findings.add(Finding(
          MistakeType.cashDrag,
          'В момент роста рынка ${(idle / after.total * 100).toStringAsFixed(0)}% капитала лежало в деньгах и денежном рынке, и рост прошёл мимо.',
        ));
      }
    }
    // ---- хорошие решения
    final sells = trades.where((t) => t.side == TradeSide.sell).length;
    final buys = trades.where((t) => t.side == TradeSide.buy).length;
    if (!p.fundamentalsChanged && p.marketShift <= -5 && sells == 0 && before.invested > 0) {
      good.add('Вы не продавали на панике: бизнес эмитентов не менялся, и это правильно.');
    }
    if (!p.fundamentalsChanged && p.marketShift <= -5 && buys > 0 && buys <= 3 && after.cashWeight > 0.1) {
      good.add('Вы докупали частями и оставили резерв денег — это снижает риск, если падение продолжится.');
    }
    if (after.byIssuer.length >= 5 && after.maxIssuerWeight < 0.2 && after.invested > 0) {
      good.add('Портфель разнообразен: ${after.byIssuer.length} эмитентов, самая большая доля — ${(after.maxIssuerWeight * 100).toStringAsFixed(0)}%.');
    }
    if (sc.category == 'Психология рынка' && p.marketShift > 0) {
      final profitSells = trades.where((t) => t.side == TradeSide.sell && t.realizedPnl > 0).length;
      if (profitSells > 0) good.add('Вы зафиксировали часть прибыли в период эйфории — зрелое решение.');
    }

    // ---- вердикт
    final diff = changePct - doNothing;
    final hasSevere = findings.any((f) => _severe.contains(f.type));
    Verdict verdict;
    if (findings.length >= 3 || (hasSevere && diff < -1)) {
      verdict = Verdict.mistake;
    } else if (findings.isNotEmpty) {
      verdict = Verdict.risky;
    } else if (diff > 0.5 || good.length >= 2) {
      verdict = Verdict.excellent;
    } else {
      verdict = Verdict.good;
    }

    final lines = <String>[
      'Капитал изменился с ${valueBefore.toStringAsFixed(0)} до ${valueAfter.toStringAsFixed(0)} ₽ (${_rub(changeRub)}, ${_pct(changePct)}).',
      'Если бы вы ничего не меняли, по модели сценария изменение составило бы примерно ${_pct(doNothing)}.',
      if (trades.isEmpty)
        'Вы не совершали сделок: результат определялся только структурой портфеля до события.'
      else
        'Ваши решения и случайные колебания рынка дали разницу ${_pct(diff)} относительно варианта «ничего не делать».',
      if (recommended != null)
        'Если бы вы заранее выполнили рекомендацию сценария, изменение составило бы примерно ${_pct(recommended)}.',
      if (recommended != null && recommendedWhy.isNotEmpty) 'Рекомендация: $recommendedWhy',
    ];

    final lessonIds = <int>{...sc.lessonIds, for (final f in findings) f.info.lessonId}.toList()..sort();
    final headline = switch (verdict) {
      Verdict.excellent => 'Отличный результат: решения были взвешенными',
      Verdict.good => 'Нормально: серьёзных ошибок не найдено',
      Verdict.risky => 'Рискованно: есть повод пересмотреть решения',
      Verdict.mistake => 'Есть серьёзные ошибки — разберите их ниже',
    };

    return ScenarioReview(
      scenario: sc,
      startDay: rec.startDay,
      endDay: endDay,
      valueBefore: valueBefore,
      valueAfter: valueAfter,
      changeRub: changeRub,
      changePct: changePct,
      doNothingPct: doNothing,
      recommendedPct: recommended,
      recommendedWhy: recommendedWhy,
      verdict: verdict,
      headline: headline,
      summaryLines: lines,
      findings: findings,
      goodDecisions: good,
      nextTimeChecklist: sc.best,
      lessonIds: lessonIds,
    );
  }
}
