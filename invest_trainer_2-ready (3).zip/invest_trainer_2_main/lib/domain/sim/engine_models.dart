// Модели движка симулятора. Без зависимостей от Flutter — движок тестируется на чистом Dart.

enum InstrumentKind { bond, stock, fund }

enum BondType { ofz, corporate, highYield, fxLinked }

enum CouponType { fixed, floater, linker }

enum FundType { indexFund, bond, money, gold, sector }

enum Sector {
  finance,
  energy,
  metals,
  retail,
  tech,
  utilities,
  realEstate,
  chemicals,
  telecom,
  transport,
  health,
  agro,
  goldMining,
  government,
  diversified,
}

extension SectorLabel on Sector {
  String get label {
    switch (this) {
      case Sector.finance:
        return 'Финансы';
      case Sector.energy:
        return 'Нефть и газ';
      case Sector.metals:
        return 'Металлы';
      case Sector.retail:
        return 'Ритейл';
      case Sector.tech:
        return 'IT';
      case Sector.utilities:
        return 'Электроэнергетика';
      case Sector.realEstate:
        return 'Девелопмент';
      case Sector.chemicals:
        return 'Химия и удобрения';
      case Sector.telecom:
        return 'Телеком';
      case Sector.transport:
        return 'Транспорт';
      case Sector.health:
        return 'Медицина';
      case Sector.agro:
        return 'Агро';
      case Sector.goldMining:
        return 'Золотодобыча';
      case Sector.government:
        return 'Государство';
      case Sector.diversified:
        return 'Диверсифицированный';
    }
  }
}

/// Группа активов для отчётов и рекомендаций.
enum AssetGroup {
  ofzFixed,
  ofzFloater,
  ofzLinker,
  corpBond,
  highYield,
  fxBond,
  stock,
  indexFund,
  bondFund,
  moneyFund,
  goldFund,
  sectorFund,
}

extension AssetGroupLabel on AssetGroup {
  String get label {
    switch (this) {
      case AssetGroup.ofzFixed:
        return 'ОФЗ с фиксированным купоном';
      case AssetGroup.ofzFloater:
        return 'ОФЗ-флоатеры';
      case AssetGroup.ofzLinker:
        return 'ОФЗ-линкеры';
      case AssetGroup.corpBond:
        return 'Корпоративные облигации';
      case AssetGroup.highYield:
        return 'Высокодоходные облигации (ВДО)';
      case AssetGroup.fxBond:
        return 'Валютные облигации';
      case AssetGroup.stock:
        return 'Акции';
      case AssetGroup.indexFund:
        return 'Индексные фонды';
      case AssetGroup.bondFund:
        return 'Фонды облигаций';
      case AssetGroup.moneyFund:
        return 'Фонды денежного рынка';
      case AssetGroup.goldFund:
        return 'Золото';
      case AssetGroup.sectorFund:
        return 'Отраслевые фонды';
    }
  }

  bool get isFixedIncomeLong =>
      this == AssetGroup.ofzFixed || this == AssetGroup.corpBond || this == AssetGroup.bondFund;
}

/// Описание инструмента. Все названия эмитентов вымышленные.
class InstrumentSpec {
  final String id;
  final String name;
  final String issuer;
  final InstrumentKind kind;
  final Sector sector;
  final String description; // «для чайника»
  final String suitsWhen; // когда подходит
  final String risksPlain; // главные риски простыми словами
  final int lotSize;
  final double spreadBps; // полный спред в б.п.

  // Акции и фонды
  final double startPrice;
  final double annualVol; // годовая волатильность, доля
  final double beta;
  final double fxSens;
  final double rateSens; // % падения цены за +1 п.п. ключевой ставки
  final double divYield; // годовая дивидендная доходность, доля
  final int divDay; // день года (0–364) дивидендной выплаты
  final bool preferred;
  final double ter; // годовая комиссия фонда, доля
  final FundType? fundType;
  final double fundDuration;
  final double fundYield; // доходность портфеля облигационного фонда, % годовых

  // Облигации
  final BondType? bondType;
  final CouponType couponType;
  final double nominal;
  final double couponRate; // % годовых (для флоатера — не используется)
  final double spreadToKey; // надбавка к ключевой ставке для флоатера, п. п.
  final int couponsPerYear;
  final int maturityDays;
  final double startYield; // % годовых (для флоатера — 0)
  final int amortPayments;
  final int? offerAtCouponsLeft; // оферта наступает при выплате купона, после которого осталось столько купонов
  final double offerNewCoupon;
  final double curveBeta; // чувствительность доходности к изменению ключевой ставки
  final double creditBeta; // чувствительность к расширению кредитных спредов
  final String rating;

  const InstrumentSpec({
    required this.id,
    required this.name,
    required this.issuer,
    required this.kind,
    required this.sector,
    required this.description,
    required this.suitsWhen,
    required this.risksPlain,
    this.lotSize = 1,
    this.spreadBps = 10,
    this.startPrice = 100,
    this.annualVol = 0.25,
    this.beta = 1.0,
    this.fxSens = 0.0,
    this.rateSens = 0.0,
    this.divYield = 0.0,
    this.divDay = 195,
    this.preferred = false,
    this.ter = 0.0,
    this.fundType,
    this.fundDuration = 0,
    this.fundYield = 0,
    this.bondType,
    this.couponType = CouponType.fixed,
    this.nominal = 1000,
    this.couponRate = 0,
    this.spreadToKey = 0,
    this.couponsPerYear = 2,
    this.maturityDays = 0,
    this.startYield = 0,
    this.amortPayments = 0,
    this.offerAtCouponsLeft,
    this.offerNewCoupon = 0.1,
    this.curveBeta = 0.7,
    this.creditBeta = 0.0,
    this.rating = '',
  });

  int get couponPeriodDays => (365 / couponsPerYear).round();

  bool get fxLinked => bondType == BondType.fxLinked;

  AssetGroup get group {
    switch (kind) {
      case InstrumentKind.stock:
        return AssetGroup.stock;
      case InstrumentKind.fund:
        switch (fundType!) {
          case FundType.indexFund:
            return AssetGroup.indexFund;
          case FundType.bond:
            return AssetGroup.bondFund;
          case FundType.money:
            return AssetGroup.moneyFund;
          case FundType.gold:
            return AssetGroup.goldFund;
          case FundType.sector:
            return AssetGroup.sectorFund;
        }
      case InstrumentKind.bond:
        switch (bondType!) {
          case BondType.ofz:
            switch (couponType) {
              case CouponType.fixed:
                return AssetGroup.ofzFixed;
              case CouponType.floater:
                return AssetGroup.ofzFloater;
              case CouponType.linker:
                return AssetGroup.ofzLinker;
            }
          case BondType.corporate:
            return AssetGroup.corpBond;
          case BondType.highYield:
            return AssetGroup.highYield;
          case BondType.fxLinked:
            return AssetGroup.fxBond;
        }
    }
  }
}

/// Партия бумаг (для расчета налога по методу ФИФО).
class Lot {
  double units;
  double costPerUnit; // цена покупки без НКД, включая долю комиссии
  double nkdPerUnit; // НКД, уплаченный при покупке
  final int day;

  Lot({required this.units, required this.costPerUnit, required this.nkdPerUnit, required this.day});
}

enum TradeSide { buy, sell }

class TradeRecord {
  final int day;
  final String id;
  final TradeSide side;
  final double units;
  final double price; // за штуку, без НКД
  final double nkd; // НКД всей сделки
  final double fee;
  final double tax;
  final double realizedPnl;

  const TradeRecord({
    required this.day,
    required this.id,
    required this.side,
    required this.units,
    required this.price,
    required this.nkd,
    required this.fee,
    this.tax = 0,
    this.realizedPnl = 0,
  });
}

class TradeResult {
  final bool ok;
  final String message;
  final double fee;
  final double tax;
  final double nkd;
  final double gross;
  final double price;

  const TradeResult({
    required this.ok,
    required this.message,
    this.fee = 0,
    this.tax = 0,
    this.nkd = 0,
    this.gross = 0,
    this.price = 0,
  });

  const TradeResult.fail(String message)
      : this(ok: false, message: message);
}

enum EventType {
  coupon,
  dividend,
  amortization,
  maturity,
  offerNotice,
  offerResult,
  defaultEvent,
  orderFilled,
  orderCancelled,
  scenario,
  info,
}

class SimEvent {
  final int day;
  final EventType type;
  final String text;
  final String? instrumentId;
  final double amount;

  const SimEvent(this.day, this.type, this.text, {this.instrumentId, this.amount = 0});
}

class Quote {
  final double mid;
  final double bid;
  final double ask;
  final double accruedPerUnit;
  final double? yieldPct;
  final double? pricePctOfNominal;
  final bool tradable;

  const Quote({
    required this.mid,
    required this.bid,
    required this.ask,
    this.accruedPerUnit = 0,
    this.yieldPct,
    this.pricePctOfNominal,
    this.tradable = true,
  });
}

class LimitOrder {
  final int orderId;
  final String instrumentId;
  final TradeSide side;
  final double lots;
  final double limitPrice;
  final int createdDay;

  const LimitOrder({
    required this.orderId,
    required this.instrumentId,
    required this.side,
    required this.lots,
    required this.limitPrice,
    required this.createdDay,
  });
}

class SimConfig {
  final double feeRate;
  final double taxRate;
  final bool ldvEnabled;
  final DateTime startDate;
  final double marketDrift; // дневной дрейф рынка
  final double marketVol; // дневная волатильность рынка

  SimConfig({
    this.feeRate = 0.0005,
    this.taxRate = 0.13,
    this.ldvEnabled = false,
    DateTime? startDate,
    this.marketDrift = 0.0003,
    this.marketVol = 0.011,
  }) : startDate = startDate ?? DateTime(2026, 1, 1);
}
