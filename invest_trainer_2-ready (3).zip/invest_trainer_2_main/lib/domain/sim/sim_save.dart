import 'dart:convert';

import 'engine_models.dart';
import 'portfolio_snapshot.dart';
import 'review.dart';
import 'scenario_catalog.dart';
import 'scenario_model.dart';
import 'sim_engine.dart';

/// Данные сохранения симулятора: движок, пройденные разборы и активный сценарий.
class SimSaveData {
  final SimEngine engine;
  final List<ScenarioReview> reviews;
  final ScenarioRecord? active;

  const SimSaveData(this.engine, this.reviews, this.active);
}

/// Кодек сохранения. Сценарии хранятся по id и восстанавливаются из каталога,
/// поэтому правка текста сценария не ломает старые сохранения.
class SimSave {
  const SimSave._();

  static const int version = 1;

  static String encode({
    required SimEngine engine,
    required List<ScenarioReview> reviews,
    ScenarioRecord? active,
  }) {
    return jsonEncode({
      'v': version,
      'engine': engine.toJson(),
      'reviews': [for (final r in reviews) _reviewJson(r)],
      'active': active == null ? null : _recordJson(active),
    });
  }

  /// Возвращает null, если данные повреждены или версия неизвестна.
  static SimSaveData? decode(String raw) {
    try {
      final m = jsonDecode(raw) as Map<String, Object?>;
      if ((m['v'] as num?)?.toInt() != version) return null;
      final engine = SimEngine.fromJson(Map<String, Object?>.from(m['engine'] as Map));
      final reviews = <ScenarioReview>[
        for (final r in m['reviews'] as List)
          if (_reviewFrom(Map<String, Object?>.from(r as Map)) case final rv?) rv,
      ];
      final activeRaw = m['active'];
      final active = activeRaw == null ? null : _recordFrom(Map<String, Object?>.from(activeRaw as Map));
      return SimSaveData(engine, reviews, active);
    } catch (_) {
      return null;
    }
  }

  // ---------------------------------------------------------------- снимок портфеля

  static double _d(Object? v) => (v as num).toDouble();

  static Map<String, Object?> _snapJson(PortfolioSnapshot s) => {
        'day': s.day,
        'cash': s.cash,
        'total': s.total,
        'duration': s.duration,
        'income': s.income12m,
        'fees': s.feesPaid,
        'taxes': s.taxesPaid,
        'positions': [
          for (final p in s.positions)
            {
              'id': p.id,
              'name': p.name,
              'group': p.group.name,
              'sector': p.sector.name,
              'issuer': p.issuer,
              'units': p.units,
              'value': p.value,
              'weight': p.weight,
              'cost': p.costBasis,
              'pnl': p.pnl,
              'duration': p.duration,
            },
        ],
        'byGroup': {for (final e in s.byGroup.entries) e.key.name: e.value},
        'bySector': {for (final e in s.bySector.entries) e.key.name: e.value},
        'byIssuer': s.byIssuer,
      };

  static PortfolioSnapshot _snapFrom(Map<String, Object?> m) {
    final positions = [
      for (final x in m['positions'] as List)
        PositionView(
          id: (x as Map)['id'] as String,
          name: x['name'] as String,
          group: AssetGroup.values.byName(x['group'] as String),
          sector: Sector.values.byName(x['sector'] as String),
          issuer: x['issuer'] as String,
          units: _d(x['units']),
          value: _d(x['value']),
          weight: _d(x['weight']),
          costBasis: _d(x['cost']),
          pnl: _d(x['pnl']),
          duration: _d(x['duration']),
        ),
    ];
    return PortfolioSnapshot(
      day: (m['day'] as num).toInt(),
      cash: _d(m['cash']),
      total: _d(m['total']),
      positions: positions,
      byGroup: {
        for (final e in (m['byGroup'] as Map).entries) AssetGroup.values.byName(e.key as String): _d(e.value),
      },
      bySector: {
        for (final e in (m['bySector'] as Map).entries) Sector.values.byName(e.key as String): _d(e.value),
      },
      byIssuer: {for (final e in (m['byIssuer'] as Map).entries) e.key as String: _d(e.value)},
      duration: _d(m['duration']),
      income12m: _d(m['income']),
      feesPaid: _d(m['fees']),
      taxesPaid: _d(m['taxes']),
    );
  }

  // ---------------------------------------------------------------- разбор

  static Map<String, Object?> _reviewJson(ScenarioReview r) => {
        'sid': r.scenario.id,
        'startDay': r.startDay,
        'endDay': r.endDay,
        'valueBefore': r.valueBefore,
        'valueAfter': r.valueAfter,
        'changeRub': r.changeRub,
        'changePct': r.changePct,
        'doNothing': r.doNothingPct,
        'rec': r.recommendedPct,
        'recWhy': r.recommendedWhy,
        'verdict': r.verdict.name,
        'headline': r.headline,
        'summary': r.summaryLines,
        'findings': [for (final f in r.findings) {'t': f.type.name, 'd': f.detail}],
        'good': r.goodDecisions,
        'lessons': r.lessonIds,
      };

  static ScenarioReview? _reviewFrom(Map<String, Object?> m) {
    final sc = ScenarioCatalog.byId(m['sid'] as String);
    if (sc == null) return null; // сценарий удалён из каталога
    final rec = m['rec'];
    return ScenarioReview(
      scenario: sc,
      startDay: (m['startDay'] as num).toInt(),
      endDay: (m['endDay'] as num).toInt(),
      valueBefore: _d(m['valueBefore']),
      valueAfter: _d(m['valueAfter']),
      changeRub: _d(m['changeRub']),
      changePct: _d(m['changePct']),
      doNothingPct: _d(m['doNothing']),
      recommendedPct: rec == null ? null : _d(rec),
      recommendedWhy: m['recWhy'] as String,
      verdict: Verdict.values.byName(m['verdict'] as String),
      headline: m['headline'] as String,
      summaryLines: [for (final x in m['summary'] as List) x as String],
      findings: [
        for (final f in m['findings'] as List)
          Finding(MistakeType.values.byName((f as Map)['t'] as String), f['d'] as String),
      ],
      goodDecisions: [for (final x in m['good'] as List) x as String],
      nextTimeChecklist: sc.best,
      lessonIds: [for (final x in m['lessons'] as List) (x as num).toInt()],
    );
  }

  // ---------------------------------------------------------------- активный сценарий

  static Map<String, Object?> _recordJson(ScenarioRecord r) => {
        'sid': r.scenario.id,
        'startDay': r.startDay,
        'before': _snapJson(r.before),
        'tradeStart': r.tradeStart,
        'eventStart': r.eventStart,
      };

  static ScenarioRecord? _recordFrom(Map<String, Object?> m) {
    final sc = ScenarioCatalog.byId(m['sid'] as String);
    if (sc == null) return null;
    return ScenarioRecord(
      scenario: sc,
      startDay: (m['startDay'] as num).toInt(),
      before: _snapFrom(Map<String, Object?>.from(m['before'] as Map)),
      tradeStart: (m['tradeStart'] as num).toInt(),
      eventStart: (m['eventStart'] as num).toInt(),
    );
  }
}
