import 'dart:math' as math;

/// Один денежный поток облигации: через [days] дней, [amount] — в долях ИСХОДНОГО номинала.
class CashFlow {
  final double days;
  final double amount;
  const CashFlow(this.days, this.amount);
}

/// Чистая математика облигаций: денежные потоки, цена по доходности, доходность по цене, дюрация.
/// Все цены — в долях исходного номинала (1.0 = 100%).
class BondMath {
  const BondMath._();

  /// Денежные потоки облигации.
  ///
  /// [couponsLeft] — сколько купонов осталось (включая ближайший);
  /// [daysToNext] — дней до ближайшего купона; [period] — дней в купонном периоде;
  /// [remainingFrac] — остаток номинала (доля от исходного);
  /// [amortPayments] — на сколько равных частей гасится номинал в последних купонах (0 — одним платежом в конце);
  /// [amortLeft] — сколько амортизационных платежей еще осталось.
  static List<CashFlow> cashFlows({
    required int couponsLeft,
    required int daysToNext,
    required int period,
    required double couponRatePct,
    required int freq,
    required double remainingFrac,
    int amortPayments = 0,
    int amortLeft = 0,
  }) {
    final flows = <CashFlow>[];
    var balance = remainingFrac;
    for (var i = 1; i <= couponsLeft; i++) {
      final coupon = couponRatePct / 100 / freq * balance;
      double amort;
      if (amortPayments > 0) {
        amort = (couponsLeft - i) < amortLeft ? 1.0 / amortPayments : 0.0;
        if (amort > balance) amort = balance;
      } else {
        amort = i == couponsLeft ? balance : 0.0;
      }
      flows.add(CashFlow((daysToNext + (i - 1) * period).toDouble(), coupon + amort));
      balance -= amort;
    }
    return flows;
  }

  /// Грязная цена (с НКД) в долях исходного номинала при доходности [yieldPct] годовых.
  static double dirtyFrac(List<CashFlow> flows, double yieldPct, int freq, int period) {
    final y = math.max(-freq * 100.0 + 1.0, yieldPct) / 100 / freq;
    var sum = 0.0;
    for (final f in flows) {
      sum += f.amount / math.pow(1 + y, f.days / period);
    }
    return sum;
  }

  /// НКД в долях исходного номинала.
  static double accruedFrac({
    required double couponRatePct,
    required int freq,
    required double remainingFrac,
    required int daysSince,
    required int period,
  }) {
    return couponRatePct / 100 / freq * remainingFrac * daysSince / period;
  }

  /// Доходность (в % годовых) по грязной цене. Бисекция: цена убывает с ростом доходности.
  static double yieldFromDirty(List<CashFlow> flows, double dirtyTarget, int freq, int period) {
    var lo = -50.0;
    var hi = 300.0;
    for (var i = 0; i < 80; i++) {
      final mid = (lo + hi) / 2;
      if (dirtyFrac(flows, mid, freq, period) > dirtyTarget) {
        lo = mid;
      } else {
        hi = mid;
      }
    }
    return (lo + hi) / 2;
  }

  /// Модифицированная дюрация в годах (численно).
  static double modifiedDuration(List<CashFlow> flows, double yieldPct, int freq, int period) {
    const bump = 0.01; // 0,01 п. п.
    final p0 = dirtyFrac(flows, yieldPct, freq, period);
    if (p0 <= 0) return 0;
    final up = dirtyFrac(flows, yieldPct + bump, freq, period);
    final down = dirtyFrac(flows, yieldPct - bump, freq, period);
    return -(up - down) / (2 * bump / 100) / p0;
  }
}
