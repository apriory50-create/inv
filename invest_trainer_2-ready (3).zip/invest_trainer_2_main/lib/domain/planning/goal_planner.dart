import 'dart:math' as math;

/// Планировщик цели: сколько откладывать каждый месяц, чтобы накопить сумму к сроку.
/// Считаем с ежемесячной капитализацией и взносами в конце месяца. Это расчёт, а не обещание доходности.
class GoalPlanner {
  const GoalPlanner._();

  /// Месячная ставка, эквивалентная годовой.
  static double monthlyRate(double annual) => math.pow(1 + annual, 1 / 12).toDouble() - 1;

  /// Будущая стоимость накоплений.
  static double futureValue({
    required double start,
    required double monthly,
    required double annualReturn,
    required int years,
  }) {
    final n = years * 12;
    final r = monthlyRate(annualReturn);
    if (r == 0) return start + monthly * n;
    final g = math.pow(1 + r, n).toDouble();
    return start * g + monthly * (g - 1) / r;
  }

  /// Ежемесячный взнос, при котором накопления достигнут [target] к сроку.
  /// Возвращает 0, если стартовой суммы уже достаточно.
  static double requiredMonthly({
    required double target,
    required double start,
    required double annualReturn,
    required int years,
  }) {
    if (years <= 0) throw ArgumentError('Срок должен быть больше нуля.');
    final n = years * 12;
    final r = monthlyRate(annualReturn);
    if (r == 0) return math.max(0.0, (target - start) / n);
    final g = math.pow(1 + r, n).toDouble();
    final pmt = (target - start * g) * r / (g - 1);
    return math.max(0.0, pmt);
  }

  /// Сумма в сегодняшних деньгах: сколько будет стоить [target] через [years] при инфляции [inflation].
  static double targetInTodayMoney({required double target, required double inflation, required int years}) =>
      target / math.pow(1 + inflation, years).toDouble();

  /// Сравнение нескольких доходностей: сколько откладывать и что накопится.
  static List<GoalScenario> scenarios({
    required double target,
    required double start,
    required int years,
    List<double> returns = const [0.05, 0.08, 0.12],
  }) {
    return [
      for (final r in returns)
        GoalScenario(
          annualReturn: r,
          years: years,
          monthly: requiredMonthly(target: target, start: start, annualReturn: r, years: years),
        ),
    ];
  }
}

class GoalScenario {
  final double annualReturn;
  final int years;
  final double monthly;

  const GoalScenario({required this.annualReturn, required this.years, required this.monthly});

  /// Сумма, которую вы сами внесёте за весь срок.
  double get totalContributed => monthly * years * 12;
}
