import '../../features/portfolio/portfolio_models.dart';

/// Классы для сравнения с шаблоном. Совпадают по смыслу с видами позиций.
enum AssetClass {
  bonds('Облигации'),
  stocks('Акции'),
  funds('Фонды'),
  gold('Золото'),
  cash('Деньги'),
  other('Прочее');

  const AssetClass(this.label);
  final String label;
}

class PortfolioTemplate {
  final String id;
  final String name;
  final String description;
  final String riskNote;

  /// Доли классов. Сумма должна быть 1 (кроме «Прочее», у шаблонов оно 0).
  final Map<AssetClass, double> shares;

  const PortfolioTemplate({
    required this.id,
    required this.name,
    required this.description,
    required this.riskNote,
    required this.shares,
  });
}

class TemplateLine {
  final AssetClass cls;
  final double targetShare;
  final double currentShare;

  const TemplateLine(this.cls, this.targetShare, this.currentShare);

  /// Отклонение в процентных пунктах (положительное — больше, чем в шаблоне).
  double get diffPp => (currentShare - targetShare) * 100;

  String get advice {
    if (diffPp.abs() <= 5) return 'В пределах 5 п. п. от шаблона';
    return diffPp > 0 ? 'Больше шаблона: можно сократить или не докупать' : 'Меньше шаблона: можно докупить постепенно';
  }
}

class PortfolioTemplates {
  const PortfolioTemplates._();

  static const List<PortfolioTemplate> all = [
    PortfolioTemplate(
      id: 'conservative',
      name: 'Консервативный',
      description: 'Главное — сохранить деньги. Основа в облигациях и деньгах, небольшая доля акций и золота.',
      riskNote: 'Просадки обычно небольшие, но и рост скромный.',
      shares: {AssetClass.bonds: 0.6, AssetClass.stocks: 0.1, AssetClass.funds: 0, AssetClass.gold: 0.1, AssetClass.cash: 0.2, AssetClass.other: 0},
    ),
    PortfolioTemplate(
      id: 'balanced',
      name: 'Сбалансированный',
      description: 'Баланс роста и защиты: заметная доля облигаций и акций, фонды для диверсификации.',
      riskNote: 'Просадки умеренные, горизонт от 3 лет.',
      shares: {AssetClass.bonds: 0.4, AssetClass.stocks: 0.35, AssetClass.funds: 0.1, AssetClass.gold: 0.05, AssetClass.cash: 0.1, AssetClass.other: 0},
    ),
    PortfolioTemplate(
      id: 'growth',
      name: 'Рост',
      description: 'Ставка на рост капитала: акции в основе, облигации и деньги как запас.',
      riskNote: 'Большие просадки возможны. Нужен горизонт 5 лет и больше.',
      shares: {AssetClass.bonds: 0.15, AssetClass.stocks: 0.6, AssetClass.funds: 0.15, AssetClass.gold: 0.05, AssetClass.cash: 0.05, AssetClass.other: 0},
    ),
    PortfolioTemplate(
      id: 'dividend',
      name: 'Доходный',
      description: 'Регулярный денежный поток: облигации с купонами и дивидендные акции.',
      riskNote: 'Дивиденды не гарантированы, их может сократить компания.',
      shares: {AssetClass.bonds: 0.45, AssetClass.stocks: 0.45, AssetClass.funds: 0, AssetClass.gold: 0.05, AssetClass.cash: 0.05, AssetClass.other: 0},
    ),
    PortfolioTemplate(
      id: 'passive',
      name: 'Пассивный индексный',
      description: 'Фонды широкого рынка и облигации, минимум ручных решений и низкие издержки.',
      riskNote: 'Повторяет рынок: в кризис падает вместе с ним.',
      shares: {AssetClass.bonds: 0.2, AssetClass.stocks: 0, AssetClass.funds: 0.75, AssetClass.gold: 0.05, AssetClass.cash: 0, AssetClass.other: 0},
    ),
  ];

  static AssetClass classOf(PositionKind k) {
    switch (k) {
      case PositionKind.bond:
        return AssetClass.bonds;
      case PositionKind.stock:
        return AssetClass.stocks;
      case PositionKind.fund:
        return AssetClass.funds;
      case PositionKind.gold:
        return AssetClass.gold;
      case PositionKind.cash:
        return AssetClass.cash;
      case PositionKind.currency:
      case PositionKind.other:
        return AssetClass.other;
    }
  }

  /// Сравнение портфеля с шаблоном по классам. [values] — стоимость каждой позиции.
  static List<TemplateLine> compare(PortfolioTemplate t, List<({PositionKind kind, double value})> positions) {
    final total = positions.fold<double>(0, (s, p) => s + p.value);
    final byClass = <AssetClass, double>{};
    for (final p in positions) {
      final c = classOf(p.kind);
      byClass[c] = (byClass[c] ?? 0) + p.value;
    }
    return [
      for (final c in AssetClass.values)
        TemplateLine(c, t.shares[c] ?? 0, total > 0 ? (byClass[c] ?? 0) / total : 0),
    ];
  }
}
