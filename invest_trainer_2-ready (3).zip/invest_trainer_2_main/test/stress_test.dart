import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/domain/risk/stress_test.dart';
import 'package:invest_trainer/features/portfolio/portfolio_models.dart';

void main() {
  const positions = [
    StressPosition(ticker: 'SBER', kind: PositionKind.stock, value: 100000),
    StressPosition(ticker: 'OFZ', kind: PositionKind.bond, value: 100000),
    StressPosition(ticker: 'CASH', kind: PositionKind.cash, value: 100000),
    StressPosition(ticker: 'GOLD', kind: PositionKind.gold, value: 100000),
  ];

  test('ставка +3 п. п. и рынок −5%: облигации −9 000, акции −5 000, деньги и золото без изменений', () {
    const s = StressScenario(name: 't', description: '', rateShockPp: 3, marketPct: -5);
    final r = PortfolioStress.run(positions, s);
    expect(r.changeRub, closeTo(-14000, 1e-6));
    expect(r.changePct, closeTo(-3.5, 1e-9));
    expect(r.byKind[PositionKind.bond], closeTo(-9000, 1e-6));
    expect(r.byKind[PositionKind.stock], closeTo(-5000, 1e-6));
    expect(r.byKind[PositionKind.cash], 0);
  });

  test('рынок −30% и рубль +10%: акции −30 000, золото +10 000, итог −5%', () {
    const s = StressScenario(name: 't', description: '', marketPct: -30, currencyPct: 10);
    final r = PortfolioStress.run(positions, s);
    expect(r.changeRub, closeTo(-20000, 1e-6));
    expect(r.changePct, closeTo(-5, 1e-9));
  });

  test('ставка снижается: облигации дорожают', () {
    const s = StressScenario(name: 't', description: '', rateShockPp: -2);
    final r = PortfolioStress.run(positions, s);
    expect(r.byKind[PositionKind.bond], closeTo(6000, 1e-6));
    expect(r.changeRub, closeTo(6000, 1e-6));
  });

  test('фонды акций реагируют с бетой 0,9, валюта растёт вместе с курсом', () {
    const s = StressScenario(name: 't', description: '', marketPct: -30, currencyPct: 20);
    final r = PortfolioStress.run(const [
      StressPosition(ticker: 'FUND', kind: PositionKind.fund, value: 100000),
      StressPosition(ticker: 'USD', kind: PositionKind.currency, value: 50000),
    ], s);
    expect(r.byKind[PositionKind.fund], closeTo(-27000, 1e-6));
    expect(r.byKind[PositionKind.currency], closeTo(10000, 1e-6));
  });

  test('пустой портфель не даёт деления на ноль', () {
    final r = PortfolioStress.run(const [], PortfolioStress.presets.first);
    expect(r.changeRub, 0);
    expect(r.changePct, 0);
  });

  test('все пресеты считаются и есть допущения', () {
    final results = PortfolioStress.runAll(positions);
    expect(results, hasLength(PortfolioStress.presets.length));
    expect(PortfolioStress.assumptions, isNotEmpty);
    for (final r in results) {
      expect(r.changePct.isFinite, isTrue);
    }
  });
}
