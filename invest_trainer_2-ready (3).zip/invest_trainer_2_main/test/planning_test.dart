import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/domain/planning/goal_planner.dart';
import 'package:invest_trainer/domain/planning/portfolio_templates.dart';
import 'package:invest_trainer/features/portfolio/portfolio_models.dart';

void main() {
  group('Планировщик цели', () {
    test('месячная ставка из годовой: 10% → около 0,797%', () {
      expect(GoalPlanner.monthlyRate(0.10), closeTo(0.0079741, 1e-6));
    });

    test('взнос для 1 000 000 ₽ за 5 лет при 10% и старте 100 000 ₽ ≈ 10 957 ₽ в месяц', () {
      final m = GoalPlanner.requiredMonthly(target: 1000000, start: 100000, annualReturn: 0.10, years: 5);
      expect(m, closeTo(10957, 5));
    });

    test('проверка обратным расчётом: накопления с этим взносом дают цель', () {
      final m = GoalPlanner.requiredMonthly(target: 1000000, start: 100000, annualReturn: 0.10, years: 5);
      final fv = GoalPlanner.futureValue(start: 100000, monthly: m, annualReturn: 0.10, years: 5);
      expect(fv, closeTo(1000000, 1));
    });

    test('нулевая доходность: взнос = (цель − старт) / месяцы', () {
      final m = GoalPlanner.requiredMonthly(target: 120000, start: 0, annualReturn: 0, years: 2);
      expect(m, closeTo(5000, 1e-9));
    });

    test('если старт уже больше цели, взнос не отрицательный', () {
      final m = GoalPlanner.requiredMonthly(target: 100000, start: 500000, annualReturn: 0.08, years: 3);
      expect(m, 0);
    });

    test('срок 0 или меньше — понятная ошибка', () {
      expect(() => GoalPlanner.requiredMonthly(target: 1, start: 0, annualReturn: 0.1, years: 0), throwsArgumentError);
    });

    test('сценарии: чем выше доходность, тем меньше взнос; сумма взносов считается за весь срок', () {
      final list = GoalPlanner.scenarios(target: 1000000, start: 0, years: 10);
      expect(list, hasLength(3));
      expect(list[0].monthly, greaterThan(list[1].monthly));
      expect(list[1].monthly, greaterThan(list[2].monthly));
      expect(list[1].totalContributed, closeTo(list[1].monthly * 120, 1e-6));
    });

    test('цель в сегодняшних деньгах при инфляции 7% за 5 лет: делим на 1,07^5', () {
      final v = GoalPlanner.targetInTodayMoney(target: 1000000, inflation: 0.07, years: 5);
      expect(v, closeTo(1000000 / 1.402552, 1));
    });
  });

  group('Шаблоны портфелей', () {
    test('в каждом шаблоне доли в сумме дают 100%', () {
      for (final t in PortfolioTemplates.all) {
        final sum = t.shares.values.fold<double>(0, (s, v) => s + v);
        expect(sum, closeTo(1.0, 1e-9), reason: t.name);
      }
    });

    test('у всех шаблонов уникальные id и заполнены описания', () {
      final ids = PortfolioTemplates.all.map((t) => t.id).toSet();
      expect(ids.length, PortfolioTemplates.all.length);
      for (final t in PortfolioTemplates.all) {
        expect(t.description.isNotEmpty && t.riskNote.isNotEmpty, isTrue, reason: t.name);
      }
    });

    test('сравнение: портфель из 100% акций против консервативного шаблона', () {
      final t = PortfolioTemplates.all.firstWhere((x) => x.id == 'conservative');
      final lines = PortfolioTemplates.compare(t, const [(kind: PositionKind.stock, value: 1000)]);
      final stocks = lines.firstWhere((l) => l.cls == AssetClass.stocks);
      expect(stocks.currentShare, closeTo(1.0, 1e-9));
      expect(stocks.diffPp, closeTo(90, 1e-6));
      expect(stocks.advice, contains('Больше шаблона'));
      final bonds = lines.firstWhere((l) => l.cls == AssetClass.bonds);
      expect(bonds.advice, contains('Меньше шаблона'));
    });

    test('сравнение: отклонение до 5 п. п. считается нормой', () {
      final t = PortfolioTemplates.all.firstWhere((x) => x.id == 'balanced');
      // Облигации 40%, акции 35%, фонды 10%, золото 5%, деньги 10% — точно по шаблону.
      final lines = PortfolioTemplates.compare(t, const [
        (kind: PositionKind.bond, value: 40),
        (kind: PositionKind.stock, value: 35),
        (kind: PositionKind.fund, value: 10),
        (kind: PositionKind.gold, value: 5),
        (kind: PositionKind.cash, value: 10),
      ]);
      for (final l in lines) {
        expect(l.advice, contains('В пределах'), reason: l.cls.label);
      }
    });

    test('пустой портфель не даёт деления на ноль', () {
      final t = PortfolioTemplates.all.first;
      final lines = PortfolioTemplates.compare(t, const []);
      expect(lines.every((l) => l.currentShare == 0), isTrue);
    });
  });
}
