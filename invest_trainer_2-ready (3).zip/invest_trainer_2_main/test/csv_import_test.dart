import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/features/portfolio/csv_import.dart';
import 'package:invest_trainer/features/portfolio/portfolio_models.dart';

void main() {
  test('разбор: точка с запятой, кавычки с разделителем внутри, CRLF, BOM', () {
    const text = '\uFEFFТикер;Название;Количество;Средняя цена\r\nSBER;"Сбербанк; ао";10;"270,5"\r\n';
    final rows = CsvParser.parse(text);
    expect(rows, hasLength(2));
    expect(rows[0].first, 'Тикер');
    expect(rows[1][1], 'Сбербанк; ао');
    expect(rows[1][3], '270,5');
  });

  test('разбор: запятая как разделитель и экранированные кавычки', () {
    final rows = CsvParser.parse('ticker,name\nLKOH,"Лукойл ""основной"""');
    expect(rows[1][1], 'Лукойл "основной"');
  });

  test('числа в русском и английском виде', () {
    expect(PositionCsvMapper.number('1 234,5'), 1234.5);
    expect(PositionCsvMapper.number('1,234.5'), 1234.5);
    expect(PositionCsvMapper.number('1234.5'), 1234.5);
    expect(PositionCsvMapper.number('abc'), isNull);
    expect(PositionCsvMapper.number(''), isNull);
  });

  test('вид бумаги по тексту', () {
    expect(PositionCsvMapper.kindOf('Облигация'), PositionKind.bond);
    expect(PositionCsvMapper.kindOf('Обыкновенная акция'), PositionKind.stock);
    expect(PositionCsvMapper.kindOf('БПИФ на индекс'), PositionKind.fund);
    expect(PositionCsvMapper.kindOf('Золото'), PositionKind.gold);
    expect(PositionCsvMapper.kindOf('что-то'), PositionKind.other);
  });

  test('сопоставление колонок и строки с ошибками', () {
    const text = 'Код;Наименование;Тип;Кол-во;Цена покупки;Комментарий\n'
        'sber;Сбербанк;Акция;10;270,5;долгосрочно\n'
        ';Без тикера;Акция;1;1;\n'
        'OFZ26238;ОФЗ;Облигация;0;1000;\n'
        'LKOH;Лукойл;Акция;5;-1;\n'
        'LKOH;Лукойл;Акция;5;6000;\n';
    final result = PositionCsvMapper.map(CsvParser.parse(text));
    expect(result.positions, hasLength(2));
    expect(result.positions.first.ticker, 'SBER');
    expect(result.positions.first.avgPrice, 270.5);
    expect(result.positions.first.note, 'долгосрочно');
    expect(result.positions.last.ticker, 'LKOH');
    expect(result.errors, hasLength(3));
    expect(result.errors.any((e) => e.contains('Строка 3') && e.contains('тикер')), isTrue);
    expect(result.errors.any((e) => e.contains('Строка 4') && e.contains('количество')), isTrue);
    expect(result.errors.any((e) => e.contains('Строка 5') && e.contains('средняя цена')), isTrue);
  });

  test('без обязательных колонок импорт не начинается и объясняет причину', () {
    final result = PositionCsvMapper.map(CsvParser.parse('a;b\n1;2'));
    expect(result.positions, isEmpty);
    expect(result.errors.single, contains('Не найдены обязательные колонки'));
  });

  test('пустой файл даёт понятную ошибку', () {
    final result = PositionCsvMapper.map(CsvParser.parse(''));
    expect(result.errors.single, 'Файл пуст.');
  });
}
