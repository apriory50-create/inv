import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/domain/sim/engine_models.dart';
import 'package:invest_trainer/domain/sim/instrument_catalog.dart';
import 'package:invest_trainer/domain/sim/scenario_catalog.dart';
import 'package:invest_trainer/domain/sim/scenario_model.dart';
import 'package:invest_trainer/domain/sim/sim_engine.dart';
import 'package:invest_trainer/lessons_data.dart';

void main() {
  final all = ScenarioCatalog.all();
  final specs = {for (final s in InstrumentCatalog.build()) s.id: s};
  final issuers = {for (final s in specs.values) s.issuer};
  final lessonIds = {for (final l in LessonsData.allLessons) l.id};

  test('сценариев не меньше 200, категорий 16', () {
    expect(all.length, greaterThanOrEqualTo(200));
    expect(ScenarioCatalog.categories().length, 16);
  });

  test('id уникальны и идут подряд', () {
    for (var i = 0; i < all.length; i++) {
      expect(all[i].id, 'S${(i + 1).toString().padLeft(3, '0')}');
    }
    expect(all.map((s) => s.id).toSet().length, all.length);
  });

  test('у каждого сценария заполнены тексты, рекомендации и уроки', () {
    for (final s in all) {
      expect(s.headline.trim(), isNotEmpty, reason: s.id);
      expect(s.news.trim().length, greaterThan(20), reason: s.id);
      expect(s.plain.trim().length, greaterThan(30), reason: s.id);
      expect(s.signs, isNotEmpty, reason: s.id);
      expect(s.best, isNotEmpty, reason: s.id);
      expect(s.bad, isNotEmpty, reason: s.id);
      expect(s.lessonIds, isNotEmpty, reason: s.id);
      expect(s.difficulty, inInclusiveRange(1, 3), reason: s.id);
      expect(s.params.rampDays, greaterThanOrEqualTo(1), reason: s.id);
    }
  });

  test('заголовки сценариев уникальны', () {
    final titles = all.map((s) => s.headline).toList();
    expect(titles.toSet().length, titles.length, reason: 'повторяющиеся заголовки');
  });

  test('ссылки на инструменты, эмитентов и уроки корректны', () {
    for (final s in all) {
      for (final id in s.params.instrumentShift.keys) {
        expect(specs.containsKey(id), isTrue, reason: '${s.id}: нет инструмента $id');
      }
      for (final id in s.params.instrumentYield.keys) {
        expect(specs[id]?.kind, InstrumentKind.bond, reason: '${s.id}: $id не облигация');
      }
      for (final id in s.params.divYieldSet.keys) {
        expect(specs[id]?.kind, InstrumentKind.stock, reason: '${s.id}: $id не акция');
      }
      for (final name in s.params.defaultIssuers) {
        expect(issuers.contains(name), isTrue, reason: '${s.id}: нет эмитента $name');
      }
      for (final m in s.recommended) {
        for (final id in m.toIds) {
          expect(specs.containsKey(id), isTrue, reason: '${s.id}: нет $id в рекомендации');
        }
        expect(m.pct, inInclusiveRange(0.05, 1.0), reason: s.id);
      }
      for (final l in s.lessonIds) {
        expect(lessonIds.contains(l), isTrue, reason: '${s.id}: нет урока $l');
      }
    }
    for (final info in kMistakes.values) {
      expect(lessonIds.contains(info.lessonId), isTrue, reason: 'урок ${info.lessonId} для ошибки «${info.title}»');
    }
    expect(kMistakes.length, MistakeType.values.length);
  });

  test('каждый сценарий применим к портфелю, а симуляция остаётся конечной', () {
    for (final s in all) {
      final e = SimEngine(seed: 1);
      e.buy('F-IDX', 500);
      e.buy('OFZ-M', 100);
      e.buy('LSG-V', 20);
      e.buy('SVB', 50);
      final rec = e.applyScenario(s);
      e.advance(s.params.rampDays + 2);
      final snap = e.snapshot();
      expect(snap.total.isFinite, isTrue, reason: s.id);
      expect(snap.total, greaterThan(0), reason: s.id);
      expect(rec.scenario.id, s.id);
    }
  });

  test('есть сценарии разной сложности и каждой ключевой категории', () {
    expect(all.map((s) => s.difficulty).toSet(), {1, 2, 3});
    for (final c in ['Ставка ЦБ', 'Инфляция', 'Валюта', 'Дефолты и рейтинги', 'Психология рынка', 'Чёрные лебеди']) {
      expect(ScenarioCatalog.inCategory(c), isNotEmpty, reason: c);
    }
  });
}
