import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/domain/sim/bond_math.dart';

void main() {
  const period = 182;

  List<CashFlow> flows({double coupon = 10, int n = 10, int amort = 0}) => BondMath.cashFlows(
        couponsLeft: n,
        daysToNext: period,
        period: period,
        couponRatePct: coupon,
        freq: 2,
        remainingFrac: 1.0,
        amortPayments: amort,
        amortLeft: amort,
      );

  test('если доходность равна купону, а купонный период свежий, цена равна номиналу', () {
    final f = flows();
    expect(BondMath.dirtyFrac(f, 10, 2, period), closeTo(1.0, 1e-9));
  });

  test('чем выше доходность, тем ниже цена', () {
    final f = flows();
    expect(BondMath.dirtyFrac(f, 15, 2, period), lessThan(BondMath.dirtyFrac(f, 10, 2, period)));
    expect(BondMath.dirtyFrac(f, 5, 2, period), greaterThan(BondMath.dirtyFrac(f, 10, 2, period)));
  });

  test('обратная задача: доходность по цене возвращает ту же цену', () {
    final f = flows(coupon: 8, n: 12);
    final y = BondMath.yieldFromDirty(f, 0.8, 2, period);
    expect(BondMath.dirtyFrac(f, y, 2, period), closeTo(0.8, 1e-6));
  });

  test('амортизация возвращает ровно 100% номинала по частям', () {
    final f = flows(coupon: 0, n: 8, amort: 4);
    final principal = f.fold<double>(0, (s, c) => s + c.amount);
    expect(principal, closeTo(1.0, 1e-9));
    // Первые 4 периода без амортизации, последние 4 — по 25%.
    expect(f[3].amount, 0);
    expect(f[4].amount, closeTo(0.25, 1e-9));
    expect(f.last.amount, closeTo(0.25, 1e-9));
  });

  test('без амортизации номинал возвращается одним платежом в конце', () {
    final f = flows(coupon: 0, n: 6);
    expect(f.where((c) => c.amount > 0).length, 1);
    expect(f.last.amount, closeTo(1.0, 1e-9));
  });

  test('дюрация длинной облигации больше, чем короткой', () {
    final dShort = BondMath.modifiedDuration(flows(coupon: 7, n: 4), 15, 2, period);
    final dLong = BondMath.modifiedDuration(flows(coupon: 7, n: 24), 15, 2, period);
    expect(dLong, greaterThan(dShort));
    expect(dShort, greaterThan(1.0));
  });

  test('бескупонная облигация: дюрация близка к сроку', () {
    final f = flows(coupon: 0, n: 10);
    final d = BondMath.modifiedDuration(f, 10, 2, period);
    expect(d, closeTo(10 * period / 365 / 1.05, 0.05));
  });

  test('НКД растёт пропорционально дням с последнего купона', () {
    final half = BondMath.accruedFrac(couponRatePct: 10, freq: 2, remainingFrac: 1, daysSince: 91, period: period);
    final full = BondMath.accruedFrac(couponRatePct: 10, freq: 2, remainingFrac: 1, daysSince: 182, period: period);
    expect(full, closeTo(0.05, 1e-9));
    expect(half, closeTo(full / 2, 1e-9));
  });
}
