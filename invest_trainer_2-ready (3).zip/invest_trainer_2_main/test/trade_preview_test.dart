import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/domain/sim/sim_engine.dart';
import 'package:invest_trainer/domain/sim/trade_preview.dart';

void main() {
  test('обычная покупка фонда без предупреждений, есть издержки', () {
    final e = SimEngine(seed: 1);
    final p = TradePreview.buy(e, 'F-IDX', 100);
    expect(p.hasWarnings, isFalse);
    expect(p.total, greaterThan(p.gross));
    expect(p.notes.any((n) => n.contains('Издержки')), isTrue);
  });

  test('покупка сверх денег даёт предупреждение', () {
    final e = SimEngine(seed: 1);
    final p = TradePreview.buy(e, 'SVB', 400);
    expect(p.warnings.any((w) => w.contains('Не хватает денег')), isTrue);
  });

  test('одна бумага больше 25% капитала даёт предупреждение о концентрации', () {
    final e = SimEngine(seed: 1);
    final p = TradePreview.buy(e, 'SVB', 300);
    expect(p.warnings.any((w) => w.contains('Доля эмитента')), isTrue);
  });

  test('ОФЗ не считаются концентрацией эмитента', () {
    final e = SimEngine(seed: 1);
    final p = TradePreview.buy(e, 'OFZ-M', 500);
    expect(p.warnings.any((w) => w.contains('Доля эмитента')), isFalse);
  });

  test('ВДО больше 10% портфеля — предупреждение', () {
    final e = SimEngine(seed: 1);
    final p = TradePreview.buy(e, 'LSG-V', 500);
    expect(p.warnings.any((w) => w.contains('ВДО станут')), isTrue);
  });

  test('длинная облигация предупреждает о чувствительности к ставке', () {
    final e = SimEngine(seed: 1);
    final p = TradePreview.buy(e, 'OFZ-L', 200);
    expect(p.warnings.any((w) => w.contains('Длинная облигация')), isTrue);
  });

  test('короткий срок до дивидендной отсечки даёт предупреждение', () {
    final e = SimEngine(seed: 1);
    e.advance(185); // отсечка SVB на 190-й день года
    final p = TradePreview.buy(e, 'SVB', 10);
    expect(p.warnings.any((w) => w.contains('дивидендной отсечки')), isTrue);
  });

  test('продажа всей позиции отмечается в пояснениях', () {
    final e = SimEngine(seed: 1);
    e.buy('F-IDX', 100);
    final p = TradePreview.sell(e, 'F-IDX', 100);
    expect(p.notes.any((n) => n.contains('всю позицию')), isTrue);
  });

  test('предупреждения и пояснения не пересекаются по смыслу с суммой', () {
    final e = SimEngine(seed: 1);
    final p = TradePreview.buy(e, 'SVB', 10);
    expect(p.total, closeTo(p.gross + p.nkd + p.fee, 1e-9));
  });
}
