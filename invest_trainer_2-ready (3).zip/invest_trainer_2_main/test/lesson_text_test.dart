import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/features/academy/lesson_text.dart';

void main() {
  test('разбор текста урока на заголовки, пункты и абзацы', () {
    const content = '''
📖 СУТЬ ПРОСТЫМИ СЛОВАМИ
Облигация — это долг.

🟢 КОГДА ВХОДИТЬ
• Первое условие
   • Вложенное условие
- Пункт с дефисом
''';
    final blocks = parseLessonContent(content);
    expect(blocks.map((b) => b.kind).toList(), [
      LessonBlockKind.header,
      LessonBlockKind.paragraph,
      LessonBlockKind.header,
      LessonBlockKind.bullet,
      LessonBlockKind.bullet,
      LessonBlockKind.bullet,
    ]);
    expect(blocks[3].text, 'Первое условие');
    expect(blocks[4].indent, 1);
    expect(blocks[5].text, 'Пункт с дефисом');
  });

  test('заголовки с вариационным селектором (🕵️, ⚠️) распознаются', () {
    final blocks = parseLessonContent('🕵️ КОСВЕННЫЕ ПРИЗНАКИ\n⚠️ Оговорка');
    expect(blocks.every((b) => b.kind == LessonBlockKind.header), isTrue);
  });
}
