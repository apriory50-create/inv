import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/features/portfolio/portfolio_models.dart';
import 'package:invest_trainer/features/portfolio/quotes_service.dart';

const _fixture = '''
{"marketdata":{"columns":["SECID","LAST","PREVPRICE"],"data":[
  ["SBER",270.5,268.0],
  ["LKOH",null,6100.0],
  ["GAZP",null,null],
  ["sber2",1.0,1.0],
  [null,10.0,10.0]
]}}
''';

void main() {
  test('разбор ответа ISS: LAST, при его отсутствии PREVPRICE, пустые пропускаются', () {
    final prices = MoexQuotes.parse(_fixture);
    expect(prices['SBER'], 270.5);
    expect(prices['LKOH'], 6100.0);
    expect(prices.containsKey('GAZP'), isFalse);
    expect(prices['SBER2'], 1.0);
    expect(prices.length, 3);
  });

  test('ссылка на котировки: https, нужный хост и режим торгов', () {
    final u = MoexQuotes.url('TQBR');
    expect(u.scheme, 'https');
    expect(u.host, MoexQuotes.host);
    expect(u.path, contains('/boards/TQBR/'));
    expect(u.queryParameters['iss.only'], 'marketdata');
  });

  test('непонятный ответ даёт понятную ошибку, а не падение', () {
    expect(() => MoexQuotes.parse('не json'), throwsFormatException);
    expect(() => MoexQuotes.parse('{"other":1}'), throwsFormatException);
    expect(() => MoexQuotes.parse('{"marketdata":{"columns":["LAST"],"data":[]}}'), throwsFormatException);
  });

  test('стоимость портфеля: по котировкам, без них — по цене покупки', () {
    final q = QuotesState(prices: {'SBER': 300.0});
    final positions = [
      const Position(ticker: 'SBER', name: 'Сбербанк', kind: PositionKind.stock, quantity: 10, avgPrice: 270),
      const Position(ticker: 'LKOH', name: 'Лукойл', kind: PositionKind.stock, quantity: 2, avgPrice: 6000),
      const Position(ticker: 'OFZ', name: 'ОФЗ', kind: PositionKind.bond, quantity: 3, avgPrice: 1000),
    ];
    final mv = PortfolioMath.marketValue(positions, q);
    // SBER: 10 × 300 = 3000; LKOH без цены: 12000 по покупке; облигация не котируется: 3000 по покупке.
    expect(mv.total, 3000 + 12000 + 3000);
    expect(mv.costTotal, 2700 + 12000 + 3000);
    expect(mv.priced, 1);
    expect(mv.unpriced, 2);
    expect(mv.pnl, closeTo(300, 1e-9));
  });

  test('цена тикера не зависит от регистра', () {
    final q = QuotesState(prices: {'SBER': 1.0});
    expect(q.priceOf('sber'), 1.0);
  });
}
