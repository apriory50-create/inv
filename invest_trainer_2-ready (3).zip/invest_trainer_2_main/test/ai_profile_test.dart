import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/core/ai/ai_models.dart';

void main() {
  group('AiProfile', () {
    test('JSON туда и обратно сохраняет все поля, ключа API в JSON нет', () {
      const profile = AiProfile(
        id: '42',
        name: 'Мой Claude',
        type: AiProviderType.anthropic,
        baseUrl: 'https://api.anthropic.com',
        model: 'test-model',
        temperature: 0.7,
        maxTokens: 2000,
        systemPrompt: 'Отвечай кратко',
      );
      final json = profile.toJson();
      expect(json.containsKey('apiKey'), isFalse);
      final restored = AiProfile.fromJson(json);
      expect(restored.id, '42');
      expect(restored.name, 'Мой Claude');
      expect(restored.type, AiProviderType.anthropic);
      expect(restored.baseUrl, 'https://api.anthropic.com');
      expect(restored.model, 'test-model');
      expect(restored.temperature, 0.7);
      expect(restored.maxTokens, 2000);
      expect(restored.systemPrompt, 'Отвечай кратко');
    });

    test('неизвестный тип провайдера заменяется на OpenAI-совместимый', () {
      final p = AiProfile.fromJson({'id': '1', 'type': 'unknown', 'model': 'm'});
      expect(p.type, AiProviderType.openaiCompatible);
      expect(p.baseUrl, AiProviderType.openaiCompatible.defaultBaseUrl);
    });
  });
}
