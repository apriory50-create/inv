import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/core/security/secure_key_store.dart';

void main() {
  test('mask не раскрывает ключ целиком', () {
    expect(SecureKeyStore.mask(''), '');
    expect(SecureKeyStore.mask('short'), '••••');
    final masked = SecureKeyStore.mask('sk-abcdefghijklmnop1234');
    expect(masked, '••••1234');
    expect(masked.contains('abcdef'), isFalse);
  });
}
