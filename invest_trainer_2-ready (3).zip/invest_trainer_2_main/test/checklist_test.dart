import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/domain/checklist/buy_checklist.dart';

Map<String, Answer> _all(Answer a) => {for (final q in BuyChecklist.questions) q.id: a};

void main() {
  test('в чек-листе 10 вопросов с уникальными id', () {
    expect(BuyChecklist.questions, hasLength(10));
    expect(BuyChecklist.questions.map((q) => q.id).toSet(), hasLength(10));
  });

  test('все ответы «да» — можно рассмотреть покупку', () {
    final r = BuyChecklist.evaluate(_all(Answer.yes));
    expect(r.verdict, ChecklistVerdict.considerable);
    expect(r.yesCount, 10);
    expect(r.blockers, isEmpty);
  });

  test('ответ «нет» на критичный вопрос блокирует покупку, даже при остальных «да»', () {
    final answers = _all(Answer.yes)..['plan'] = Answer.no;
    final r = BuyChecklist.evaluate(answers);
    expect(r.verdict, ChecklistVerdict.blocked);
    expect(r.blockers, hasLength(1));
    expect(r.blockers.single, contains('не новости'));
  });

  test('ответ «нет» на некритичный вопрос не блокирует, но уводит в «проверить ещё»', () {
    final answers = _all(Answer.yes)..['price'] = Answer.no;
    final r = BuyChecklist.evaluate(answers);
    expect(r.verdict, ChecklistVerdict.checkMore);
    expect(r.blockers, isEmpty);
    expect(r.todo, hasLength(1));
  });

  test('пустые ответы считаются «не знаю»: покупка не рекомендуется', () {
    final r = BuyChecklist.evaluate(const {});
    expect(r.verdict, isNot(ChecklistVerdict.considerable));
    expect(r.yesCount, 0);
    expect(r.todo, hasLength(10));
  });

  test('восемь «да» и два «не знаю» по некритичным — можно рассмотреть', () {
    final answers = _all(Answer.yes)
      ..['debt'] = Answer.unknown
      ..['costs'] = Answer.unknown;
    final r = BuyChecklist.evaluate(answers);
    expect(r.verdict, ChecklistVerdict.considerable);
  });
}
