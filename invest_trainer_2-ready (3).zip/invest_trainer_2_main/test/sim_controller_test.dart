import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/core/settings/settings_controller.dart';
import 'package:invest_trainer/domain/sim/scenario_catalog.dart';
import 'package:invest_trainer/features/simulator/sim_controller.dart';
import 'package:invest_trainer/features/simulator/sim_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Контейнер с подменой SharedPreferences (как в main()).
Future<ProviderContainer> _container([SharedPreferences? prefs]) async {
  // Передали готовые prefs (перезапуск) — не сбрасываем хранилище.
  if (prefs != null) {
    return ProviderContainer(overrides: [sharedPreferencesProvider.overrideWithValue(prefs)]);
  }
  SharedPreferences.setMockInitialValues({});
  final p = await SharedPreferences.getInstance();
  return ProviderContainer(overrides: [sharedPreferencesProvider.overrideWithValue(p)]);
}

void main() {
  test('сценарий: нельзя запустить два сразу, после завершения есть разбор и отметка о прохождении', () async {
    final c = await _container();
    addTearDown(c.dispose);
    final ctl = c.read(simProvider.notifier);
    expect(ctl.buy('F-IDX', 100).ok, isTrue);

    final scenario = ScenarioCatalog.all().first;
    expect(ctl.startScenario(scenario), isTrue);
    expect(ctl.startScenario(scenario), isFalse);
    expect(c.read(simProvider).active, isNotNull);

    ctl.advance(5);
    final review = ctl.finishScenario();
    expect(review, isNotNull);
    final st = c.read(simProvider);
    expect(st.active, isNull);
    expect(st.reviews, hasLength(1));
    expect(st.completedScenarioIds, contains(scenario.id));
    expect(ctl.finishScenario(), isNull);
  });

  test('каждая операция увеличивает счётчик изменений (интерфейс перерисуется)', () async {
    final c = await _container();
    addTearDown(c.dispose);
    final ctl = c.read(simProvider.notifier);
    final r0 = c.read(simProvider).rev;
    ctl.buy('F-MM', 10);
    ctl.advance(1);
    expect(c.read(simProvider).rev, r0 + 2);
  });

  test('новая игра сбрасывает портфель, время и статистику', () async {
    final c = await _container();
    addTearDown(c.dispose);
    final ctl = c.read(simProvider.notifier);
    ctl.buy('F-MM', 100);
    ctl.advance(10);
    ctl.newGame();
    final e = c.read(simProvider).engine;
    expect(e.day, 0);
    expect(e.units('F-MM'), 0);
    expect(e.totalValue(), 1000000);
    expect(c.read(simProvider).reviews, isEmpty);
  });

  testWidgets('экран симулятора показывает капитал и перематывает время', (tester) async {
    tester.view.physicalSize = const Size(1000, 1800);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();

    await tester.pumpWidget(
      ProviderScope(
        overrides: [sharedPreferencesProvider.overrideWithValue(prefs)],
        child: const MaterialApp(home: Scaffold(body: SimPage())),
      ),
    );
    await tester.pump();
    expect(find.textContaining('Капитал:'), findsWidgets);
    expect(find.textContaining('день 0'), findsOneWidget);

    await tester.tap(find.text('+1 неделя'));
    await tester.pump();
    expect(find.textContaining('день 7'), findsOneWidget);
  });

  test('прогресс симулятора сохраняется и восстанавливается после перезапуска', () async {
    final c1 = await _container();
    final prefs = c1.read(sharedPreferencesProvider);
    c1.read(simProvider.notifier).buy('F-MM', 100);
    c1.read(simProvider.notifier).advance(15);
    final day = c1.read(simProvider).engine.day;
    final total = c1.read(simProvider).engine.totalValue();
    c1.dispose();

    expect(prefs.getString('sim.save.v1'), isNotNull);

    // «Перезапуск приложения»: новый контейнер читает те же SharedPreferences.
    final c2 = await _container(prefs);
    addTearDown(c2.dispose);
    final restored = c2.read(simProvider).engine;
    expect(restored.day, day);
    expect(restored.totalValue(), closeTo(total, 1e-6));
    expect(restored.units('F-MM'), 100);
  });

  test('новая игра стирает сохранение', () async {
    final c = await _container();
    addTearDown(c.dispose);
    final prefs = c.read(sharedPreferencesProvider);
    c.read(simProvider.notifier).advance(3);
    expect(prefs.getString('sim.save.v1'), isNotNull);
    c.read(simProvider.notifier).newGame();
    final saved = SimSaveProbe.dayOf(prefs.getString('sim.save.v1')!);
    expect(saved, 0);
  });
}

/// Вспомогательная проверка содержимого сохранения без доступа к внутренностям движка.
class SimSaveProbe {
  static int dayOf(String raw) {
    final m = jsonDecode(raw) as Map<String, dynamic>;
    return ((m['engine'] as Map)['day'] as num).toInt();
  }
}
