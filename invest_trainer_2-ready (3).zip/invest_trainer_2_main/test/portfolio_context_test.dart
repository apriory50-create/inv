import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/features/portfolio/portfolio_context.dart';
import 'package:invest_trainer/features/portfolio/portfolio_models.dart';

void main() {
  const positions = [
    Position(ticker: 'AAA', name: 'Акция А', kind: PositionKind.stock, quantity: 10, avgPrice: 100),
    Position(ticker: 'BBB', name: 'Облигация Б', kind: PositionKind.bond, quantity: 3, avgPrice: 1000),
  ];

  test('пустой портфель описывается без ошибок', () {
    expect(PortfolioContext.build(const [], includeAmounts: false), 'Портфель пока пуст.');
  });

  test('доли считаются по стоимости покупки: 1000 и 3000 -> 25% и 75%', () {
    final text = PortfolioContext.build(positions, includeAmounts: false);
    expect(text, contains('Акция: 25.0%'));
    expect(text, contains('Облигация: 75.0%'));
  });

  test('без includeAmounts количество и цены не попадают в текст', () {
    final text = PortfolioContext.build(positions, includeAmounts: false);
    expect(text.contains('количество'), isFalse);
    expect(text.contains('средняя цена'), isFalse);
    expect(text.contains('Общая стоимость'), isFalse);
  });

  test('с includeAmounts суммы добавляются', () {
    final text = PortfolioContext.build(positions, includeAmounts: true);
    expect(text, contains('количество: 10'));
    expect(text, contains('Общая стоимость по цене покупки: 4000'));
  });

  test('Position.cost = количество × цена', () {
    expect(positions.first.cost, 1000);
    expect(positions.last.cost, 3000);
  });
}
