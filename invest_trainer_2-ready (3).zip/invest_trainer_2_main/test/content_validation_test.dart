import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/lessons_data.dart';

void main() {
  final lessons = LessonsData.allLessons;
  final cjk = RegExp(r'[\u3040-\u30ff\u4e00-\u9fff]');

  test('курс не пустой и отсортирован по id', () {
    expect(lessons, isNotEmpty);
    for (var i = 1; i < lessons.length; i++) {
      expect(lessons[i].id, greaterThan(lessons[i - 1].id), reason: 'уроки должны идти по возрастанию id');
    }
  });

  test('id уникальны, заголовок начинается с «Урок N.»', () {
    final ids = <int>{};
    for (final l in lessons) {
      expect(ids.add(l.id), isTrue, reason: 'повторяется id ${l.id}');
      expect(l.title.startsWith('Урок ${l.id}.'), isTrue, reason: 'заголовок урока ${l.id}: ${l.title}');
    }
  });

  test('у каждого урока заполнены обязательные поля', () {
    for (final l in lessons) {
      expect(l.moduleTitle.trim(), isNotEmpty, reason: 'урок ${l.id}');
      expect(l.category.trim(), isNotEmpty, reason: 'урок ${l.id}');
      expect(l.readingTimeMinutes, greaterThan(0), reason: 'урок ${l.id}');
      expect(l.content.trim().length, greaterThan(200), reason: 'урок ${l.id}: слишком короткий текст');
      expect(l.keyRules, isNotEmpty, reason: 'урок ${l.id}');
      expect(l.question.trim(), isNotEmpty, reason: 'урок ${l.id}');
      expect(l.explanation.trim(), isNotEmpty, reason: 'урок ${l.id}');
    }
  });

  test('тест урока: 4 разных варианта и корректный индекс ответа', () {
    for (final l in lessons) {
      expect(l.options.length, 4, reason: 'урок ${l.id}');
      expect(l.options.toSet().length, 4, reason: 'урок ${l.id}: повторяющиеся варианты');
      expect(l.correctOptionIndex, inInclusiveRange(0, 3), reason: 'урок ${l.id}');
    }
  });

  test('правильные ответы не прижаты к одной позиции', () {
    final counts = List<int>.filled(4, 0);
    for (final l in lessons) {
      counts[l.correctOptionIndex]++;
    }
    for (final c in counts) {
      expect(c / lessons.length, lessThan(0.5), reason: 'позиции ответов: $counts');
    }
  });

  test('в текстах нет посторонних символов (иероглифов)', () {
    for (final l in lessons) {
      final all = [l.title, l.content, l.question, l.explanation, ...l.options, ...l.keyRules].join('\n');
      expect(cjk.hasMatch(all), isFalse, reason: 'урок ${l.id}');
    }
  });

  test('модули: один moduleId — одно название', () {
    final titles = <int, String>{};
    for (final l in lessons) {
      final prev = titles.putIfAbsent(l.moduleId, () => l.moduleTitle);
      expect(prev, l.moduleTitle, reason: 'модуль ${l.moduleId} называется по-разному');
    }
  });
}
