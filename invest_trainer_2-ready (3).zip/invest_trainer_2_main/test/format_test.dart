import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/core/format.dart';

void main() {
  test('fmtRub группирует разряды и поддерживает дробную часть и минус', () {
    expect(fmtRub(0), '0');
    expect(fmtRub(999), '999');
    expect(fmtRub(1234567.891), '1 234 568');
    expect(fmtRub(1234567.891, digits: 2), '1 234 567,89');
    expect(fmtRub(-1000), '−1 000');
    expect(fmtRub(-0.2), '0');
  });

  test('fmtPct показывает знак и запятую', () {
    expect(fmtPct(5.25), '+5,3%');
    expect(fmtPct(-3.0), '−3,0%');
    expect(fmtPct(0.0), '0,0%');
    expect(fmtPct(2.0, sign: false), '2,0%');
  });

  test('fmtDate: день.месяц.год с ведущими нулями', () {
    expect(fmtDate(DateTime(2026, 3, 5)), '05.03.2026');
  });
}
