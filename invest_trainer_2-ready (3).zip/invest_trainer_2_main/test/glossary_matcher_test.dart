import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/features/academy/glossary_data.dart';
import 'package:invest_trainer/features/academy/glossary_matcher.dart';

void main() {
  final matcher = GlossaryMatcher(kGlossary);

  test('глоссарий содержит не меньше 500 терминов', () {
    expect(kGlossary.length, greaterThanOrEqualTo(500));
  });

  test('каждый термин находится в собственном названии', () {
    for (final e in kGlossary) {
      expect(matcher.find(e.term), isNotEmpty, reason: 'не найден термин «${e.term}»');
    }
  });

  test('шаблоны не содержат групп захвата и термины уникальны', () {
    final terms = <String>{};
    for (final e in kGlossary) {
      expect(terms.add(e.term), isTrue, reason: 'повтор «${e.term}»');
      expect(e.meaning.trim(), isNotEmpty);
      final capturing = RegExp(r'\((?!\?)').hasMatch(e.pattern);
      expect(capturing, isFalse, reason: 'группа захвата в шаблоне «${e.term}»');
    }
  });

  test('находит термины с окончаниями и не ловит части других слов', () {
    const text = 'Купон облигации платит эмитент. Акционер получает дивиденды.';
    final found = matcher.find(text).map((m) => text.substring(m.start, m.end).toLowerCase()).toList();
    expect(found, containsAll(['купон', 'облигации', 'эмитент', 'дивиденды']));
    expect(found.contains('акционер'), isFalse);
  });

  test('вхождения идут по порядку и не пересекаются', () {
    final matches = matcher.find('Ключевая ставка влияет на доходность облигаций, а НКД платит покупатель.');
    for (var i = 1; i < matches.length; i++) {
      expect(matches[i].start, greaterThanOrEqualTo(matches[i - 1].end));
    }
  });
}
