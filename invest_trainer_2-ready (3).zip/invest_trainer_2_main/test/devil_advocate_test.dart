import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/features/portfolio/devil_advocate.dart';
import 'package:invest_trainer/features/portfolio/portfolio_models.dart';

void main() {
  const positions = [
    Position(ticker: 'SBER', name: 'Сбербанк', kind: PositionKind.stock, quantity: 123, avgPrice: 270),
  ];

  test('системный промт требует аргументов против и запрещает команды', () {
    expect(DevilAdvocate.systemPrompt, contains('ПРОТИВ'));
    expect(DevilAdvocate.systemPrompt, contains('не давай команд'));
    expect(DevilAdvocate.systemPrompt, contains('<idea>'));
  });

  test('идея оборачивается тегами, суммы не уходят без разрешения', () {
    final msgs = DevilAdvocate.buildMessages(idea: 'Купить Сбер на все деньги', positions: positions, includeAmounts: false);
    expect(msgs.first.role, 'system');
    final user = msgs.last.content;
    expect(user, contains('<idea>Купить Сбер на все деньги</idea>'));
    expect(user.contains('123'), isFalse);
    expect(user.contains('количество'), isFalse);
  });

  test('длинная идея обрезается до лимита', () {
    final long = 'а' * (DevilAdvocate.maxIdeaChars + 500);
    final user = DevilAdvocate.buildMessages(idea: long, positions: const [], includeAmounts: false).last.content;
    expect(user.contains('а' * (DevilAdvocate.maxIdeaChars + 1)), isFalse);
  });

  test('роль сообщений: системное, затем пользовательское', () {
    final msgs = DevilAdvocate.buildMessages(idea: 'x', positions: const [], includeAmounts: true);
    expect(msgs.map((m) => m.role).toList(), ['system', 'user']);
  });
}
