import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/features/news/ai_digest.dart';
import 'package:invest_trainer/features/news/news_classifier.dart';
import 'package:invest_trainer/features/news/news_controller.dart';
import 'package:invest_trainer/features/news/news_models.dart';
import 'package:invest_trainer/features/news/rss_parser.dart';
import 'package:invest_trainer/features/portfolio/portfolio_models.dart';

const _rss = '''<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel><title>Лента</title>
<item>
  <title>ЦБ повысил ключевую ставку</title>
  <link>https://example.test/1</link>
  <description><![CDATA[<p>Банк России <b>повысил</b> ставку &amp; сообщил о рисках</p>]]></description>
  <pubDate>Mon, 16 Nov 2026 10:30:00 +0300</pubDate>
</item>
<item>
  <title>Сбербанк выплатит дивиденды</title>
  <link>https://example.test/2</link>
  <description>Совет директоров рекомендовал дивиденды.</description>
</item>
</channel></rss>''';

const _atom = '''<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <entry>
    <title>Нефть подорожала</title>
    <link rel="alternate" href="https://example.test/a1"/>
    <summary>Цены на нефть выросли.</summary>
    <updated>2026-11-18T09:00:00Z</updated>
  </entry>
</feed>''';

Position _pos(String ticker, String name) => Position(
      ticker: ticker,
      name: name,
      kind: PositionKind.stock,
      quantity: 1,
      avgPrice: 100,
    );

RawNewsItem _raw(String title, {String summary = 'Текст новости о рынке.', String source = 'Лента', DateTime? at}) =>
    RawNewsItem(sourceTitle: source, title: title, summary: summary, url: 'https://x.test/${title.hashCode}', published: at);

void main() {
  group('RSS и Atom', () {
    test('RSS: заголовок, очищенное описание, дата и ссылка', () {
      final items = FeedParser.parse(_rss, sourceTitle: 'Лента');
      expect(items, hasLength(2));
      expect(items.first.title, 'ЦБ повысил ключевую ставку');
      expect(items.first.summary, 'Банк России повысил ставку & сообщил о рисках');
      expect(items.first.url, 'https://example.test/1');
      expect(items.first.published, isNotNull);
      expect(items.last.published, isNull);
    });

    test('Atom: ссылка из атрибута href и дата в ISO', () {
      final items = FeedParser.parse(_atom, sourceTitle: 'Атом');
      expect(items, hasLength(1));
      expect(items.single.url, 'https://example.test/a1');
      expect(items.single.summary, 'Цены на нефть выросли.');
      expect(items.single.published, DateTime.parse('2026-11-18T09:00:00Z'));
    });

    test('повреждённый XML не ломает приложение и даёт пустой список', () {
      expect(FeedParser.parse('<rss><channel><item>', sourceTitle: 'Битый'), isEmpty);
      expect(FeedParser.parse('не xml вообще', sourceTitle: 'Битый'), isEmpty);
    });

    test('stripHtml убирает теги и сущности', () {
      expect(FeedParser.stripHtml('<p>A&nbsp;&lt;b&gt;</p>'), 'A <b>');
    });
  });

  group('Классификатор', () {
    test('тип: слух, мнение, факт', () {
      expect(NewsClassifier.kindOf('по данным источников, компания готовит сделку'), NewsKind.rumor);
      expect(NewsClassifier.kindOf('аналитик считает, что ставка снизится'), NewsKind.opinion);
      expect(NewsClassifier.kindOf('банк опубликовал отчётность за квартал'), NewsKind.fact);
    });

    test('упоминание бумаги портфеля по тикеру и по названию', () {
      final positions = [_pos('SBER', 'Сбербанк'), _pos('LKOH', 'Лукойл')];
      expect(NewsClassifier.matchPositions('sber нарастил прибыль', positions), ['SBER']);
      expect(NewsClassifier.matchPositions('сбербанк выплатит дивиденды', positions), ['SBER']);
      // Короткий тикер внутри другого слова не считается упоминанием.
      expect(NewsClassifier.matchPositions('лукойлистика не про компанию', positions), isEmpty);
    });

    test('влияние по ключевым словам: ставка и нефть', () {
      final up = NewsClassifier.impactsOf('цб повысил ставку');
      expect(up.any((e) => e.contains('подешеветь')), isTrue);
      final oil = NewsClassifier.impactsOf('нефть подорожала');
      expect(oil.any((e) => e.contains('выручки')), isTrue);
    });

    test('шум: кликбейт и реклама', () {
      expect(NewsClassifier.noiseOf(_raw('ШОК!!! Срочно купите это, только сейчас')), greaterThanOrEqualTo(2));
      expect(NewsClassifier.noiseOf(_raw('Банк опубликовал отчётность за третий квартал')), lessThan(2));
    });

    test('классификация: портфельная новость и рыночная новость', () {
      final positions = [_pos('SBER', 'Сбербанк')];
      final portfolio = NewsClassifier.classify(_raw('Сбербанк нарастил прибыль'), positions);
      final market = NewsClassifier.classify(_raw('ЦБ сохранил ставку без изменений'), positions);
      expect(portfolio.scope, NewsScope.portfolio);
      expect(market.scope, NewsScope.market);
    });
  });

  group('Фильтры', () {
    final now = DateTime.utc(2026, 11, 22);
    final positions = [_pos('SBER', 'Сбербанк')];

    test('дубликаты по заголовку сохраняются один раз', () {
      final out = NewsClassifier.dedupe([
        _raw('ЦБ повысил ставку на 2 п. п.'),
        _raw('ЦБ повысил ставку на 2 п. п.', source: 'Другой'),
      ]);
      expect(out, hasLength(1));
    });

    test('исключающие слова, блокировка источника и возраст скрывают новости', () {
      final raw = [
        _raw('ЦБ повысил ставку', at: now.subtract(const Duration(hours: 5))),
        _raw('Прогноз на неделю по рынку', at: now.subtract(const Duration(hours: 5))),
        _raw('Нефть подорожала у другого источника', source: 'Плохой', at: now.subtract(const Duration(hours: 5))),
        _raw('ЦБ сохранил ставку', at: now.subtract(const Duration(days: 30))),
      ];
      final f = NewsClassifier.apply(
        raw,
        positions: positions,
        now: now,
        settings: const NewsFilterSettings(
          excludeWords: ['прогноз'],
          blockedSources: ['Плохой'],
          maxAgeDays: 7,
        ),
      );
      final titles = [...f.market, ...f.portfolio].map((c) => c.raw.title);
      expect(titles, ['ЦБ повысил ставку']);
      expect(f.hiddenCount, 3);
    });

    test('список включающих слов оставляет только совпадающие новости', () {
      final raw = [
        _raw('ЦБ повысил ставку'),
        _raw('Нефть подорожала'),
      ];
      final f = NewsClassifier.apply(
        raw,
        positions: positions,
        now: now,
        settings: const NewsFilterSettings(includeWords: ['нефть']),
      );
      expect([...f.market, ...f.portfolio].map((c) => c.raw.title), ['Нефть подорожала']);
    });

    test('портфельные и рыночные новости делятся, а нерелевантные скрываются', () {
      final raw = [
        _raw('Сбербанк выплатит дивиденды'),
        _raw('ЦБ сохранил ставку'),
        _raw('Новости о спорте и погоде'),
      ];
      final f = NewsClassifier.apply(raw, positions: positions, now: now, settings: const NewsFilterSettings());
      expect(f.portfolio.map((c) => c.raw.title), ['Сбербанк выплатит дивиденды']);
      expect(f.market.map((c) => c.raw.title), ['ЦБ сохранил ставку']);
      expect(f.hiddenCount, 1);
    });
  });

  group('Настройки фильтров', () {
    test('JSON туда и обратно', () {
      const f = NewsFilterSettings(includeWords: ['нефть'], excludeWords: ['реклама'], blockedSources: ['X'], maxAgeDays: 14, hideNoisy: false);
      final back = NewsFilterSettings.fromJson(f.toJson());
      expect(back.includeWords, ['нефть']);
      expect(back.excludeWords, ['реклама']);
      expect(back.blockedSources, ['X']);
      expect(back.maxAgeDays, 14);
      expect(back.hideNoisy, isFalse);
    });
  });

  group('ИИ-дайджест', () {
    test('без разрешения сумм в запрос не попадают количества и цены', () {
      final positions = [
        const Position(ticker: 'SBER', name: 'Сбербанк', kind: PositionKind.stock, quantity: 123, avgPrice: 270),
      ];
      final f = NewsClassifier.apply([_raw('Сбербанк выплатит дивиденды')], positions: positions, now: DateTime.utc(2026, 11, 22), settings: const NewsFilterSettings());
      final msg = NewsDigest.buildUserMessage(
        portfolioNews: f.portfolio,
        marketNews: f.market,
        positions: positions,
        includeAmounts: false,
      );
      expect(msg.contains('количество'), isFalse);
      expect(msg.contains('123'), isFalse);
      expect(msg.contains('<news>'), isTrue);
    });

    test('текст новости оборачивается тегами и обрезается', () {
      final long = 'а' * 1000;
      final f = NewsClassifier.apply([_raw('ЦБ повысил ставку', summary: long)], positions: const [], now: DateTime.utc(2026, 11, 22), settings: const NewsFilterSettings());
      final msg = NewsDigest.buildUserMessage(portfolioNews: f.portfolio, marketNews: f.market, positions: const [], includeAmounts: false);
      expect(msg.contains('…'), isTrue);
      expect(msg.length, lessThan(2000));
    });

    test('системный промт предупреждает, что тексты новостей — данные', () {
      expect(NewsDigest.systemPrompt.contains('данные'), isTrue);
      expect(NewsDigest.systemPrompt.contains('игнорируй'), isTrue);
    });
  });

  group('Адреса каналов', () {
    test('принимаются только http и https с хостом', () {
      expect(NewsController.validateUrl('https://example.test/rss'), isNull);
      expect(NewsController.validateUrl('http://example.test/feed.xml'), isNull);
      expect(NewsController.validateUrl('ftp://example.test/feed'), isNotNull);
      expect(NewsController.validateUrl('file:///etc/passwd'), isNotNull);
      expect(NewsController.validateUrl('не адрес'), isNotNull);
    });
  });
}
