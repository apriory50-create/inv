import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/domain/sim/engine_models.dart';
import 'package:invest_trainer/domain/sim/instrument_catalog.dart';
import 'package:invest_trainer/domain/sim/review.dart';
import 'package:invest_trainer/domain/sim/scenario_catalog.dart';
import 'package:invest_trainer/domain/sim/scenario_model.dart';
import 'package:invest_trainer/domain/sim/sim_engine.dart';

Scenario _custom(ScenarioParams p, {String category = 'Тест'}) => Scenario(
      id: 'T',
      category: category,
      difficulty: 1,
      headline: 'Тестовый сценарий',
      news: '',
      plain: '',
      signs: const [],
      params: p,
      best: const ['x'],
      bad: const ['y'],
      mistakes: const [],
      lessonIds: const [1],
    );

/// Купонный период полугодовых выпусков в каталоге: (365 / 2).round() = 183 дня.
const int kHalfYearPeriod = 183;

void main() {
  group('Каталог инструментов', () {
    final specs = InstrumentCatalog.build();

    test('id уникальны, цены и сроки положительные', () {
      final ids = <String>{};
      for (final s in specs) {
        expect(ids.add(s.id), isTrue, reason: 'повтор ${s.id}');
        expect(s.name, isNotEmpty);
        expect(s.description, isNotEmpty);
        expect(s.risksPlain, isNotEmpty);
        if (s.kind == InstrumentKind.bond) {
          expect(s.maturityDays, greaterThan(0), reason: s.id);
        } else {
          expect(s.startPrice, greaterThan(0), reason: s.id);
        }
      }
      expect(specs.length, greaterThanOrEqualTo(30));
    });

    test('есть все основные классы активов', () {
      final groups = specs.map((s) => s.group).toSet();
      expect(groups, containsAll(AssetGroup.values));
    });
  });

  group('Старт и детерминизм', () {
    test('капитал на старте равен стартовым деньгам, цены облигаций разумные', () {
      final e = SimEngine(seed: 1);
      expect(e.totalValue(), 1000000);
      final floater = e.quote('OFZ-F');
      expect(floater.pricePctOfNominal, closeTo(100, 0.5));
      final long = e.quote('OFZ-L');
      expect(long.pricePctOfNominal!, lessThan(75));
      expect(long.yieldPct, closeTo(14.5, 1e-6));
    });

    test('одинаковый seed даёт одинаковый результат, разный — другой', () {
      SimEngine run(int seed) {
        final e = SimEngine(seed: seed);
        e.buy('F-IDX', 1000);
        e.buy('SVB', 10);
        e.advance(60);
        return e;
      }

      expect(run(5).totalValue(), run(5).totalValue());
      expect(run(5).totalValue(), isNot(run(6).totalValue()));
    });

    test('двухлетняя симуляция всех инструментов не ломается', () {
      final e = SimEngine(seed: 3);
      e.advance(730);
      for (final s in e.catalog) {
        final st = e.state(s.id)!;
        expect(st.price.isFinite, isTrue, reason: s.id);
        expect(st.price, greaterThanOrEqualTo(0), reason: s.id);
      }
      expect(e.totalValue().isFinite, isTrue);
    });
  });

  group('Сделки', () {
    test('покупка списывает деньги и комиссию, продажа возвращает почти всё', () {
      final e = SimEngine(seed: 1);
      final r = e.buy('F-MM', 1000);
      expect(r.ok, isTrue);
      expect(e.units('F-MM'), 1000);
      expect(e.cash, lessThan(1000000 - 100000));
      expect(e.feesPaid, greaterThan(0));
      final s = e.sell('F-MM', 1000);
      expect(s.ok, isTrue);
      expect(e.units('F-MM'), 0);
      // Потеряли только спред и комиссии — меньше 0,5% от сделки.
      expect(1000000 - e.cash, lessThan(500));
      expect(e.taxesPaid, 0); // убыток налога не создаёт
      expect(e.lossCarry, greaterThan(0));
    });

    test('нельзя купить на сумму больше доступных денег и продать больше, чем есть', () {
      final e = SimEngine(seed: 1);
      final r = e.buy('NFT-A', 1000);
      expect(r.ok, isFalse);
      expect(r.message, contains('Недостаточно денег'));
      final s = e.sell('NFT-A', 1);
      expect(s.ok, isFalse);
      expect(e.buy('SVB', 0).ok, isFalse);
    });

    test('при покупке облигации платится НКД, после начала периода он растёт', () {
      final e = SimEngine(seed: 1);
      e.advance(30);
      final q = e.quote('OFZ-S');
      expect(q.accruedPerUnit, greaterThan(0));
      final r = e.buy('OFZ-S', 10);
      expect(r.ok, isTrue);
      expect(r.nkd, closeTo(10 * q.accruedPerUnit, 1e-6));
    });

    test('лимитная заявка исполняется, когда цена достигает уровня', () {
      final e = SimEngine(seed: 2);
      final ask = e.quote('F-MM').ask;
      final id = e.placeLimit('F-MM', TradeSide.buy, 100, ask * 1.5);
      expect(id, greaterThan(0));
      final events = e.advance(1);
      expect(events.any((x) => x.type == EventType.orderFilled), isTrue);
      expect(e.units('F-MM'), 100);
      expect(e.orders, isEmpty);
    });

    test('лимитная заявка с недостижимой ценой снимается через 30 дней', () {
      final e = SimEngine(seed: 2);
      e.placeLimit('F-MM', TradeSide.buy, 10, 1.0);
      final events = e.advance(32);
      expect(events.any((x) => x.type == EventType.orderCancelled), isTrue);
      expect(e.orders, isEmpty);
    });
  });

  group('Купоны, дивиденды, налоги', () {
    test('купон ОФЗ приходит через период, налог 13% с учётом НКД', () {
      final e = SimEngine(seed: 1);
      final r = e.buy('OFZ-S', 10);
      expect(r.ok, isTrue);
      final cashAfterBuy = e.cash;
      final events = e.advance(kHalfYearPeriod);
      final coupon = events.where((x) => x.type == EventType.coupon).toList();
      expect(coupon, hasLength(1));
      // 10 бумаг × 8%/2 × 1000 = 400 ₽, после налога 13% = 348 ₽ (НКД на старте нулевой).
      expect(coupon.first.amount, closeTo(348, 1.0));
      expect(e.cash - cashAfterBuy, closeTo(348, 1.0));
      expect(e.taxesPaid, closeTo(52, 1.0));
    });

    test('уплаченный при покупке НКД уменьшает налог с первого купона', () {
      final e = SimEngine(seed: 1);
      e.advance(91); // середина периода: НКД около половины купона
      final accrued = e.quote('OFZ-S').accruedPerUnit;
      e.buy('OFZ-S', 10);
      final taxBefore = e.taxesPaid;
      e.advance(92);
      final gross = 10 * 40.0;
      final expectedTax = (gross - 10 * accrued) * 0.13;
      expect(e.taxesPaid - taxBefore, closeTo(expectedTax, 1.5));
    });

    test('дивиденды: деньги приходят после налога, цена падает (гэп)', () {
      final e = SimEngine(seed: 1);
      e.buy('SVB', 20);
      final events = e.advance(190);
      final div = events.where((x) => x.type == EventType.dividend).toList();
      expect(div, hasLength(1));
      final net = div.first.amount;
      expect(net, greaterThan(0));
      // Налог = 13% от валовой суммы.
      expect(e.taxesPaid, closeTo(net * 0.13 / 0.87, 0.5));
    });

    test('без позиции дивиденды не начисляются', () {
      final e = SimEngine(seed: 1);
      final events = e.advance(200);
      expect(events.where((x) => x.type == EventType.dividend), isEmpty);
    });

    test('погашение: номинал возвращается, позиция исчезает', () {
      final e = SimEngine(seed: 1);
      e.buy('OFZ-S', 10);
      final events = e.advance(4 * kHalfYearPeriod + 5);
      expect(events.any((x) => x.type == EventType.maturity), isTrue);
      expect(e.units('OFZ-S'), 0);
      expect(e.state('OFZ-S')!.bond!.matured, isTrue);
      expect(e.buy('OFZ-S', 1).ok, isFalse);
      // Куплено со скидкой (≈87,5%) на 10 000 ₽ номинала и получен номинал с купонами: итог выше вложений.
      expect(e.totalValue(), greaterThan(1000000));
    });

    test('амортизация возвращает часть номинала до погашения', () {
      final e = SimEngine(seed: 1);
      e.buy('MUN-A', 10);
      final events = e.advance(8 * kHalfYearPeriod + 5);
      expect(events.where((x) => x.type == EventType.amortization).length, 3);
      expect(events.where((x) => x.type == EventType.maturity).length, 1);
      expect(e.units('MUN-A'), 0);
    });

    test('флоатер: купон следует за ключевой ставкой', () {
      final e = SimEngine(seed: 1);
      e.buy('OFZ-F', 10);
      e.applyScenario(_custom(const ScenarioParams(keyRateDelta: 4, rampDays: 1)));
      e.advance(2);
      expect(e.state('OFZ-F')!.bond!.couponRate, closeTo(16 + 4 - 0.5, 1e-9));
    });
  });

  group('Оферта и дефолт', () {
    test('с заявкой номинал возвращается, без заявки купон снижается и цена падает', () {
      final withApply = SimEngine(seed: 1);
      final without = SimEngine(seed: 1);
      for (final e in [withApply, without]) {
        e.buy('RTL-1', 10);
        e.advance(537);
        expect(e.offerWindowOpen('RTL-1'), isTrue, reason: 'окно оферты RTL-1 после 537 дней');
      }
      expect(withApply.submitForOffer('RTL-1'), isTrue);
      // Оферта исполняется на 549-й день; от 537-го до него 12 дней.
      final evA = withApply.advance(12);
      final evB = without.advance(12);

      expect(evA.any((x) => x.type == EventType.offerResult && x.text.contains('исполнена')), isTrue);
      expect(withApply.units('RTL-1'), 0);

      expect(evB.any((x) => x.type == EventType.offerResult && x.text.contains('не подали')), isTrue);
      expect(without.missedOffers, hasLength(1));
      expect(without.state('RTL-1')!.bond!.couponRate, closeTo(0.1, 1e-9));
      // Цена облигации после сниженного купона сильно ниже номинала.
      expect(without.quote('RTL-1').pricePctOfNominal!, lessThan(82));
      expect(withApply.totalValue(), greaterThan(without.totalValue()));
    });

    test('заявку на оферту нельзя подать, пока окно закрыто', () {
      final e = SimEngine(seed: 1);
      e.buy('RTL-1', 1);
      expect(e.offerWindowOpen('RTL-1'), isFalse);
      expect(e.submitForOffer('RTL-1'), isFalse);
    });

    test('дефолт: цена падает до цены восстановления, купоны не платятся', () {
      final e = SimEngine(seed: 1);
      e.buy('LSG-V', 10);
      e.applyScenario(_custom(const ScenarioParams(defaultIssuers: ['Лизинг Гарант'], rampDays: 1)));
      final st = e.state('LSG-V')!;
      expect(st.bond!.defaulted, isTrue);
      expect(st.price, closeTo(250, 1));
      final before = e.cash;
      e.advance(60);
      expect(e.cash, before); // купоны по дефолтной бумаге не поступают
    });
  });

  group('Сценарии и разбор', () {
    test('рост ставки: длинная ОФЗ падает сильно, флоатер почти не меняется', () {
      final e = SimEngine(seed: 7);
      e.buy('OFZ-L', 100);
      e.buy('OFZ-F', 100);
      final pL = e.state('OFZ-L')!.price;
      final pF = e.state('OFZ-F')!.price;
      e.applyScenario(_custom(const ScenarioParams(keyRateDelta: 2, rampDays: 3)));
      e.advance(5);
      final dropL = (e.state('OFZ-L')!.price / pL - 1) * 100;
      final dropF = (e.state('OFZ-F')!.price / pF - 1) * 100;
      expect(dropL, inInclusiveRange(-15, -8));
      expect(dropF.abs(), lessThan(1.5));
    });

    test('падение рынка отражается на индексном фонде примерно с коэффициентом бета', () {
      final e = SimEngine(seed: 11);
      final p0 = e.state('F-IDX')!.price;
      e.applyScenario(_custom(const ScenarioParams(marketShift: -10, rampDays: 3)));
      e.advance(3);
      final change = (e.state('F-IDX')!.price / p0 - 1) * 100;
      expect(change, lessThan(-4));
    });

    test('слабый рубль: валютная облигация и золото дорожают в рублях', () {
      final e = SimEngine(seed: 5);
      final fx0 = e.quote('FXB-1').mid;
      final g0 = e.state('F-GLD')!.price;
      e.applyScenario(_custom(const ScenarioParams(fxDelta: 20, rampDays: 2)));
      e.advance(3);
      expect(e.quote('FXB-1').mid, greaterThan(fx0 * 1.1));
      expect(e.state('F-GLD')!.price, greaterThan(g0 * 1.1));
    });

    test('разбор: продажа акций с убытком на панике без изменения фундамента находит ошибку', () {
      final e = SimEngine(seed: 4);
      e.buy('F-IDX', 3000);
      e.buy('SVB', 100);
      final panic = ScenarioCatalog.all().firstWhere((s) => s.headline.startsWith('Паника на рынке') && s.headline.contains('уровень 3'));
      final rec = e.applyScenario(panic);
      e.advance(4);
      e.sell('F-IDX', 3000);
      e.sell('SVB', 100);
      final review = ReviewEngine.review(e, rec);
      expect(review.findings.map((f) => f.type), contains(MistakeType.panicSell));
      expect(review.verdict, isNot(Verdict.excellent));
      expect(review.summaryLines, isNotEmpty);
    });

    test('разбор: спокойствие при панике и докупка из резерва засчитываются как хорошие решения', () {
      final e = SimEngine(seed: 4);
      e.buy('F-IDX', 2000);
      e.buy('F-MM', 3000);
      e.buy('SVB', 100);
      e.buy('NFT-A', 5);
      e.buy('RET-M', 20);
      e.buy('OFZ-S', 50);
      final panic = ScenarioCatalog.all().firstWhere((s) => s.headline.startsWith('Паника на рынке') && s.headline.contains('уровень 4'));
      final rec = e.applyScenario(panic);
      e.advance(4);
      final review = ReviewEngine.review(e, rec);
      expect(review.findings.where((f) => f.type == MistakeType.panicSell), isEmpty);
      expect(review.goodDecisions, isNotEmpty);
    });

    test('разбор: портфель из одного эмитента получает замечание о концентрации', () {
      final e = SimEngine(seed: 4);
      // 300 лотов по 10 акций по 300 ₽ = 900 000 ₽, это ~90% стартового капитала.
      expect(e.buy('SVB', 300).ok, isTrue);
      final s = _custom(const ScenarioParams(marketShift: -1, rampDays: 1));
      final rec = e.applyScenario(s);
      e.advance(2);
      final review = ReviewEngine.review(e, rec);
      expect(review.findings.map((f) => f.type), contains(MistakeType.concentration));
    });

    test('разбор: рекомендация «флоатеры» показывает лучший результат при росте ставки для портфеля с длинными ОФЗ', () {
      final e = SimEngine(seed: 9);
      e.buy('OFZ-L', 1000);
      final sc = ScenarioCatalog.all().firstWhere((s) => s.headline.startsWith('ЦБ повышает ключевую ставку на 2 '));
      final rec = e.applyScenario(sc);
      e.advance(4);
      final review = ReviewEngine.review(e, rec);
      expect(review.recommendedPct, isNotNull);
      expect(review.recommendedPct!, greaterThan(review.doNothingPct));
      expect(review.findings.map((f) => f.type), isNot(contains(MistakeType.panicSell)));
    });
  });
}
