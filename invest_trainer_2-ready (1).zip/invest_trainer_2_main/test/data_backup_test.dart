import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/core/data/data_backup.dart';
import 'package:invest_trainer/core/share/share_texts.dart';
import 'package:invest_trainer/data/db/app_database.dart';
import 'package:invest_trainer/domain/sim/review.dart';
import 'package:invest_trainer/domain/sim/scenario_catalog.dart';
import 'package:invest_trainer/domain/sim/sim_engine.dart';
import 'package:invest_trainer/domain/sim/sim_save.dart';
import 'package:invest_trainer/features/portfolio/portfolio_models.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

Future<Database> _openDb() {
  return databaseFactoryFfi.openDatabase(
    inMemoryDatabasePath,
    options: OpenDatabaseOptions(
      version: 1,
      onCreate: (db, v) async {
        for (final s in AppDatabase.schemaV1) {
          await db.execute(s);
        }
      },
    ),
  );
}

void main() {
  late Database db;
  late SharedPreferences prefs;

  setUp(() async {
    sqfliteFfiInit();
    SharedPreferences.setMockInitialValues({});
    prefs = await SharedPreferences.getInstance();
    db = await _openDb();
  });

  tearDown(() async {
    await db.close();
  });

  Future<void> fillSample() async {
    await db.insert('portfolio_positions', {
      'ticker': 'SBER',
      'name': 'Сбербанк',
      'kind': 'stock',
      'quantity': 10,
      'avg_price': 270,
      'currency': 'RUB',
      'note': 'долгосрочно',
      'created_at': 1,
    });
    await db.insert('lesson_progress', {
      'lesson_id': 5,
      'completed': 1,
      'best_score': 1,
      'last_answer': 1,
      'last_correct': 1,
      'attempts': 2,
      'updated_at': 1,
    });
    await db.insert('news_sources', {'title': 'Лента', 'url': 'https://example.test/rss', 'kind': 'rss', 'enabled': 1});

    final engine = SimEngine(seed: 7);
    engine.buy('F-IDX', 100);
    engine.advance(10);
    await prefs.setString('sim.save.v1', SimSave.encode(engine: engine, reviews: const []));
    await prefs.setString(
      'ai.profiles',
      jsonEncode([
        {'id': '1', 'name': 'Мой ИИ', 'type': 'openaiCompatible', 'baseUrl': 'https://api.example.test/v1', 'model': 'm'},
      ]),
    );
    await prefs.setInt('settings.themeMode', 2);
  }

  test('экспорт не содержит ключей API и включает все разрешённые разделы', () async {
    await fillSample();
    final json = await DataBackup.export(db, prefs);
    expect(json.contains('ai_key_'), isFalse);
    expect(json.contains('apiKey'), isFalse);
    final m = jsonDecode(json) as Map<String, dynamic>;
    expect(m['app'], DataBackup.appId);
    expect(m['version'], DataBackup.version);
    final tables = m['tables'] as Map<String, dynamic>;
    expect(tables['portfolio_positions'], isNotEmpty);
    expect(tables['lesson_progress'], isNotEmpty);
    expect((m['prefs'] as Map)['sim.save.v1'], isA<String>());
  });

  test('экспорт → удаление → восстановление возвращает данные и настройки', () async {
    await fillSample();
    final backup = await DataBackup.export(db, prefs);
    final simBefore = prefs.getString('sim.save.v1');
    final aiBefore = prefs.getString('ai.profiles');

    await DataBackup.wipe(db, prefs);
    expect(await db.query('portfolio_positions'), isEmpty);
    expect(prefs.getString('sim.save.v1'), isNull);

    await DataBackup.restore(backup, db, prefs);
    final positions = await db.query('portfolio_positions');
    expect(positions, hasLength(1));
    expect(positions.single['ticker'], 'SBER');
    expect(positions.single['note'], 'долгосрочно');
    expect((await db.query('lesson_progress')).single['attempts'], 2);
    expect(prefs.getString('sim.save.v1'), simBefore);
    expect(prefs.getString('ai.profiles'), aiBefore);
    expect(prefs.getInt('settings.themeMode'), 2);
  });

  test('восстановление заменяет текущие данные, а не добавляет к ним', () async {
    await fillSample();
    final backup = await DataBackup.export(db, prefs);
    await db.insert('portfolio_positions', {
      'ticker': 'LKOH',
      'name': 'Лукойл',
      'kind': 'stock',
      'quantity': 1,
      'avg_price': 1,
      'currency': 'RUB',
      'created_at': 2,
    });
    expect(await db.query('portfolio_positions'), hasLength(2));
    await DataBackup.restore(backup, db, prefs);
    expect(await db.query('portfolio_positions'), hasLength(1));
  });

  test('описание файла показывает количества и предупреждение о ключах', () async {
    await fillSample();
    final text = DataBackup.describe(await DataBackup.export(db, prefs));
    expect(text, contains('Бумаги в портфеле: 1'));
    expect(text, contains('Профили ИИ: 1'));
    expect(text, contains('ключи API придётся ввести заново'));
  });

  test('чужой, новый и повреждённый файлы отклоняются, данные при этом не меняются', () async {
    await fillSample();
    final before = await db.query('portfolio_positions');

    expect(() => DataBackup.describe('не json'), throwsFormatException);
    expect(() => DataBackup.describe(jsonEncode({'app': 'другое'})), throwsFormatException);
    expect(
      () => DataBackup.describe(jsonEncode({'app': DataBackup.appId, 'version': 99, 'tables': {}, 'prefs': {}})),
      throwsA(isA<FormatException>().having((e) => e.message, 'message', contains('более новой версии'))),
    );

    final corruptSim = jsonEncode({
      'app': DataBackup.appId,
      'version': 1,
      'tables': {},
      'prefs': {'sim.save.v1': 'не сохранение'},
    });
    await expectLater(DataBackup.restore(corruptSim, db, prefs), throwsFormatException);

    expect(await db.query('portfolio_positions'), before);
  });

  test('в тексте для «Поделиться» нет сумм в рублях и количеств', () {
    final text = ShareTexts.portfolioStructure(const [
      Position(ticker: 'SBER', name: 'Сбербанк', kind: PositionKind.stock, quantity: 10, avgPrice: 270),
      Position(ticker: 'OFZ', name: 'ОФЗ', kind: PositionKind.bond, quantity: 3, avgPrice: 1000),
    ]);
    // 10 × 270 = 2 700 и 3 × 1 000 = 3 000, всего 5 700.
    expect(text, contains('Акция: 47,4%'));
    expect(text, contains('Облигация: 52,6%'));
    expect(text.contains('₽'), isFalse);
    expect(text.contains('SBER'), isFalse);
  });

  test('разбор сценария для «Поделиться» не содержит сумм', () {
    final e = SimEngine(seed: 2);
    e.buy('F-IDX', 500);
    final sc = ScenarioCatalog.all().first;
    final rec = e.applyScenario(sc);
    e.advance(3);
    final review = ReviewEngine.review(e, rec);
    final text = ShareTexts.review(review);
    expect(text, contains('Симулятор инвестора'));
    expect(text.contains('₽'), isFalse);
  });
}
