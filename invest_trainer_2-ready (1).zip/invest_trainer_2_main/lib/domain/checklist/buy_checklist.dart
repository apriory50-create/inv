/// Ответ на вопрос чек-листа.
enum Answer { yes, unknown, no }

class ChecklistQuestion {
  final String id;
  final String text;
  final String hint;

  /// Критичный вопрос: ответ «нет» блокирует покупку, даже если остальное в порядке.
  final bool critical;

  const ChecklistQuestion(this.id, this.text, this.hint, {this.critical = false});
}

enum ChecklistVerdict {
  blocked('Сейчас не покупать'),
  checkMore('Нужно проверить ещё'),
  considerable('Можно рассмотреть покупку');

  const ChecklistVerdict(this.label);
  final String label;
}

class ChecklistResult {
  final ChecklistVerdict verdict;
  final int yesCount;
  final int total;
  final List<String> blockers;
  final List<String> todo;

  const ChecklistResult({
    required this.verdict,
    required this.yesCount,
    required this.total,
    required this.blockers,
    required this.todo,
  });
}

/// «Купить? 10 вопросов». Вопросы учебные: помогают не пропустить важное, а не дают рекомендацию.
class BuyChecklist {
  const BuyChecklist._();

  static const List<ChecklistQuestion> questions = [
    ChecklistQuestion('understand', 'Я понимаю, как эта компания или эмитент зарабатывает деньги.',
        'Если объяснить это в двух предложениях не получается, покупать рано.', critical: true),
    ChecklistQuestion('debt', 'Долги в норме: для облигаций рейтинг не ниже A-, для акций Чистый долг / EBITDA не выше 3.',
        'Смотрите рейтинг агентства и отчётность МСФО.'),
    ChecklistQuestion('cash', 'Денежный поток от основной деятельности положительный за последние два периода.',
        'Прибыль на бумаге может отличаться от денег на счетах.'),
    ChecklistQuestion('size', 'После покупки доля бумаги не превысит 10% портфеля, а эмитента — 25%.',
        'Если больше, сократите сумму покупки.'),
    ChecklistQuestion('dates', 'Я знаю даты купонов, оферт, отсечек и отчётов и поставил напоминания.',
        'Пропущенная оферта или отсечка меняет результат.'),
    ChecklistQuestion('price', 'Цена и доходность не выглядят аномально по сравнению с похожими бумагами.',
        'Слишком высокая доходность часто означает высокий риск.'),
    ChecklistQuestion('plan', 'Покупка соответствует моему плану, а не новости, слухам или чужому совету.',
        'Если решение появилось в один день под влиянием новости, подождите сутки.', critical: true),
    ChecklistQuestion('drawdown', 'Я смогу пережить падение этой бумаги на 30% без паники.',
        'Если нет, уменьшите долю или выберите более спокойный инструмент.', critical: true),
    ChecklistQuestion('reserve', 'Деньги не понадобятся в горизонте инвестиции, и подушка безопасности уже есть.',
        'Инвестировать деньги, которые нужны через полгода, рискованно.', critical: true),
    ChecklistQuestion('costs', 'Я учёл комиссии, спред и налог с прибыли.',
        'Мелкие издержки при частых сделках съедают результат.'),
  ];

  static ChecklistResult evaluate(Map<String, Answer> answers) {
    var yes = 0;
    final blockers = <String>[];
    final todo = <String>[];
    for (final q in questions) {
      final a = answers[q.id] ?? Answer.unknown;
      if (a == Answer.yes) {
        yes++;
      } else if (a == Answer.no && q.critical) {
        blockers.add('${q.text} ${q.hint}');
      } else {
        todo.add('${q.text} ${q.hint}');
      }
    }
    final ChecklistVerdict verdict;
    if (blockers.isNotEmpty) {
      verdict = ChecklistVerdict.blocked;
    } else if (yes >= 8 && todo.length <= 2) {
      verdict = ChecklistVerdict.considerable;
    } else {
      verdict = ChecklistVerdict.checkMore;
    }
    return ChecklistResult(
      verdict: verdict,
      yesCount: yes,
      total: questions.length,
      blockers: blockers,
      todo: todo,
    );
  }
}
