import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/ai/ai_models.dart';
import '../../core/ai/ai_profiles_controller.dart';
import '../../core/format.dart';
import '../../core/legal/disclaimer.dart';
import '../../core/security/secure_key_store.dart';
import '../../core/settings/settings_controller.dart';
import '../../news_screen.dart';
import '../../section_tabs.dart';
import '../portfolio/portfolio_models.dart';
import '../portfolio/portfolio_repository.dart';
import 'ai_digest.dart';
import 'news_classifier.dart';
import 'news_controller.dart';
import 'news_models.dart';

/// Раздел «Новости»: подключаемые каналы, фильтры, рыночные и портфельные новости, ИИ-дайджест.
class NewsPage extends ConsumerStatefulWidget {
  const NewsPage({super.key});

  @override
  ConsumerState<NewsPage> createState() => _NewsPageState();
}

class _NewsPageState extends ConsumerState<NewsPage> {
  @override
  void initState() {
    super.initState();
    // Один автоматический запрос при первом открытии, если каналы уже подключены.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final st = ref.read(newsControllerProvider).valueOrNull;
      if (!mounted || st == null) return;
      if (st.updatedAt == null && st.sources.any((s) => s.enabled && !s.isManual)) {
        ref.read(newsControllerProvider.notifier).refresh();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(newsControllerProvider);
    final state = async.valueOrNull;
    return Column(
      children: [
        _Toolbar(state: state),
        Expanded(
          child: async.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text('Не удалось открыть хранилище новостей. Перезапустите приложение.\n$e'),
              ),
            ),
            data: (_) => const SectionTabs(
              labels: ['Рынок', 'Портфель', 'ИИ-инвестор', 'Каналы', 'Разбор примеров'],
              children: [
                _NewsList(scope: NewsScope.market),
                _NewsList(scope: NewsScope.portfolio),
                _DigestTab(),
                _SourcesTab(),
                NewsScreen(),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

/// Результат фильтрации для текущих данных. Null, пока новости не загружены.
FilteredNews? _filtered(WidgetRef ref) {
  final st = ref.watch(newsControllerProvider).valueOrNull;
  if (st == null) return null;
  final positions = ref.watch(positionsProvider).valueOrNull ?? const <Position>[];
  return NewsClassifier.apply(st.items, positions: positions, settings: st.filters, now: DateTime.now());
}

class _Toolbar extends ConsumerWidget {
  const _Toolbar({required this.state});

  final NewsState? state;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = state;
    final ctl = ref.read(newsControllerProvider.notifier);
    final updated = s?.updatedAt;
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 6, 8, 0),
      child: Row(
        children: [
          Expanded(
            child: Text(
              s == null
                  ? 'Загрузка…'
                  : updated == null
                      ? 'Новости ещё не обновлялись'
                      : 'Обновлено: ${fmtDate(updated)} ${updated.hour.toString().padLeft(2, '0')}:${updated.minute.toString().padLeft(2, '0')}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
          IconButton(
            tooltip: 'Добавить заметку с текстом новости',
            icon: const Icon(Icons.note_add_outlined),
            onPressed: s == null ? null : () => _addNote(context, ctl),
          ),
          IconButton(
            tooltip: 'Фильтры',
            icon: const Icon(Icons.filter_alt_outlined),
            onPressed: s == null ? null : () => _filters(context, ref, s),
          ),
          IconButton(
            tooltip: 'Обновить каналы',
            icon: s?.refreshing == true
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.refresh),
            onPressed: s == null || s.refreshing ? null : () => ctl.refresh(),
          ),
        ],
      ),
    );
  }

  Future<void> _addNote(BuildContext context, NewsController ctl) async {
    final title = TextEditingController();
    final body = TextEditingController();
    String? error;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Заметка с новостью'),
          content: SizedBox(
            width: 460,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: title, decoration: const InputDecoration(labelText: 'Заголовок')),
                const SizedBox(height: 8),
                TextField(
                  controller: body,
                  minLines: 4,
                  maxLines: 8,
                  decoration: const InputDecoration(labelText: 'Текст новости', helperText: 'Вставьте текст из другого приложения.'),
                ),
                if (error != null) Text(error!, style: TextStyle(color: Theme.of(ctx).colorScheme.error)),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Отмена')),
            FilledButton(
              onPressed: () async {
                final err = await ctl.addNote(title.text, body.text);
                if (err != null) {
                  setS(() => error = err);
                } else if (ctx.mounted) {
                  Navigator.of(ctx).pop();
                }
              },
              child: const Text('Сохранить'),
            ),
          ],
        ),
      ),
    );
    title.dispose();
    body.dispose();
  }

  void _filters(BuildContext context, WidgetRef ref, NewsState s) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => _FilterSheet(initial: s.filters, sources: s.items.map((i) => i.sourceTitle).toSet().toList()),
    );
  }
}

class _FilterSheet extends ConsumerStatefulWidget {
  const _FilterSheet({required this.initial, required this.sources});

  final NewsFilterSettings initial;
  final List<String> sources;

  @override
  ConsumerState<_FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends ConsumerState<_FilterSheet> {
  late final TextEditingController _include;
  late final TextEditingController _exclude;
  late NewsFilterSettings _f;

  @override
  void initState() {
    super.initState();
    _f = widget.initial;
    _include = TextEditingController(text: _f.includeWords.join(', '));
    _exclude = TextEditingController(text: _f.excludeWords.join(', '));
  }

  @override
  void dispose() {
    _include.dispose();
    _exclude.dispose();
    super.dispose();
  }

  List<String> _words(String s) => s.split(',').map((w) => w.trim()).where((w) => w.isNotEmpty).toList();

  void _save() {
    final f = _f.copyWith(includeWords: _words(_include.text), excludeWords: _words(_exclude.text));
    ref.read(newsControllerProvider.notifier).setFilters(f);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Фильтры новостей', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            TextField(
              controller: _include,
              decoration: const InputDecoration(
                labelText: 'Показывать только со словами',
                helperText: 'Через запятую. Пусто — показывать все.',
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _exclude,
              decoration: const InputDecoration(
                labelText: 'Скрывать со словами',
                helperText: 'Через запятую, например: реклама, прогноз на неделю',
              ),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Скрывать кликбейт и рекламу'),
              value: _f.hideNoisy,
              onChanged: (v) => setState(() => _f = _f.copyWith(hideNoisy: v)),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Скрывать новости без связи с рынком и портфелем'),
              value: _f.hideIrrelevant,
              onChanged: (v) => setState(() => _f = _f.copyWith(hideIrrelevant: v)),
            ),
            Text('Не старше: ${_f.maxAgeDays} дн.'),
            Slider(
              value: _f.maxAgeDays.toDouble(),
              min: 1,
              max: 30,
              divisions: 29,
              onChanged: (v) => setState(() => _f = _f.copyWith(maxAgeDays: v.round())),
            ),
            if (widget.sources.isNotEmpty) ...[
              const Text('Источники'),
              for (final src in widget.sources)
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(src),
                  value: !_f.blockedSources.contains(src),
                  onChanged: (on) => setState(() {
                    final blocked = [..._f.blockedSources];
                    if (on == true) {
                      blocked.remove(src);
                    } else {
                      blocked.add(src);
                    }
                    _f = _f.copyWith(blockedSources: blocked);
                  }),
                ),
            ],
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: OutlinedButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Отмена'))),
                const SizedBox(width: 8),
                Expanded(child: FilledButton(onPressed: _save, child: const Text('Применить'))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _NewsList extends ConsumerWidget {
  const _NewsList({required this.scope});

  final NewsScope scope;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final st = ref.watch(newsControllerProvider).valueOrNull;
    final f = _filtered(ref);
    final theme = Theme.of(context);
    if (st == null || f == null) return const Center(child: CircularProgressIndicator());

    final list = scope == NewsScope.market ? f.market : f.portfolio;
    final errors = st.errors.entries.toList();

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        if (st.sources.where((s) => s.enabled && !s.isManual).isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Text('Подключите каналы во вкладке «Каналы»: RSS или Atom-ленту новостного сайта. '
                  'Прямые закрытые платформы, например Telegram, здесь не подключаются.'),
            ),
          ),
        for (final e in errors)
          Card(
            color: theme.colorScheme.errorContainer,
            child: ListTile(
              leading: const Icon(Icons.error_outline),
              title: Text(e.key),
              subtitle: Text(e.value),
            ),
          ),
        Text(
          scope == NewsScope.market
              ? 'Общерыночные новости: ставка, инфляция, курс, нефть, санкции, госдолг.'
              : 'Новости по бумагам из вашего портфеля (раздел «Портфель»).',
          style: theme.textTheme.bodySmall,
        ),
        if (f.hiddenCount > 0)
          Text('Скрыто фильтрами: ${f.hiddenCount}', style: theme.textTheme.bodySmall),
        const SizedBox(height: 6),
        if (list.isEmpty)
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('Новостей пока нет. Нажмите «Обновить» или проверьте фильтры.'),
          ),
        for (final c in list) _NewsCard(item: c),
      ],
    );
  }
}

class _NewsCard extends StatelessWidget {
  const _NewsCard({required this.item});

  final ClassifiedNews item;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final r = item.raw;
    final kindColor = switch (item.kind) {
      NewsKind.fact => Colors.green.shade700,
      NewsKind.opinion => Colors.blue.shade700,
      NewsKind.rumor => Colors.orange.shade800,
    };
    return Card(
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 14),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        title: Text(r.title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Wrap(
            spacing: 6,
            runSpacing: 4,
            children: [
              Chip(
                visualDensity: VisualDensity.compact,
                label: Text(item.kind.label),
                labelStyle: TextStyle(color: kindColor),
              ),
              Chip(visualDensity: VisualDensity.compact, label: Text(r.sourceTitle)),
              if (r.published != null) Chip(visualDensity: VisualDensity.compact, label: Text(fmtDate(r.published!.toLocal()))),
              for (final t in item.matchedTickers)
                Chip(visualDensity: VisualDensity.compact, avatar: const Icon(Icons.pie_chart_outline, size: 14), label: Text(t)),
            ],
          ),
        ),
        children: [
          if (r.summary.isNotEmpty) Text(r.summary),
          if (item.impacts.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('Возможное влияние (не прогноз):', style: theme.textTheme.titleSmall),
            for (final i in item.impacts)
              Padding(
                padding: const EdgeInsets.only(top: 3),
                child: Text('• $i'),
              ),
          ],
          if (item.kind == NewsKind.rumor) ...[
            const SizedBox(height: 6),
            Text('Слух: проверьте по первоисточнику до решения.',
                style: TextStyle(color: Colors.orange.shade800, fontWeight: FontWeight.w600)),
          ],
          if (r.url.isNotEmpty) ...[
            const SizedBox(height: 6),
            SelectableText(r.url, style: theme.textTheme.bodySmall),
          ],
        ],
      ),
    );
  }
}

class _DigestTab extends ConsumerStatefulWidget {
  const _DigestTab();

  @override
  ConsumerState<_DigestTab> createState() => _DigestTabState();
}

class _DigestTabState extends ConsumerState<_DigestTab> {
  bool _loading = false;
  String? _result;
  String? _error;

  Future<void> _run() async {
    // Обработчик нажатия: только read, watch здесь недопустим.
    final st = ref.read(newsControllerProvider).valueOrNull;
    final profile = ref.read(aiProfilesProvider).active;
    if (st == null) return;
    final positions = ref.read(positionsProvider).valueOrNull ?? const <Position>[];
    final f = NewsClassifier.apply(st.items, positions: positions, settings: st.filters, now: DateTime.now());
    if (profile == null) {
      setState(() => _error = 'Сначала подключите ИИ: Настройки → Подключения ИИ.');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
      _result = null;
    });
    try {
      final key = await ref.read(secureKeyStoreProvider).readKey(profile.id) ?? '';
      final includeAmounts = ref.read(settingsProvider).sendAmountsToAi;
      final text = await NewsDigest.run(
        profile: profile,
        apiKey: key,
        portfolioNews: f.portfolio,
        marketNews: f.market,
        positions: positions,
        includeAmounts: includeAmounts,
      );
      if (!mounted) return;
      setState(() => _result = text);
    } on AiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'Не удалось получить дайджест. Проверьте настройки ИИ.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final f = _filtered(ref);
    final profile = ref.watch(aiProfilesProvider).active;
    final includeAmounts = ref.watch(settingsProvider).sendAmountsToAi;
    final theme = Theme.of(context);
    final sendCount = f == null
        ? 0
        : f.portfolio.length.clamp(0, NewsDigest.maxPortfolioItems).toInt() +
            f.market.length.clamp(0, NewsDigest.maxMarketItems).toInt();

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ИИ-инвестор: дайджест', style: theme.textTheme.titleMedium),
                const SizedBox(height: 6),
                const Text('Дайджест разбирает отобранные новости и объясняет, что они могут значить для вашего портфеля. '
                    'Тексты новостей отправляются как данные, а не как команды.'),
                const SizedBox(height: 8),
                Text(profile == null ? 'ИИ не подключён.' : 'Профиль: ${profile.name} • ${profile.model}'),
                Text(
                  includeAmounts
                      ? 'В ИИ уйдут названия, доли, суммы и отобранные новости.'
                      : 'В ИИ уйдут названия и доли в процентах (без сумм) и отобранные новости.',
                  style: theme.textTheme.bodySmall,
                ),
                Text('Новостей для разбора: $sendCount', style: theme.textTheme.bodySmall),
                const SizedBox(height: 10),
                FilledButton.icon(
                  onPressed: _loading || f == null ? null : _run,
                  icon: _loading
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.auto_awesome),
                  label: const Text('Сделать дайджест'),
                ),
              ],
            ),
          ),
        ),
        if (_error != null) ...[
          const SizedBox(height: 8),
          Text(_error!, style: TextStyle(color: theme.colorScheme.error)),
        ],
        if (_result != null) ...[
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: SelectableText(_result!),
            ),
          ),
        ],
        const SizedBox(height: 8),
        Text(Disclaimer.short, style: theme.textTheme.bodySmall),
      ],
    );
  }
}

class _SourcesTab extends ConsumerWidget {
  const _SourcesTab();

  Future<void> _addRss(BuildContext context, NewsController ctl) async {
    final title = TextEditingController();
    final url = TextEditingController();
    String? error;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Новый канал'),
          content: SizedBox(
            width: 460,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: title, decoration: const InputDecoration(labelText: 'Название, например «Финансовый сайт»')),
                const SizedBox(height: 8),
                TextField(
                  controller: url,
                  keyboardType: TextInputType.url,
                  decoration: const InputDecoration(labelText: 'Адрес RSS или Atom', helperText: 'Обычно ссылка с пометкой RSS на сайте.'),
                ),
                if (error != null) Text(error!, style: TextStyle(color: Theme.of(ctx).colorScheme.error)),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Отмена')),
            FilledButton(
              onPressed: () async {
                final err = await ctl.addSource(title.text, url.text);
                if (err != null) {
                  setS(() => error = err);
                } else if (ctx.mounted) {
                  Navigator.of(ctx).pop();
                }
              },
              child: const Text('Подключить'),
            ),
          ],
        ),
      ),
    );
    title.dispose();
    url.dispose();
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final st = ref.watch(newsControllerProvider).valueOrNull;
    final ctl = ref.read(newsControllerProvider.notifier);
    final theme = Theme.of(context);
    if (st == null) return const Center(child: CircularProgressIndicator());

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        FilledButton.icon(
          onPressed: () => _addRss(context, ctl),
          icon: const Icon(Icons.add_link),
          label: const Text('Подключить канал (RSS или Atom)'),
        ),
        const SizedBox(height: 8),
        const Text('Каналы загружаются с ваших устройств напрямую: приложение не хранит и не пересылает их через свой сервер.'),
        const SizedBox(height: 8),
        if (st.sources.isEmpty)
          const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('Каналов пока нет.'))),
        for (final s in st.sources)
          Card(
            child: SwitchListTile(
              title: Text(s.title),
              subtitle: Text(
                s.isManual ? 'Заметки вручную' : s.url,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              value: s.enabled,
              onChanged: s.isManual ? null : (v) => ctl.toggleSource(s, v),
              secondary: IconButton(
                tooltip: 'Удалить канал',
                icon: const Icon(Icons.delete_outline),
                onPressed: s.isManual ? null : () => ctl.removeSource(s),
              ),
            ),
          ),
        if (st.errors.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text('Последние ошибки загрузки:', style: theme.textTheme.titleSmall),
          for (final e in st.errors.entries) Text('• ${e.key}: ${e.value}'),
        ],
      ],
    );
  }
}
