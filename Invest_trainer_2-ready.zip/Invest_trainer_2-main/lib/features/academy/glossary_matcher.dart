import 'glossary_data.dart';
import 'glossary_entry.dart';

class GlossaryMatch {
  final int start;
  final int end;

  /// Индекс термина в [GlossaryMatcher.entries] (для учета «уже показанных»).
  final int index;
  final GlossaryEntry entry;

  const GlossaryMatch(this.start, this.end, this.index, this.entry);
}

/// Ищет термины глоссария в тексте с учетом окончаний.
class GlossaryMatcher {
  GlossaryMatcher(List<GlossaryEntry> source) : entries = _sorted(source) {
    final alternatives = entries.map((e) => '(${e.pattern})').join('|');
    _regex = RegExp(
      '(?<![\\p{L}\\d])(?:$alternatives)(?![\\p{L}\\d])',
      caseSensitive: false,
      unicode: true,
    );
  }

  /// Термины, отсортированные так, чтобы более длинные шаблоны проверялись раньше коротких.
  final List<GlossaryEntry> entries;
  late final RegExp _regex;

  static List<GlossaryEntry> _sorted(List<GlossaryEntry> source) {
    final copy = [...source];
    copy.sort((a, b) => b.pattern.length.compareTo(a.pattern.length));
    return copy;
  }

  /// Все вхождения терминов в [text] по порядку, без пересечений.
  List<GlossaryMatch> find(String text) {
    final result = <GlossaryMatch>[];
    for (final m in _regex.allMatches(text)) {
      for (var i = 0; i < entries.length; i++) {
        if (m.group(i + 1) != null) {
          result.add(GlossaryMatch(m.start, m.end, i, entries[i]));
          break;
        }
      }
    }
    return result;
  }
}
