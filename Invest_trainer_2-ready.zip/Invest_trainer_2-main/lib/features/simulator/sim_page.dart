import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/format.dart';
import '../../domain/sim/engine_models.dart';
import '../../section_tabs.dart';
import 'journal_tab.dart';
import 'market_tab.dart';
import 'portfolio_tab.dart';
import 'review_page.dart';
import 'scenarios_tab.dart';
import 'sim_controller.dart';

/// Раздел «Симулятор»: виртуальные деньги, перемотка времени, рынок, сценарии и разбор действий.
class SimPage extends ConsumerWidget {
  const SimPage({super.key});

  static const _important = {
    EventType.coupon,
    EventType.dividend,
    EventType.maturity,
    EventType.amortization,
    EventType.offerNotice,
    EventType.offerResult,
    EventType.defaultEvent,
    EventType.orderFilled,
  };

  void _advance(BuildContext context, WidgetRef ref, int days) {
    final events = ref.read(simProvider.notifier).advance(days);
    final important = events.where((e) => _important.contains(e.type)).toList();
    final messenger = ScaffoldMessenger.of(context);
    messenger.hideCurrentSnackBar();
    if (important.isEmpty) return;
    final texts = important.take(2).map((e) => e.text).join('\n');
    final more = important.length > 2 ? '\nИ ещё событий: ${important.length - 2} (см. «Журнал»)' : '';
    messenger.showSnackBar(SnackBar(content: Text('$texts$more'), duration: const Duration(seconds: 7)));
  }

  void _finish(BuildContext context, WidgetRef ref) {
    final review = ref.read(simProvider.notifier).finishScenario();
    if (review == null) return;
    Navigator.of(context, rootNavigator: true).push(
      MaterialPageRoute<void>(builder: (_) => ReviewPage(review: review)),
    );
  }

  Future<void> _newGame(BuildContext context, WidgetRef ref) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Начать новую игру?'),
        content: const Text('Текущий портфель, история и статистика сценариев будут сброшены. Деньги вернутся к 1 000 000 ₽.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Начать заново')),
        ],
      ),
    );
    if (ok == true) ref.read(simProvider.notifier).newGame();
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sim = ref.watch(simProvider);
    final e = sim.engine;
    final total = e.totalValue();
    final change = e.initialCash > 0 ? (total / e.initialCash - 1) * 100 : 0.0;
    final theme = Theme.of(context);
    final active = sim.active;

    return Column(
      children: [
        Card(
          margin: const EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${fmtDate(e.date)} • день ${e.day}',
                        style: theme.textTheme.titleSmall,
                      ),
                    ),
                    IconButton(
                      tooltip: 'Новая игра',
                      icon: const Icon(Icons.restart_alt),
                      onPressed: () => _newGame(context, ref),
                    ),
                  ],
                ),
                Wrap(
                  spacing: 16,
                  runSpacing: 4,
                  children: [
                    Text('Капитал: ${fmtRub(total)} ₽ (${fmtPct(change)})', style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text('Деньги: ${fmtRub(e.cash)} ₽'),
                    Text('Ключевая ставка: ${fmtPct(e.keyRate, sign: false)}'),
                    Text('Инфляция: ${fmtPct(e.inflation, sign: false)}'),
                    Text('Валюта: ${fmtPct((e.fxIndex - 1) * 100)} к старту'),
                  ],
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: [
                    for (final (label, days) in const [('+1 день', 1), ('+1 неделя', 7), ('+1 месяц', 30), ('+3 месяца', 91)])
                      FilledButton.tonal(onPressed: () => _advance(context, ref, days), child: Text(label)),
                  ],
                ),
              ],
            ),
          ),
        ),
        if (active != null)
          Card(
            margin: const EdgeInsets.fromLTRB(12, 0, 12, 4),
            color: theme.colorScheme.tertiaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Идёт сценарий: ${active.scenario.headline}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(active.scenario.news),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: [
                      OutlinedButton(onPressed: () => _advance(context, ref, 3), child: const Text('Прокрутить 3 дня')),
                      FilledButton(onPressed: () => _finish(context, ref), child: const Text('Завершить и получить разбор')),
                    ],
                  ),
                ],
              ),
            ),
          ),
        const Expanded(
          child: SectionTabs(
            labels: ['Рынок', 'Портфель', 'Журнал', 'Сценарии'],
            children: [MarketTab(), SimPortfolioTab(), JournalTab(), ScenariosTab()],
          ),
        ),
      ],
    );
  }
}
