import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:invest_trainer/domain/sim/engine_models.dart';
import 'package:invest_trainer/domain/sim/review.dart';
import 'package:invest_trainer/domain/sim/scenario_catalog.dart';
import 'package:invest_trainer/domain/sim/scenario_model.dart';
import 'package:invest_trainer/domain/sim/sim_engine.dart';
import 'package:invest_trainer/domain/sim/sim_save.dart';

void main() {
  test('движок восстанавливается точно: день, деньги, позиции, цены, журналы', () {
    final e = SimEngine(seed: 42);
    e.buy('F-IDX', 500);
    e.buy('OFZ-S', 20);
    e.buy('SVB', 30);
    e.placeLimit('F-MM', TradeSide.buy, 10, 1.0);
    e.advance(200);
    e.sell('SVB', 10);

    final raw = SimSave.encode(engine: e, reviews: const []);
    final restored = SimSave.decode(raw)!.engine;

    expect(restored.day, e.day);
    expect(restored.cash, e.cash);
    expect(restored.totalValue(), closeTo(e.totalValue(), 1e-6));
    expect(restored.units('OFZ-S'), e.units('OFZ-S'));
    expect(restored.units('SVB'), e.units('SVB'));
    expect(restored.quote('OFZ-S').mid, e.quote('OFZ-S').mid);
    expect(restored.quote('OFZ-S').accruedPerUnit, closeTo(e.quote('OFZ-S').accruedPerUnit, 1e-9));
    expect(restored.trades.length, e.trades.length);
    expect(restored.events.length, e.events.length);
    expect(restored.valueHistory.length, e.valueHistory.length);
    expect(restored.feesPaid, closeTo(e.feesPaid, 1e-9));
    expect(restored.taxesPaid, closeTo(e.taxesPaid, 1e-9));
    expect(restored.lossCarry, closeTo(e.lossCarry, 1e-9));
    expect(restored.orders.length, e.orders.length);
    expect(restored.snapshot().total, closeTo(e.snapshot().total, 1e-6));
    expect(restored.snapshot().duration, closeTo(e.snapshot().duration, 1e-9));
  });

  test('после восстановления время продолжает идти: купоны и торги работают', () {
    final e = SimEngine(seed: 3);
    e.buy('OFZ-S', 10);
    e.advance(100);
    final restored = SimSave.decode(SimSave.encode(engine: e, reviews: const []))!.engine;
    final events = restored.advance(120);
    expect(events.any((x) => x.type == EventType.coupon), isTrue);
    expect(restored.sell('OFZ-S', 10).ok, isTrue);
  });

  test('активный сценарий и разборы сохраняются и потом завершаются', () {
    final e = SimEngine(seed: 8);
    e.buy('F-IDX', 2000);
    e.buy('SVB', 100);
    final panic = ScenarioCatalog.all().firstWhere((s) => s.headline.startsWith('Паника на рынке') && s.headline.contains('уровень 3'));
    final first = e.applyScenario(ScenarioCatalog.all().first);
    e.advance(3);
    final review = ReviewEngine.review(e, first);
    final second = e.applyScenario(panic);

    final raw = SimSave.encode(engine: e, reviews: [review], active: second);
    final data = SimSave.decode(raw)!;

    expect(data.reviews, hasLength(1));
    expect(data.reviews.first.headline, review.headline);
    expect(data.reviews.first.scenario.id, review.scenario.id);
    expect(data.reviews.first.findings.length, review.findings.length);
    expect(data.reviews.first.verdict, review.verdict);

    expect(data.active, isNotNull);
    expect(data.active!.scenario.id, panic.id);
    expect(data.active!.before.total, closeTo(second.before.total, 1e-6));
    expect(data.active!.before.positions.length, second.before.positions.length);
    expect(data.active!.tradeStart, second.tradeStart);
    expect(data.active!.eventStart, second.eventStart);

    // Завершение восстановленного сценария даёт разбор, как и без перезапуска.
    e.advance(2);
    final restoredReview = ReviewEngine.review(data.engine, data.active!);
    expect(restoredReview.scenario.id, panic.id);
    expect(restoredReview.startDay, second.startDay);
  });

  test('шок активного сценария переживает перезапуск', () {
    final e = SimEngine(seed: 5);
    e.buy('F-IDX', 1000);
    final sc = ScenarioCatalog.all().firstWhere((s) => s.headline.startsWith('Рубль слабеет'));
    e.applyScenario(sc);
    final restored = SimSave.decode(SimSave.encode(engine: e, reviews: const []))!.engine;
    expect(restored.state('F-GLD')!.spec.id, 'F-GLD');
    // Незавершённый шок продолжает действовать: состояние шока совпадает.
    final a = e.state('FXB-1')!;
    final b = restored.state('FXB-1')!;
    expect(b.bond!.yieldPct, closeTo(a.bond!.yieldPct, 1e-9));
  });

  test('повреждённые данные и неизвестная версия не ломают приложение', () {
    expect(SimSave.decode('не json'), isNull);
    expect(SimSave.decode(jsonEncode({'v': 99})), isNull);
    expect(SimSave.decode(jsonEncode({'v': 1, 'engine': {}})), isNull);
  });
}
